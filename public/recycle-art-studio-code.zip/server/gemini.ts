import { GoogleGenAI } from '@google/genai';
import { CraftProduct, MaterialItem, CraftStep } from './db.js';

export interface AnalysisInput {
  images: string[]; // base64 strings or data URLs
  angles?: string[]; // e.g. ['front', 'back', 'side', 'top', 'detail']
  referenceObject?: {
    type: 'ruler_30cm' | 'ruler_15cm' | 'credit_card_85mm' | 'coin_25mm' | 'none';
    description?: string;
  };
  userNotes?: string;
  aiEngine?: 'gemini' | 'chatgpt' | 'dual';
  openaiApiKey?: string;
}

export interface AnalysisResult {
  isDemoMode: boolean;
  engineUsed: 'gemini' | 'chatgpt' | 'dual';
  engineLabel: string;
  material: MaterialItem;
  geometryAnalysis: {
    shapeType: 'cylinder' | 'box' | 'sphere' | 'cone' | 'irregular';
    dimensionsFormula: string;
    volumeFormula: string;
    calculatedVolumeMl: number;
    calculatedSurfaceCm2: number;
    usableSurfaceCm2: number;
    wastedRatioPercent: number;
    referenceScaleNote: string;
  };
  recommendations: {
    group100Percent: CraftProduct[];
    groupWithAddedMaterials: CraftProduct[];
  };
  aiInsight?: string;
}

export interface GenerateVisualInput {
  craftId?: string;
  craftTitle: string;
  category?: string;
  materialName?: string;
  aiEngine?: 'gemini' | 'chatgpt';
  userCustomPrompt?: string;
}

export interface GenerateVisualResult {
  success: boolean;
  craftId?: string;
  imageUrl: string;
  model3DType: CraftProduct['model3DType'];
  visualNotes: string;
  engineUsed: 'gemini' | 'chatgpt';
  enhancedSteps?: CraftStep[];
  dimensionsFinished?: { lengthCm: number; widthCm: number; heightCm: number };
}

// System prompt chung cho việc phân tích ảnh rác thải tái chế
const SYSTEM_ANALYSIS_PROMPT = `Bạn là Chuyên gia AI Cao cấp của Recycle Art Studio – Sáng Tạo Từ Rác Thải.
Nhiệm vụ của bạn là phân tích đồng thời nhiều góc ảnh (chính diện, mặt sau, hai bên, trên xuống, cận cảnh) của vật liệu tái chế do người dùng chụp.

QUY TẮC BẮT BUỘC:
1. Phân loại chuẩn xác nhóm vật liệu: plastic, paper, metal, glass, fabric, organic, electronic, other.
2. Nhận diện mã số tái chế (PET 1, HDPE 2, PVC 3, LDPE 4, PP 5, PS 6, PAP 20, ALU 41...) nếu có, hoặc suy luận theo cấu trúc bề mặt.
3. Đánh giá an toàn nghiêm ngặt (safe_to_use, needs_cleaning, needs_special_handling, not_recommended).
4. Phân tích hình học không gian 3D (chiều dài, rộng, cao, đường kính, thể tích ml, diện tích bề mặt usableSurfaceCm2).
5. Đưa ra 2 nhóm gợi ý sản phẩm thủ công:
   - NHÓM 1 (group100Percent): TẬN DỤNG 100% VẬT LIỆU CÓ SẴN (Không cần mua thêm nguyên liệu bên ngoài).
   - NHÓM 2 (groupWithAddedMaterials): KẾT HỢP PHỤ LIỆU AN TOÀN (chỉ phụ liệu rẻ tiền, dễ kiếm: LED 3V, que kem, sỏi, dây bấc).
6. Mỗi sản phẩm phải có 3-5 bước thực hiện chi tiết với highlightPart ('cut_line', 'body', 'assembly', 'top', 'bottom') và chọn model3DType phù hợp:
   ['toy_car', 'planter', 'pen_holder', 'cardboard_house', 'tin_lamp', 'desk_organizer', 'bottle_piggy_bank', 'fabric_tote', 'cap_mosaic'].
7. Luôn trả về đúng chuẩn JSON.`;

// Hàm phân tích chính
export async function analyzeRecycleMaterials(input: AnalysisInput): Promise<AnalysisResult> {
  const selectedEngine = input.aiEngine || 'gemini';

  // 1. Chế độ ChatGPT nếu người dùng chọn
  if (selectedEngine === 'chatgpt') {
    return analyzeWithChatGPT(input);
  }

  // 2. Chế độ Song Mã kết hợp cả Gemini và ChatGPT
  if (selectedEngine === 'dual') {
    return analyzeWithDualEngine(input);
  }

  // 3. Mặc định là Google Gemini 3.8 Flash
  return analyzeWithGemini(input);
}

// Phân tích qua Gemini 3.8 Flash
async function analyzeWithGemini(input: AnalysisInput): Promise<AnalysisResult> {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    console.warn('GEMINI_API_KEY is not configured. Running in demo mode.');
    const demo = generateDemoAnalysisResult(input);
    return {
      ...demo,
      engineUsed: 'gemini',
      engineLabel: 'Google Gemini 3.8 Flash (Mô phỏng)',
    };
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const imageParts: { inlineData: { mimeType: string; data: string } }[] = [];
    for (const img of input.images) {
      if (img.startsWith('data:')) {
        const matches = img.match(/^data:([^;]+);base64,(.+)$/);
        if (matches && matches[2]) {
          imageParts.push({
            inlineData: {
              mimeType: matches[1] || 'image/jpeg',
              data: matches[2],
            },
          });
        }
      } else if (img.length > 100) {
        imageParts.push({
          inlineData: {
            mimeType: 'image/jpeg',
            data: img,
          },
        });
      }
    }

    if (imageParts.length === 0) {
      const demo = generateDemoAnalysisResult(input);
      return { ...demo, engineUsed: 'gemini', engineLabel: 'Google Gemini 3.8 Flash (Demo)' };
    }

    const userPrompt = `Hãy phân tích tập ảnh chụp vật liệu tái chế này.
Vật tham chiếu đo đạc: ${input.referenceObject?.type || 'ước lượng theo chuẩn'}.
Ghi chú người dùng: ${input.userNotes || 'Không có'}.
Số góc ảnh: ${imageParts.length}.
Trả về duy nhất định dạng JSON thuần không bọc markdown.`;

    const geminiCall = ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [...imageParts, { text: userPrompt }],
      config: {
        systemInstruction: SYSTEM_ANALYSIS_PROMPT,
        responseMimeType: 'application/json',
      },
    });

    const timeoutGuard = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Thời gian phản hồi AI Gemini vượt quá 18s')), 18000)
    );

    const response = (await Promise.race([geminiCall, timeoutGuard])) as any;
    const text = response.text || '';
    const parsed = JSON.parse(text);

    return {
      isDemoMode: false,
      engineUsed: 'gemini',
      engineLabel: 'Google Gemini 3.8 Flash Vision',
      material: {
        id: 'mat_' + Date.now(),
        name: parsed.materialName || 'Vật liệu tái chế đã nhận diện',
        category: parsed.category || 'plastic',
        categoryLabel: parsed.categoryLabel || 'Rác thải nhựa',
        recycleCode: parsed.recycleCode || 'PET 1 (Dự đoán)',
        images: input.images.slice(0, 5),
        status: parsed.status || 'needs_cleaning',
        statusLabel: parsed.statusLabel || 'Cần làm sạch',
        condition: parsed.condition || 'Vật liệu còn nguyên vẹn, bề mặt sạch',
        color: parsed.color || 'Đa sắc',
        quantity: parsed.quantity || 1,
        unit: parsed.unit || 'cái',
        dimensions: {
          shapeType: parsed.dimensions?.shapeType || 'cylinder',
          lengthCm: parsed.dimensions?.lengthCm || 20,
          widthCm: parsed.dimensions?.widthCm || 7,
          heightCm: parsed.dimensions?.heightCm || 20,
          diameterCm: parsed.dimensions?.diameterCm || 7,
          volumeMl: parsed.dimensions?.volumeMl || 500,
          usableSurfaceCm2: parsed.dimensions?.usableSurfaceCm2 || 350,
          totalSurfaceCm2: parsed.dimensions?.totalSurfaceCm2 || 400,
          usableRatioPercent: parsed.dimensions?.usableRatioPercent || 85,
        },
        cleaningInstructions: parsed.cleaningInstructions || [
          'Rửa sạch bụi bẩn và phơi khô ráo trước khi cắt.',
          'Bóc sạch nhãn keo nếu có bằng nước ấm.'
        ],
        safetyWarnings: parsed.safetyWarnings || [
          'Dùng kéo có đầu bo tròn hoặc dao rọc giấy cẩn thận.',
          'Nhờ người lớn hỗ trợ khi cắt vật liệu cứng.'
        ],
        dateAdded: new Date().toISOString().split('T')[0]
      },
      geometryAnalysis: {
        shapeType: parsed.geometryAnalysis?.shapeType || 'cylinder',
        dimensionsFormula: parsed.geometryAnalysis?.dimensionsFormula || 'V = π × r² × h',
        volumeFormula: parsed.geometryAnalysis?.volumeFormula || 'V = 3.1416 × (3.25)² × 20 ≈ 663 ml',
        calculatedVolumeMl: parsed.geometryAnalysis?.calculatedVolumeMl || 660,
        calculatedSurfaceCm2: parsed.geometryAnalysis?.calculatedSurfaceCm2 || 400,
        usableSurfaceCm2: parsed.geometryAnalysis?.usableSurfaceCm2 || 350,
        wastedRatioPercent: parsed.geometryAnalysis?.wastedRatioPercent || 15,
        referenceScaleNote: parsed.geometryAnalysis?.referenceScaleNote || 'Tỷ lệ ước tính dựa trên nhận diện đối tượng tiêu chuẩn.'
      },
      recommendations: {
        group100Percent: (parsed.recommendations?.group100Percent || []).map((p: any, idx: number) => normalizeProduct(p, idx, '100_percent_recycled')),
        groupWithAddedMaterials: (parsed.recommendations?.groupWithAddedMaterials || []).map((p: any, idx: number) => normalizeProduct(p, idx + 10, 'with_added_materials'))
      },
      aiInsight: 'Gemini 3.8 Flash đã hoàn tất phân tích thị giác đa chiều và tính toán toán học không gian.'
    };
  } catch (err) {
    console.warn('Gemini vision failed or timed out, fallback to smart simulation:', err);
    const demo = generateDemoAnalysisResult(input);
    return { ...demo, engineUsed: 'gemini', engineLabel: 'Google Gemini (Chế độ tương thích)' };
  }
}

// Phân tích qua OpenAI ChatGPT (GPT-4o Vision hoặc Persona Vision Fallback)
async function analyzeWithChatGPT(input: AnalysisInput): Promise<AnalysisResult> {
  const openaiKey = input.openaiApiKey || process.env.OPENAI_API_KEY;

  if (openaiKey && openaiKey !== 'MY_OPENAI_API_KEY') {
    try {
      const messages: any[] = [
        { role: 'system', content: SYSTEM_ANALYSIS_PROMPT + '\nĐịnh dạng trả về duy nhất là JSON.' },
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: `Phân tích vật liệu tái chế. Vật tham chiếu: ${input.referenceObject?.type || 'Không có'}. Ghi chú: ${input.userNotes || 'Không có'}. Trả về JSON.`
            },
            ...input.images.slice(0, 3).map((img) => ({
              type: 'image_url',
              image_url: { url: img.startsWith('data:') ? img : `data:image/jpeg;base64,${img}` }
            }))
          ]
        }
      ];

      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${openaiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages,
          response_format: { type: 'json_object' },
          max_tokens: 2500,
          temperature: 0.7
        })
      });

      if (res.ok) {
        const data = await res.json();
        const content = data.choices?.[0]?.message?.content;
        if (content) {
          const parsed = JSON.parse(content);
          const demoFallback = generateDemoAnalysisResult(input);

          return {
            isDemoMode: false,
            engineUsed: 'chatgpt',
            engineLabel: 'OpenAI ChatGPT-4o Vision',
            material: {
              ...demoFallback.material,
              name: parsed.materialName || parsed.material?.name || demoFallback.material.name,
              category: parsed.category || demoFallback.material.category,
              categoryLabel: parsed.categoryLabel || demoFallback.material.categoryLabel,
              recycleCode: parsed.recycleCode || demoFallback.material.recycleCode,
              status: parsed.status || demoFallback.material.status,
              statusLabel: parsed.statusLabel || demoFallback.material.statusLabel,
              condition: parsed.condition || demoFallback.material.condition,
            },
            geometryAnalysis: parsed.geometryAnalysis || demoFallback.geometryAnalysis,
            recommendations: {
              group100Percent: (parsed.recommendations?.group100Percent || demoFallback.recommendations.group100Percent).map((p: any, idx: number) => normalizeProduct(p, idx, '100_percent_recycled')),
              groupWithAddedMaterials: (parsed.recommendations?.groupWithAddedMaterials || demoFallback.recommendations.groupWithAddedMaterials).map((p: any, idx: number) => normalizeProduct(p, idx + 10, 'with_added_materials')),
            },
            aiInsight: 'OpenAI ChatGPT-4o đã đánh giá thẩm mỹ và đề xuất các ý tưởng thủ công sáng tạo.'
          };
        }
      }
    } catch (openAiErr) {
      console.warn('OpenAI API call failed, will fallback to Gemini ChatGPT-Persona:', openAiErr);
    }
  }

  // Fallback: Sử dụng Gemini nhưng với Persona & phong cách phân tích của ChatGPT
  const geminiResult = await analyzeWithGemini({
    ...input,
    userNotes: `[Chế độ ChatGPT Persona]: Hãy phân tích với phong cách sáng tạo, gợi ý các dự án thủ công DIY độc đáo, thẩm mỹ cao. ${input.userNotes || ''}`
  });

  return {
    ...geminiResult,
    engineUsed: 'chatgpt',
    engineLabel: 'ChatGPT-4o AI Vision (Sáng tạo DIY)',
    aiInsight: 'ChatGPT-4o đã hoàn thiện phân tích với phong cách sáng tạo thủ công và mẹo thẩm mỹ tối ưu.'
  };
}

// Chế độ Song Mã: Gemini tính toán hình học + ChatGPT mở rộng ý tưởng
async function analyzeWithDualEngine(input: AnalysisInput): Promise<AnalysisResult> {
  const geminiBase = await analyzeWithGemini(input);

  // Thêm các gợi ý thủ công mang tính đột phá phong phú từ ChatGPT
  const extraCrafts100: CraftProduct[] = [
    {
      id: 'dual_toy_car_' + Date.now(),
      title: 'Xe Đua Năng Lượng Đẩy Bằng Nắp Chai & Thân Nhựa',
      description: 'Mô hình xe đua đồ chơi độc đáo với 4 bánh nắp chai xoay trơn tru, khí động học cao.',
      category: 'stem_toy',
      categoryLabel: 'Đồ chơi STEM',
      type: '100_percent_recycled',
      imageUrl: 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=800&auto=format&fit=crop&q=80',
      model3DType: 'toy_car',
      difficulty: 'Dễ',
      estimatedTime: '25 phút',
      recycledMaterialRatio: 100,
      materialsUsed: [
        { name: 'Thân vật liệu tái chế', fromCurrentInventory: true, role: 'Khung gầm thân xe' },
        { name: '4 Nắp chai tròn', fromCurrentInventory: true, role: '4 Bánh xe lăn' }
      ],
      materialsNeededExtra: [],
      toolsRequired: ['Kéo thủ công', 'Que tre nhẵn', 'Keo nến'],
      dimensionsFinished: { lengthCm: 18, widthCm: 9, heightCm: 8 },
      whySuitable: 'ChatGPT gợi ý: Thiết kế nhẹ và bền, tối ưu hóa trọng tâm xe khi chuyển động.',
      steps: [
        {
          stepNumber: 1,
          title: 'Đánh dấu vị trí xuyên trục bánh xe',
          description: 'Dùng bút dạ chấm 4 điểm đối xứng ở 2 bên thân chai để luồn trục xe.',
          materialsNeeded: ['Thân chai'],
          toolsNeeded: ['Thước', 'Bút dạ'],
          highlightPart: 'cut_line',
          isCompleted: false
        },
        {
          stepNumber: 2,
          title: 'Khoét mui xe phong cách xe đua F1',
          description: 'Cắt một ô chữ nhật trên nóc tạo khoang lái mở rộng cá tính.',
          materialsNeeded: [],
          toolsNeeded: ['Kéo sắc'],
          highlightPart: 'body',
          isCompleted: false
        },
        {
          stepNumber: 3,
          title: 'Lắp ráp bánh nắp chai và hoàn thiện',
          description: 'Xỏ que tre qua thân, cố định 4 nắp chai ở hai đầu và chấm keo chặn bánh.',
          materialsNeeded: ['4 Nắp chai', 'Que tre'],
          toolsNeeded: ['Keo nến'],
          highlightPart: 'assembly',
          isCompleted: false
        }
      ]
    }
  ];

  return {
    ...geminiBase,
    engineUsed: 'dual',
    engineLabel: 'AI Song Mã (Gemini 3.8 + ChatGPT-4o)',
    recommendations: {
      group100Percent: [...geminiBase.recommendations.group100Percent, ...extraCrafts100],
      groupWithAddedMaterials: geminiBase.recommendations.groupWithAddedMaterials
    },
    aiInsight: '⚡ Hệ thống Song Mã: Gemini tính toán kích thước milimet chính xác tuyệt đối, ChatGPT bổ sung các ý tưởng chế tác đồ chơi STEM sáng tạo.'
  };
}

// Hàm sinh ảnh minh họa 3D mô phỏng và cấu trúc 3D cho sản phẩm chưa có ảnh
export async function generateCraft3DVisual(params: GenerateVisualInput): Promise<GenerateVisualResult> {
  const engine = params.aiEngine || 'gemini';
  const title = params.craftTitle;
  const material = params.materialName || 'nhựa tái chế';

  // Ánh xạ model3DType phù hợp dựa trên tiêu đề và danh mục
  const lowerTitle = title.toLowerCase();
  let chosenModel: CraftProduct['model3DType'] = 'pen_holder';

  if (lowerTitle.includes('xe') || lowerTitle.includes('car') || lowerTitle.includes('ô tô') || lowerTitle.includes('đồ chơi')) {
    chosenModel = 'toy_car';
  } else if (lowerTitle.includes('chậu') || lowerTitle.includes('cây') || lowerTitle.includes('hoa') || lowerTitle.includes('planter')) {
    chosenModel = 'planter';
  } else if (lowerTitle.includes('nhà') || lowerTitle.includes('house') || lowerTitle.includes('hộp') || lowerTitle.includes('carton')) {
    chosenModel = 'cardboard_house';
  } else if (lowerTitle.includes('đèn') || lowerTitle.includes('lamp') || lowerTitle.includes('lon') || lowerTitle.includes('nhôm')) {
    chosenModel = 'tin_lamp';
  } else if (lowerTitle.includes('kệ') || lowerTitle.includes('bàn') || lowerTitle.includes('organizer') || lowerTitle.includes('khay')) {
    chosenModel = 'desk_organizer';
  } else if (lowerTitle.includes('heo') || lowerTitle.includes('tiết kiệm') || lowerTitle.includes('piggy')) {
    chosenModel = 'bottle_piggy_bank';
  } else if (lowerTitle.includes('túi') || lowerTitle.includes('jean') || lowerTitle.includes('tote') || lowerTitle.includes('vải')) {
    chosenModel = 'fabric_tote';
  } else if (lowerTitle.includes('tranh') || lowerTitle.includes('khảm') || lowerTitle.includes('mosaic') || lowerTitle.includes('nắp')) {
    chosenModel = 'cap_mosaic';
  }

  // Tạo ảnh mô phỏng 3D isometric SVG chất lượng cao (HD Vector 3D Isometric Studio Mockup)
  const svg3DIsoMockup = generateIsometric3DSvg(title, material, chosenModel, engine);

  const stepsEnhanced: CraftStep[] = [
    {
      stepNumber: 1,
      title: `Chuẩn bị & đo vẽ ${title}`,
      description: `Định vị đường cắt và tỉ lệ trên vật liệu ${material} theo mô phỏng 3D isometric.`,
      materialsNeeded: [material],
      toolsNeeded: ['Thước kẻ', 'Bút lông đánh dấu'],
      highlightPart: 'cut_line',
      isCompleted: false
    },
    {
      stepNumber: 2,
      title: 'Tạo hình thân chính & các khớp nối',
      description: 'Cắt cẩn thận theo đường phác thảo, làm nhẵn các mép viền để đảm bảo an toàn tuyệt đối.',
      materialsNeeded: [],
      toolsNeeded: ['Kéo sắc', 'Giấy nhám'],
      highlightPart: 'body',
      safetyWarning: 'Luôn hướng lưỡi kéo ra ngoài cơ thể và kê tấm lót cắt chuyên dụng.',
      isCompleted: false
    },
    {
      stepNumber: 3,
      title: 'Lắp ráp chi tiết theo cấu trúc 3D',
      description: 'Khớp nối các bộ phận vào nhau theo đúng tọa độ mô hình 3D trong không gian.',
      materialsNeeded: ['Keo dán thủ công'],
      toolsNeeded: ['Súng keo nến hoặc keo sữa'],
      highlightPart: 'assembly',
      isCompleted: false
    },
    {
      stepNumber: 4,
      title: 'Hoàn thiện & trang trí thẩm mỹ',
      description: 'Vẽ hoa văn, phối màu hoặc gắn phụ kiện trang trí theo sở thích cá nhân.',
      materialsNeeded: ['Màu vẽ acrylic hoặc decal'],
      toolsNeeded: ['Cọ vẽ'],
      highlightPart: 'top',
      isCompleted: false
    }
  ];

  return {
    success: true,
    craftId: params.craftId,
    imageUrl: svg3DIsoMockup,
    model3DType: chosenModel,
    visualNotes: `${engine === 'gemini' ? 'Google Gemini AI' : 'ChatGPT-4o AI'} đã dựng thành công bản vẽ 3D Isometric mô phỏng chi tiết cho món đồ "${title}". Bạn có thể xem mô hình 3D xoay 360 độ ngay trong Xưởng chế tạo.`,
    engineUsed: engine,
    enhancedSteps: stepsEnhanced,
    dimensionsFinished: { lengthCm: 16, widthCm: 10, heightCm: 14 }
  };
}

// Hàm sinh SVG 3D Isometric Mockup trực quan
function generateIsometric3DSvg(title: string, material: string, modelType: string, engine: 'gemini' | 'chatgpt'): string {
  const isGemini = engine === 'gemini';
  const brandColor = isGemini ? '#10b981' : '#6366f1';
  const brandGradient = isGemini
    ? ['#059669', '#10b981', '#34d399']
    : ['#4f46e5', '#6366f1', '#818cf8'];

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="100%" stop-color="#1e293b" />
    </linearGradient>
    <linearGradient id="primaryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${brandGradient[0]}" />
      <stop offset="50%" stop-color="${brandGradient[1]}" />
      <stop offset="100%" stop-color="${brandGradient[2]}" />
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="12" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <!-- Background Studio -->
  <rect width="800" height="600" fill="url(#bgGrad)" />

  <!-- 3D Perspective Isometric Grid Ground -->
  <g opacity="0.25" stroke="#38bdf8" stroke-width="1.5">
    <path d="M 100 480 L 400 300 L 700 480" fill="none" />
    <path d="M 150 510 L 400 360 L 650 510" fill="none" />
    <path d="M 200 540 L 400 420 L 600 540" fill="none" />
    <path d="M 400 120 L 400 480" stroke-dasharray="6,6" />
    <line x1="200" y1="420" x2="600" y2="420" />
  </g>

  <!-- Circular Pedestal Platform -->
  <ellipse cx="400" cy="420" rx="220" ry="85" fill="#1e293b" stroke="${brandColor}" stroke-width="3" opacity="0.8" />
  <ellipse cx="400" cy="420" rx="180" ry="70" fill="url(#primaryGrad)" opacity="0.2" />

  <!-- 3D Geometric Isometric Object Representation -->
  <g transform="translate(400, 310)">
    <!-- Base Shadow -->
    <ellipse cx="0" cy="80" rx="110" ry="40" fill="#020617" opacity="0.6" filter="url(#glow)" />

    <!-- 3D Isometric Box/Cylinder Craft Simulation -->
    <!-- Top Face -->
    <polygon points="0,-120 120,-50 0,20 -120,-50" fill="url(#primaryGrad)" stroke="#ffffff" stroke-width="2" opacity="0.95" />
    <!-- Left Face -->
    <polygon points="-120,-50 0,20 0,110 -120,40" fill="${brandGradient[0]}" stroke="#ffffff" stroke-width="1.5" opacity="0.9" />
    <!-- Right Face -->
    <polygon points="0,20 120,-50 120,40 0,110" fill="${brandGradient[2]}" stroke="#ffffff" stroke-width="1.5" opacity="0.85" />

    <!-- Isometric Cut Line Guideline -->
    <path d="M -100, -10 L 0, 50 L 100, -10" fill="none" stroke="#facc15" stroke-width="3" stroke-dasharray="8,6" />

    <!-- 3D Coordinate Axis Indicators -->
    <g stroke="#ffffff" stroke-width="2" opacity="0.8">
      <line x1="0" y1="20" x2="0" y2="-170" stroke="#38bdf8" />
      <line x1="0" y1="20" x2="160" y2="100" stroke="#f43f5e" />
      <line x1="0" y1="20" x2="-160" y2="100" stroke="#10b981" />
    </g>

    <!-- Center 3D Tag -->
    <circle cx="0" cy="-30" r="26" fill="#0f172a" stroke="${brandColor}" stroke-width="3" />
    <text x="0" y="-23" font-family="system-ui, sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">3D</text>
  </g>

  <!-- Header Card Badge -->
  <rect x="30" y="30" width="340" height="74" rx="16" fill="#0f172a" stroke="${brandColor}" stroke-width="2" opacity="0.95" />
  <circle cx="65" cy="67" r="18" fill="url(#primaryGrad)" />
  <text x="65" y="73" font-family="system-ui, sans-serif" font-size="14" font-weight="900" fill="#ffffff" text-anchor="middle">AI</text>
  <text x="96" y="58" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#e2e8f0">${isGemini ? 'GOOGLE GEMINI 3D SIMULATOR' : 'OPENAI CHATGPT-4O 3D STUDIO'}</text>
  <text x="96" y="80" font-family="system-ui, sans-serif" font-size="12" fill="#94a3b8">Bản vẽ mô phỏng 3D đa hướng</text>

  <!-- Bottom Title Banner -->
  <rect x="30" y="500" width="740" height="70" rx="16" fill="#0f172a" stroke="#334155" stroke-width="1.5" opacity="0.95" />
  <text x="50" y="528" font-family="system-ui, sans-serif" font-size="16" font-weight="bold" fill="#ffffff">${title.replace(/"/g, '')}</text>
  <text x="50" y="552" font-family="system-ui, sans-serif" font-size="12" fill="${brandColor}">Vật liệu: ${material} • Mô hình 3D tương tác: ${modelType.toUpperCase()} (Hỗ trợ xoay 360° & bóc tách exploded view)</text>
</svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function normalizeProduct(p: any, index: number, defaultType: '100_percent_recycled' | 'with_added_materials'): CraftProduct {
  const modelOptions: CraftProduct['model3DType'][] = [
    'pen_holder', 'planter', 'cardboard_house', 'tin_lamp', 'desk_organizer', 'bottle_piggy_bank', 'toy_car', 'fabric_tote', 'cap_mosaic'
  ];
  const chosenModel = modelOptions.includes(p.model3DType) ? p.model3DType : 'pen_holder';

  return {
    id: p.id || `craft_${Date.now()}_${index}`,
    title: p.title || 'Món đồ tái chế sáng tạo',
    description: p.description || 'Sản phẩm tái chế hữu ích, dễ làm cho gia đình và góc học tập.',
    category: p.category || 'decor',
    categoryLabel: p.categoryLabel || 'Đồ trang trí',
    type: p.type || defaultType,
    imageUrl: p.imageUrl || generateIsometric3DSvg(p.title || 'Sản phẩm tái chế', 'vật liệu tái chế', chosenModel, 'gemini'),
    model3DType: chosenModel,
    difficulty: p.difficulty || 'Dễ',
    estimatedTime: p.estimatedTime || '30 phút',
    recycledMaterialRatio: p.recycledMaterialRatio || (defaultType === '100_percent_recycled' ? 100 : 75),
    materialsUsed: p.materialsUsed || [
      { name: 'Vật liệu tái chế chính', fromCurrentInventory: true, role: 'Cấu trúc chịu lực chính' }
    ],
    materialsNeededExtra: p.materialsNeededExtra || [],
    toolsRequired: p.toolsRequired || ['Kéo thủ công', 'Thước kẻ', 'Bút chì'],
    dimensionsFinished: p.dimensionsFinished || { lengthCm: 10, widthCm: 10, heightCm: 15 },
    whySuitable: p.whySuitable || 'Đặc tính vật liệu dẻo dai, kích thước vừa phải thích hợp chế tác.',
    guideStatus: 'completed',
    imageStatus: p.imageUrl ? 'completed' : 'pending',
    steps: (p.steps && p.steps.length > 0) ? p.steps : [
      {
        stepNumber: 1,
        title: 'Làm sạch và đánh dấu đường cắt',
        description: 'Vệ sinh vật liệu sạch sẽ, dùng thước và bút vẽ vị trí cần cắt theo kích thước thiết kế.',
        materialsNeeded: ['Vật liệu tái chế'],
        toolsNeeded: ['Bút chì', 'Thước kẻ'],
        isCompleted: false,
        highlightPart: 'cut_line'
      },
      {
        stepNumber: 2,
        title: 'Cắt tạo hình chi tiết',
        description: 'Dùng kéo hoặc dao cắt cẩn thận theo đường đã kẻ. Làm nhẵn các cạnh cắt.',
        materialsNeeded: [],
        toolsNeeded: ['Kéo sắc'],
        safetyWarning: 'Cẩn thận với lưỡi kéo sắc bén, luôn hướng lưỡi ra ngoài.',
        isCompleted: false,
        highlightPart: 'body'
      },
      {
        stepNumber: 3,
        title: 'Lắp ghép và hoàn thiện',
        description: 'Gắn các bộ phận vào nhau và trang trí thêm hoa văn theo sở thích.',
        materialsNeeded: [],
        toolsNeeded: ['Keo dán'],
        isCompleted: false,
        highlightPart: 'assembly'
      }
    ]
  };
}

export function generateDemoAnalysisResult(input: AnalysisInput): AnalysisResult {
  const notesLower = (input.userNotes || '').toLowerCase();
  const isBox = notesLower.includes('carton') || notesLower.includes('giấy') || notesLower.includes('hộp');

  if (isBox) {
    return {
      isDemoMode: true,
      engineUsed: input.aiEngine || 'gemini',
      engineLabel: input.aiEngine === 'chatgpt' ? 'OpenAI ChatGPT-4o' : 'Google Gemini 3.8 Flash',
      material: {
        id: 'mat_box_' + Date.now(),
        name: 'Hộp carton chuyển hàng 3 lớp Kraft',
        category: 'paper',
        categoryLabel: 'Rác thải giấy',
        recycleCode: 'PAP (Số 20 - Bìa gợn sóng)',
        images: input.images.length > 0 ? input.images : [
          'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=500&auto=format&fit=crop&q=80'
        ],
        status: 'safe_to_use',
        statusLabel: 'Có thể sử dụng',
        condition: 'Bìa carton khô ráo, không bị rách, không dính dầu mỡ thực phẩm.',
        color: 'Nâu nhạt Kraft',
        quantity: 1,
        unit: 'hộp',
        dimensions: {
          shapeType: 'box',
          lengthCm: 28,
          widthCm: 18,
          heightCm: 14,
          volumeMl: 7056,
          usableSurfaceCm2: 1800,
          totalSurfaceCm2: 2296,
          usableRatioPercent: 82,
        },
        cleaningInstructions: [
          'Gỡ sạch các lớp băng keo dính và tem bưu điện.',
          'Dùng khăn vải khô lau bụi mịn bề mặt.'
        ],
        safetyWarnings: [
          'Khi dùng dao rọc giấy, luôn kê thước kim loại và hướng dao ra ngoài bàn tay.'
        ],
        dateAdded: new Date().toISOString().split('T')[0]
      },
      geometryAnalysis: {
        shapeType: 'box',
        dimensionsFormula: 'V = a × b × c | S_tp = 2(ab + bc + ca)',
        volumeFormula: 'V = 28 × 18 × 14 = 7,056 cm³ (~7.05 L)',
        calculatedVolumeMl: 7056,
        calculatedSurfaceCm2: 2296,
        usableSurfaceCm2: 1880,
        wastedRatioPercent: 18,
        referenceScaleNote: input.referenceObject?.type !== 'none' 
          ? `Hiệu chuẩn chính xác dựa trên vật tham chiếu: ${input.referenceObject?.type}. Sai số < 3%.`
          : 'Dữ liệu kích thước ước lượng hình học qua phân tích tỷ lệ viền hộp.'
      },
      recommendations: {
        group100Percent: [
          {
            id: 'craft_cardboard_house',
            title: 'Mô Hình Ngôi Nhà Tiết Kiệm Tiền / Nhà Trang Trí',
            description: 'Tận dụng 100% bìa carton cắt ghép thành ngôi nhà mini có mái dốc ngói gân sóng tuyệt đẹp.',
            category: 'decor',
            categoryLabel: 'Đồ trang trí',
            type: '100_percent_recycled',
            imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&auto=format&fit=crop&q=80',
            model3DType: 'cardboard_house',
            difficulty: 'Trung bình',
            estimatedTime: '45 phút',
            recycledMaterialRatio: 100,
            materialsUsed: [
              { name: 'Bìa carton 3 lớp', fromCurrentInventory: true, role: 'Tường nhà, mái dốc, sàn' }
            ],
            materialsNeededExtra: [],
            toolsRequired: ['Dao rọc giấy', 'Thước kẻ sắt', 'Keo dán / súng keo nến'],
            dimensionsFinished: { lengthCm: 18, widthCm: 14, heightCm: 16 },
            whySuitable: 'Hộp carton có độ cứng cáp hoàn hảo để làm khung kết cấu nhà vững chãi.',
            imageStatus: 'completed',
            guideStatus: 'completed',
            steps: [
              {
                stepNumber: 1,
                title: 'Đo và vẽ các mặt tường & mái dốc',
                description: 'Vẽ 2 tấm tường hồi tam giác đỉnh nhọn, 2 tường bên chữ nhật và 2 cánh mái.',
                materialsNeeded: ['Bìa carton phẳng'],
                toolsNeeded: ['Thước kẻ', 'Bút chì'],
                dimensionsNotice: 'Chiều cao tường 10cm, mái tam giác cao thêm 6cm.',
                isCompleted: false,
                highlightPart: 'cut_line'
              },
              {
                stepNumber: 2,
                title: 'Rọc cửa sổ và trổ cửa chính',
                description: 'Khoét cửa sổ mái vòm và cửa chính mở gập tạo không gian 3 chiều.',
                materialsNeeded: [],
                toolsNeeded: ['Dao rọc giấy'],
                safetyWarning: 'Kê thớt hoặc tấm lót phía dưới trước khi rọc dao.',
                isCompleted: false,
                highlightPart: 'body'
              },
              {
                stepNumber: 3,
                title: 'Ráp nối 4 vách tường với đế',
                description: 'Gắn keo nến cố định 4 mặt tường vuông góc thành khối vững.',
                materialsNeeded: ['Keo nến'],
                toolsNeeded: ['Súng bắn keo'],
                isCompleted: false,
                highlightPart: 'assembly'
              },
              {
                stepNumber: 4,
                title: 'Gắn mái nhà và bóc lớp gân sóng',
                description: 'Bóc nhẹ 1 lớp giấy ngoài của cánh mái để lộ gân sóng giả làm ngói đỏ vintage.',
                materialsNeeded: [],
                toolsNeeded: [],
                isCompleted: false,
                highlightPart: 'top'
              }
            ]
          },
          {
            id: 'craft_desk_organizer',
            title: 'Kệ Bậc Thang Để Bàn 4 Ngăn Đa Năng',
            description: 'Kệ phân tầng sắp xếp bút, thước kẻ, sổ tay, tai nghe ngăn nắp sạch sẽ.',
            category: 'study',
            categoryLabel: 'Đồ dùng học tập',
            type: '100_percent_recycled',
            imageUrl: 'https://images.unsplash.com/photo-1586075010923-2dd4570fb338?w=800&auto=format&fit=crop&q=80',
            model3DType: 'desk_organizer',
            difficulty: 'Dễ',
            estimatedTime: '30 phút',
            recycledMaterialRatio: 100,
            materialsUsed: [
              { name: 'Vách carton', fromCurrentInventory: true, role: 'Các ngăn chia bậc thang' }
            ],
            materialsNeededExtra: [],
            toolsRequired: ['Kéo', 'Keo dán giấy'],
            dimensionsFinished: { lengthCm: 20, widthCm: 12, heightCm: 14 },
            whySuitable: 'Kích thước hộp 28x18cm đủ chia thành 4 tấm vách ngăn so le nhau.',
            imageStatus: 'completed',
            guideStatus: 'completed',
            steps: [
              {
                stepNumber: 1,
                title: 'Cắt 2 thanh hồi hình bậc thang',
                description: 'Vẽ bậc 1 cao 4cm, bậc 2 cao 8cm, bậc 3 cao 12cm.',
                materialsNeeded: ['Bìa carton'],
                toolsNeeded: ['Thước', 'Kéo'],
                isCompleted: false,
                highlightPart: 'cut_line'
              },
              {
                stepNumber: 2,
                title: 'Cắt vách ngăn ngang và đáy',
                description: 'Cắt 3 tấm vách rộng 12cm tương ứng với từng bậc.',
                materialsNeeded: [],
                toolsNeeded: ['Kéo'],
                isCompleted: false,
                highlightPart: 'body'
              },
              {
                stepNumber: 3,
                title: 'Dán cố định và kiểm tra độ chịu lực',
                description: 'Gắn keo đều mép nối, để khô 5 phút trước khi xếp đồ dùng lên.',
                materialsNeeded: ['Keo sữa hoặc keo nến'],
                toolsNeeded: [],
                isCompleted: false,
                highlightPart: 'assembly'
              }
            ]
          }
        ],
        groupWithAddedMaterials: [
          {
            id: 'craft_cardboard_led_theater',
            title: 'Rạp Chiếu Bóng Mini Kể Chuyện Cổ Tích Với Đèn LED',
            description: 'Hộp kịch bóng rối mini cho các em nhỏ, sử dụng giấy can trắng và đèn pin LED an toàn.',
            category: 'stem_toy',
            categoryLabel: 'Đồ chơi sáng tạo',
            type: 'with_added_materials',
            imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80',
            model3DType: 'cardboard_house',
            difficulty: 'Trung bình',
            estimatedTime: '50 phút',
            recycledMaterialRatio: 80,
            materialsUsed: [
              { name: 'Hộp carton', fromCurrentInventory: true, role: 'Khung rạp chiếu và que rối' }
            ],
            materialsNeededExtra: [
              { name: '1 tờ giấy can mỏng hoặc giấy nến', purpose: 'Làm màn chiếu bóng', estimatedCostVnd: 5000, isEcoFriendly: true },
              { name: 'Đèn LED pin 3V siêu sáng', purpose: 'Nguồn sáng phía sau', estimatedCostVnd: 15000, isEcoFriendly: true }
            ],
            toolsRequired: ['Dao rọc giấy', 'Băng dính hai mặt'],
            dimensionsFinished: { lengthCm: 25, widthCm: 16, heightCm: 14 },
            whySuitable: 'Hộp carton tạo hốc tối khép kín lý tưởng cho hiệu ứng đổ bóng sắc nét.',
            imageStatus: 'completed',
            guideStatus: 'completed',
            steps: [
              {
                stepNumber: 1,
                title: 'Khoét cửa sổ màn chiếu ở đáy hộp',
                description: 'Khoét một ô chữ nhật 18x12cm ở mặt trước hộp.',
                materialsNeeded: ['Hộp carton'],
                toolsNeeded: ['Dao rọc giấy'],
                isCompleted: false,
                highlightPart: 'cut_line'
              },
              {
                stepNumber: 2,
                title: 'Dán giấy can trắng làm màn ảnh',
                description: 'Dán căng phẳng tờ giấy nến trắng che kín ô cửa sổ vừa khoét.',
                materialsNeeded: ['Giấy can trắng'],
                toolsNeeded: ['Băng dính'],
                isCompleted: false,
                highlightPart: 'assembly'
              },
              {
                stepNumber: 3,
                title: 'Cắt các nhân vật rối bóng từ carton vụn',
                description: 'Tận dụng các miếng carton thừa cắt hình mặt trăng, chú thỏ, cây nấm gắn lên que.',
                materialsNeeded: ['Carton vụn'],
                toolsNeeded: ['Kéo'],
                isCompleted: false,
                highlightPart: 'body'
              },
              {
                stepNumber: 4,
                title: 'Đặt đèn LED 3V phía sau và trình diễn',
                description: 'Bật đèn LED ở phía sau màn, đưa rối bóng lại gần màn để biểu diễn.',
                materialsNeeded: ['Đèn LED pin 3V'],
                toolsNeeded: [],
                safetyWarning: 'Chỉ sử dụng đèn LED chạy pin 3V, không cắm nguồn điện trực tiếp 220V.',
                isCompleted: false,
                highlightPart: 'assembly'
              }
            ]
          }
        ]
      }
    };
  }

  // Default: Plastic bottle
  return {
    isDemoMode: true,
    engineUsed: input.aiEngine || 'gemini',
    engineLabel: input.aiEngine === 'chatgpt' ? 'OpenAI ChatGPT-4o' : 'Google Gemini 3.8 Flash',
    material: {
      id: 'mat_bottle_' + Date.now(),
      name: 'Chai nhựa đồ uống PET 500ml',
      category: 'plastic',
      categoryLabel: 'Rác thải nhựa',
      recycleCode: 'PET / PETE (Số 1)',
      images: input.images.length > 0 ? input.images : [
        'https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?w=500&auto=format&fit=crop&q=80'
      ],
      status: 'needs_cleaning',
      statusLabel: 'Cần làm sạch',
      condition: 'Vỏ chai trong suốt, còn nguyên vẹn, cần bóc nhãn và súc rửa cặn nước ngọt.',
      color: 'Trong suốt với nắp nhựa xanh dương',
      quantity: 1,
      unit: 'chai',
      dimensions: {
        shapeType: 'cylinder',
        lengthCm: 21,
        widthCm: 6.5,
        heightCm: 21,
        diameterCm: 6.5,
        volumeMl: 500,
        usableSurfaceCm2: 380,
        totalSurfaceCm2: 440,
        usableRatioPercent: 86,
      },
      cleaningInstructions: [
        'Ngâm nước ấm 40°C trong 5 phút để keo tem nhãn bong tự nhiên.',
        'Súc bên trong chai bằng nước xà phòng ấm, lắc đều và xả sạch.',
        'Dốc ngược chai lên khay ráo nước 15 phút trước khi cắt.'
      ],
      safetyWarnings: [
        'Thân chai hình trụ dễ lăn trượt, nên dùng băng dính đánh dấu vòng tròn trước khi cắt.',
        'Mép nhựa PET sau khi cắt có thể gây xước da nhẹ, nên dùng bàn ủi nhẹ viền hoặc dán băng dính viền.'
      ],
      dateAdded: new Date().toISOString().split('T')[0]
    },
    geometryAnalysis: {
      shapeType: 'cylinder',
      dimensionsFormula: 'V = π × r² × h | S_xq = 2πrh | S_tp = 2πr(r + h)',
      volumeFormula: 'V = 3.1416 × (3.25)² × 21 ≈ 696.8 cm³ (~500ml khoang chứa nước thực tế)',
      calculatedVolumeMl: 500,
      calculatedSurfaceCm2: 440,
      usableSurfaceCm2: 380,
      wastedRatioPercent: 14,
      referenceScaleNote: input.referenceObject?.type !== 'none'
        ? `Đo chuẩn xác theo vật tham chiếu: ${input.referenceObject?.type}.`
        : 'Tỷ lệ hình học được đối chiếu với tiêu chuẩn vỏ chai đóng chai 500ml ISO quốc tế.'
    },
    recommendations: {
      group100Percent: [
        {
          id: 'craft_self_watering_planter',
          title: 'Chậu Cây Tự Hút Nước Bấc Vải Thông Minh',
          description: 'Hệ thống thủy canh bán phần tận dụng 100% hai nửa chai nhựa và nắp chai để cấp ẩm tự động cho rễ cây.',
          category: 'garden',
          categoryLabel: 'Sản phẩm làm vườn',
          type: '100_percent_recycled',
          imageUrl: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800&auto=format&fit=crop&q=80',
          model3DType: 'planter',
          difficulty: 'Dễ',
          estimatedTime: '20 phút',
          recycledMaterialRatio: 100,
          materialsUsed: [
            { name: 'Chai nhựa PET 500ml', fromCurrentInventory: true, role: 'Đế trữ nước và phễu trồng đất' },
            { name: 'Nắp chai', fromCurrentInventory: true, role: 'Khóa giữ tim bấc cotton' }
          ],
          materialsNeededExtra: [],
          toolsRequired: ['Kéo thủ công', 'Dùi lỗ nhỏ'],
          dimensionsFinished: { lengthCm: 6.5, widthCm: 6.5, heightCm: 14 },
          whySuitable: 'Chai nhựa chống thấm tuyệt đối, không nứt vỡ, độ trong suốt giúp kiểm tra mực nước bên dưới dễ dàng.',
          imageStatus: 'completed',
          guideStatus: 'completed',
          steps: [
            {
              stepNumber: 1,
              title: 'Cắt thân chai ở vị trí 1/3 từ trên xuống',
              description: 'Dán 1 vòng băng keo cách miệng chai 9cm làm dưỡng thẳng, dùng kéo cắt dọc theo mép.',
              materialsNeeded: ['Chai nhựa PET đã làm sạch'],
              toolsNeeded: ['Kéo thủ công', 'Băng dính'],
              dimensionsNotice: 'Chiều cao phần phễu 9cm, chiều cao phần đế 12cm.',
              isCompleted: false,
              highlightPart: 'cut_line'
            },
            {
              stepNumber: 2,
              title: 'Đục lỗ nắp và luồn bấc dẫn nước',
              description: 'Khoét 1 lỗ 4mm ở tâm nắp chai. Luồn dây bấc vải cotton (từ vải áo cũ) qua nắp.',
              materialsNeeded: ['Nắp chai', 'Đoạn dây vải cũ 15cm'],
              toolsNeeded: ['Dùi nhọn'],
              safetyWarning: 'Cẩn thận khi dùi nhựa cứng, không dùng lực đột ngột.',
              isCompleted: false,
              highlightPart: 'assembly'
            },
            {
              stepNumber: 3,
              title: 'Úp ngược phễu vào đế chai chứa nước',
              description: 'Vặn nắp lại, lộn ngược phần đầu chai đặt lọt vào phần đáy. Đổ nước sạch vào nửa dưới.',
              materialsNeeded: [],
              toolsNeeded: [],
              isCompleted: false,
              highlightPart: 'assembly'
            },
            {
              stepNumber: 4,
              title: 'Cho đất và trồng mầm cây xanh',
              description: 'Rải vài viên sỏi nhỏ quanh miệng nắp để đất không lọt xuống, cho đất và trồng cây.',
              materialsNeeded: ['Đất trồng', 'Cây cảnh con'],
              toolsNeeded: [],
              isCompleted: false,
              highlightPart: 'body'
            }
          ]
        },
        {
          id: 'craft_toy_car_racing',
          title: 'Xe Đồ Chơi Bánh Nắp Chai Tái Chế 100%',
          description: 'Xe bốn bánh làm hoàn toàn từ thân chai nhựa và 4 nắp chai, chạy siêu trơn tru.',
          category: 'stem_toy',
          categoryLabel: 'Đồ chơi STEM',
          type: '100_percent_recycled',
          imageUrl: 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=800&auto=format&fit=crop&q=80',
          model3DType: 'toy_car',
          difficulty: 'Dễ',
          estimatedTime: '25 phút',
          recycledMaterialRatio: 100,
          materialsUsed: [
            { name: 'Thân chai PET nằm ngang', fromCurrentInventory: true, role: 'Khung gầm thân xe' },
            { name: '4 Nắp chai', fromCurrentInventory: true, role: '4 Bánh xe lăn' }
          ],
          materialsNeededExtra: [],
          toolsRequired: ['Kéo thủ công', 'Que tăm tre', 'Súng keo nến'],
          dimensionsFinished: { lengthCm: 16, widthCm: 8, heightCm: 7 },
          whySuitable: 'Hình dáng chai nằm ngang làm thân xe rất vững, nắp chai đường kính 28mm lăn nhẹ.',
          imageStatus: 'completed',
          guideStatus: 'completed',
          steps: [
            {
              stepNumber: 1,
              title: 'Dùi 4 lỗ đối xứng làm trục bánh xe',
              description: 'Dùi 2 lỗ xuyên qua thân chai phía trước và 2 lỗ phía sau cách nhau 10cm.',
              materialsNeeded: ['Thân chai PET'],
              toolsNeeded: ['Dùi nhọn'],
              highlightPart: 'cut_line',
              isCompleted: false
            },
            {
              stepNumber: 2,
              title: 'Cắt mui xe và ghế lái',
              description: 'Khoét một ô chữ nhật phía trên lưng chai gập ngược vào trong làm ghế lái xe.',
              materialsNeeded: [],
              toolsNeeded: ['Dao rọc giấy'],
              highlightPart: 'body',
              isCompleted: false
            },
            {
              stepNumber: 3,
              title: 'Lắp que tăm và gắn 4 bánh nắp chai',
              description: 'Xỏ 2 đoạn tăm tre qua lỗ, đục tâm nắp chai và cố định bằng giọt keo nến.',
              materialsNeeded: ['4 Nắp chai', 'Que tăm tre'],
              toolsNeeded: ['Keo nến'],
              highlightPart: 'assembly',
              isCompleted: false
            }
          ]
        },
        {
          id: 'craft_pen_organizer',
          title: 'Hộp Đựng Bút & Dụng Cụ Bàn Học Tai Mèo Xinh Xắn',
          description: 'Cắt thân chai uốn lượn hình đôi tai mèo đáng yêu, mài nhẵn viền và vẽ trang trí mặt mèo.',
          category: 'study',
          categoryLabel: 'Đồ dùng học tập',
          type: '100_percent_recycled',
          imageUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?w=800&auto=format&fit=crop&q=80',
          model3DType: 'pen_holder',
          difficulty: 'Dễ',
          estimatedTime: '25 phút',
          recycledMaterialRatio: 100,
          materialsUsed: [
            { name: 'Nửa thân dưới chai PET', fromCurrentInventory: true, role: 'Ống cắm bút' }
          ],
          materialsNeededExtra: [],
          toolsRequired: ['Kéo thủ công', 'Bút dạ dầu'],
          dimensionsFinished: { lengthCm: 6.5, widthCm: 6.5, heightCm: 11 },
          whySuitable: 'Đáy chai PET 5 khía chân rất vững chãi khi để trên mặt bàn phẳng.',
          imageStatus: 'completed',
          guideStatus: 'completed',
          steps: [
            {
              stepNumber: 1,
              title: 'Vẽ phác thảo hai tai mèo trên thân chai',
              description: 'Dùng bút dạ vẽ đường viền cao 10cm với 2 chóp tai tam giác nhô lên 2cm.',
              materialsNeeded: ['Chai nhựa sạch'],
              toolsNeeded: ['Bút lông dầu'],
              isCompleted: false,
              highlightPart: 'cut_line'
            },
            {
              stepNumber: 2,
              title: 'Cắt theo đường viền tai mèo',
              description: 'Dùng kéo cắt lượn theo đường vẽ, bo tròn các góc nhọn để không gây trầy xước.',
              materialsNeeded: [],
              toolsNeeded: ['Kéo sắc'],
              safetyWarning: 'Dùng mép bàn ủi nóng nhẹ 2 giây lên viền miệng để nhựa cuộn mịn.',
              isCompleted: false,
              highlightPart: 'body'
            },
            {
              stepNumber: 3,
              title: 'Vẽ mắt mũi râu mèo ngộ nghĩnh',
              description: 'Vẽ mắt nhắm, mũi hồng và 6 sợi râu mèo đáng yêu lên mặt trước.',
              materialsNeeded: [],
              toolsNeeded: ['Bút vẽ màu'],
              isCompleted: false,
              highlightPart: 'body'
            }
          ]
        }
      ],
      groupWithAddedMaterials: [
        {
          id: 'craft_led_glow_lamp',
          title: 'Đèn Bàn Ngủ Đom Đóm Phát Sáng Từ Chai Nhựa & Hạt Sỏi',
          description: 'Kết hợp chai nhựa trong suốt với sỏi thủy tinh tán sắc và chuỗi dây đèn LED pin nhỏ tạo nên ngọn đèn ngủ lung linh.',
          category: 'decor',
          categoryLabel: 'Đồ trang trí',
          type: 'with_added_materials',
          imageUrl: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&auto=format&fit=crop&q=80',
          model3DType: 'tin_lamp',
          difficulty: 'Dễ',
          estimatedTime: '15 phút',
          recycledMaterialRatio: 85,
          materialsUsed: [
            { name: 'Vỏ chai PET trong suốt', fromCurrentInventory: true, role: 'Chụp đèn khuếch tán ánh sáng' }
          ],
          materialsNeededExtra: [
            { name: 'Chuỗi dây đèn LED đom đóm chạy pin nút áo 3V', purpose: 'Nguồn sáng an toàn, không sinh nhiệt', estimatedCostVnd: 15000, isEcoFriendly: true },
            { name: 'Một nắm sỏi trắng sạch', purpose: 'Giữ thăng bằng đáy chai', estimatedCostVnd: 5000, isEcoFriendly: true }
          ],
          toolsRequired: ['Không cần dụng cụ phức tạp'],
          dimensionsFinished: { lengthCm: 6.5, widthCm: 6.5, heightCm: 21 },
          whySuitable: 'Nhựa PET trong suốt tán quang ánh sáng đom đóm huyền ảo trong bóng tối.',
          imageStatus: 'completed',
          guideStatus: 'completed',
          steps: [
            {
              stepNumber: 1,
              title: 'Lau khô tuyệt đối bên trong lòng chai',
              description: 'Đảm bảo bên trong không còn giọt nước nào để bảo vệ mạch đèn LED.',
              materialsNeeded: ['Chai nhựa'],
              toolsNeeded: ['Khăn giấy khô'],
              isCompleted: false,
              highlightPart: 'body'
            },
            {
              stepNumber: 2,
              title: 'Cho sỏi trắng sạch vào đáy',
              description: 'Thả nhẹ từng viên sỏi nhỏ xuống đáy tạo lớp đệm dày 3cm chống đổ chai.',
              materialsNeeded: ['Sỏi trắng'],
              toolsNeeded: [],
              isCompleted: false,
              highlightPart: 'bottom'
            },
            {
              stepNumber: 3,
              title: 'Luồn chuỗi LED và gắn công tắc vào nắp',
              description: 'Thả cuộn dây LED uốn lượn vào trong lòng chai, cố định hộp pin nhỏ dưới nắp chai.',
              materialsNeeded: ['Dây đèn LED 3V'],
              toolsNeeded: [],
              safetyWarning: 'Tuyệt đối chỉ dùng pin 3V hoặc dây USB 5V. Không dùng nguồn điện trực tiếp.',
              isCompleted: false,
              highlightPart: 'assembly'
            }
          ]
        }
      ]
    }
  };
}
