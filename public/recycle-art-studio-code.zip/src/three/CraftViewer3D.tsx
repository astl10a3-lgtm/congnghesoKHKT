import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import {
  Pause,
  Play,
  RotateCcw,
  Sliders,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Sparkles,
  Download,
  Info,
  X,
  Layers,
  Wrench,
  ShieldAlert,
  Compass,
  CheckCircle2,
  Split,
  RefreshCw,
  Camera,
  Sun,
  Lightbulb,
  Check,
  Palette,
  Heart
} from 'lucide-react';
import { CraftProduct, CraftStep } from '../../server/db';
import {
  createRecycledPETMaterial,
  createHandCutLipMaterial,
  createHDPECapMaterial,
  createHotGlueMaterial,
  createBambooAxleMaterial,
  createPottingSoilMaterial,
  createKraftCardboardMaterial,
  createBrushedAluminumMaterial,
} from './photorealisticMaterials';
import {
  getContactShadowTexture,
  getWorkshopWoodFloorTexture,
} from './photorealisticTextures';

interface CraftViewer3DProps {
  craft: CraftProduct;
  currentStepIndex: number;
  onStepChange?: (index: number) => void;
  height?: string;
}

interface ComponentHotspot {
  id: string;
  name: string;
  material: string;
  role: string;
  howToMake: string;
  safetyNotice: string;
  position: THREE.Vector3;
}

export type StudioBackdrop = 'studio_white' | 'workshop_wood' | 'studio_dark';
export type LightingMode = 'soft_studio' | 'natural_sun' | 'dramatic_rim';

export const CraftViewer3D: React.FC<CraftViewer3DProps> = ({
  craft,
  currentStepIndex,
  onStepChange,
  height = '480px',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [explodedFactor, setExplodedFactor] = useState(0);
  const [isSimulating, setIsSimulating] = useState(false);
  const [isAutoRotating, setIsAutoRotating] = useState(false);
  const [isZenMode, setIsZenMode] = useState(false);
  const [selectedHotspot, setSelectedHotspot] = useState<ComponentHotspot | null>(null);
  const [exportingGlb, setExportingGlb] = useState(false);

  // Photorealistic Studio Controls
  const [studioBackdrop, setStudioBackdrop] = useState<StudioBackdrop>('studio_white');
  const [lightingMode, setLightingMode] = useState<LightingMode>('soft_studio');
  const [isSnapshotting, setIsSnapshotting] = useState(false);
  const [snapshotToast, setSnapshotToast] = useState<string | null>(null);
  const [showDecorations, setShowDecorations] = useState(true);

  const safeSteps: CraftStep[] =
    craft.steps && craft.steps.length > 0
      ? craft.steps
      : [
          {
            stepNumber: 1,
            title: 'Mô hình tổng quan sản phẩm',
            description: 'Mô hình 3D hoàn chỉnh được dựng từ vật liệu tái chế thực tế.',
            materialsNeeded: craft.materialsUsed?.map((m) => m.name) || ['Vật liệu tái chế'],
            toolsNeeded: craft.toolsRequired || ['Kéo thủ công'],
            highlightPart: 'body',
          },
        ];

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const craftGroupRef = useRef<THREE.Group | null>(null);
  const hotspotGroupRef = useRef<THREE.Group | null>(null);
  const groundMeshRef = useRef<THREE.Mesh | null>(null);
  const contactShadowRef = useRef<THREE.Mesh | null>(null);
  const animFrameRef = useRef<number>(0);
  const simulationTimerRef = useRef<NodeJS.Timeout | null>(null);
  const targetCamPosRef = useRef<THREE.Vector3 | null>(null);

  // Studio Lights References
  const keyLightRef = useRef<THREE.DirectionalLight | null>(null);
  const fillLightRef = useRef<THREE.DirectionalLight | null>(null);
  const rimLightRef = useRef<THREE.DirectionalLight | null>(null);
  const hemiLightRef = useRef<THREE.HemisphereLight | null>(null);

  // Subparts array for exploded view animations
  const subpartsRef = useRef<{ mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[]>([]);

  // Simulation autoplay
  useEffect(() => {
    if (isSimulating) {
      simulationTimerRef.current = setInterval(() => {
        const nextStep = (currentStepIndex + 1) % safeSteps.length;
        if (onStepChange) onStepChange(nextStep);
        if (nextStep === 0) {
          setIsSimulating(false);
        }
      }, 3500);
    } else {
      if (simulationTimerRef.current) clearInterval(simulationTimerRef.current);
    }
    return () => {
      if (simulationTimerRef.current) clearInterval(simulationTimerRef.current);
    };
  }, [isSimulating, currentStepIndex, safeSteps.length, onStepChange]);

  // Main Scene Initialization with Photorealistic PBR & Studio Lighting
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL guard
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0xf8fafc); // Default clean studio white
    scene.fog = new THREE.FogExp2(0xf8fafc, 0.025);

    // 2. Camera: slightly lower focal length (42mm equivalent) for authentic product photography
    const camera = new THREE.PerspectiveCamera(
      42,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(3.4, 2.4, 4.2);
    cameraRef.current = camera;

    // 3. Renderer with ACES Filmic tone mapping for rich photorealistic dynamic range
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true, // Required for HD studio snapshot download
    });
    rendererRef.current = renderer;
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18; // Calibrated for translucent plastics
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.touchAction = 'none';

    container.appendChild(renderer.domElement);

    // 4. Studio Environment map via RoomEnvironment for realistic specular reflections
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. OrbitControls - Allow unrestricted 360-degree rotation vertically & horizontally
    const controls = new OrbitControls(camera, renderer.domElement);
    controlsRef.current = controls;
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    // Allow full 360-degree orbit around the model (both horizontally and vertically)
    controls.maxPolarAngle = Math.PI - 0.05; // Full bottom orbit
    controls.minPolarAngle = 0.05; // Full top orbit
    controls.minDistance = 0.8;
    controls.maxDistance = 14;
    controls.target.set(0, 0.85, 0);
    // Explicit touch gestures for mobile screens
    controls.touches = {
      ONE: THREE.TOUCH.ROTATE,
      TWO: THREE.TOUCH.DOLLY_PAN,
    };

    // 6. Balanced Studio 3-Point Photography Lighting Rig
    // Hemisphere ambient fill
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0xcfe2ff, 0.65);
    hemiLightRef.current = hemiLight;
    scene.add(hemiLight);

    // Key Light (Main soft directional sun with 2048x2048 soft shadow map)
    const keyLight = new THREE.DirectionalLight(0xfff7ed, 2.2);
    keyLight.position.set(4.5, 7.5, 3.5);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.bias = -0.0001;
    keyLight.shadow.normalBias = 0.02;
    keyLight.shadow.radius = 3.5; // Soft penumbra for realistic studio shadow
    keyLightRef.current = keyLight;
    scene.add(keyLight);

    // Fill Light (Soft cool fill light to prevent black voids in plastic folds)
    const fillLight = new THREE.DirectionalLight(0xcfd8dc, 0.85);
    fillLight.position.set(-3.5, 3.8, 2.5);
    fillLightRef.current = fillLight;
    scene.add(fillLight);

    // Rim / Back Light (Crucial for photorealism: catches bevels, cut edges, and translucent plastic walls)
    const rimLight = new THREE.DirectionalLight(0xffffff, 2.5);
    rimLight.position.set(-2.5, 5.0, -4.5);
    rimLightRef.current = rimLight;
    scene.add(rimLight);

    // Ground bounce underfill
    const underFill = new THREE.DirectionalLight(0xf8fafc, 0.35);
    underFill.position.set(0, -2, 0);
    scene.add(underFill);

    // 7. Ground Studio Floor Mesh
    const groundGeo = new THREE.PlaneGeometry(16, 16);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.85,
      metalness: 0.02,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;
    ground.receiveShadow = !isSoftwareGl;
    groundMeshRef.current = ground;
    scene.add(ground);

    // 8. Contact Shadow Ground Disc (Firmly anchors the product to the studio floor with natural AO)
    const contactShadowTex = getContactShadowTexture();
    const contactGeo = new THREE.PlaneGeometry(3.6, 3.6);
    const contactMat = new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    const contactShadowMesh = new THREE.Mesh(contactGeo, contactMat);
    contactShadowMesh.rotation.x = -Math.PI / 2;
    contactShadowMesh.position.y = 0.002;
    contactShadowRef.current = contactShadowMesh;
    scene.add(contactShadowMesh);

    // 9. Craft Group & Hotspot Markers
    const craftGroup = new THREE.Group();
    craftGroup.name = 'craft_root';
    craftGroupRef.current = craftGroup;
    scene.add(craftGroup);

    const hotspotGroup = new THREE.Group();
    hotspotGroupRef.current = hotspotGroup;
    scene.add(hotspotGroup);

    subpartsRef.current = [];
    buildPhotorealisticCraftMesh(craftGroup, craft, subpartsRef.current, showDecorations);
    buildInteractiveHotspots(hotspotGroup, craft);

    // 10. Animation Render Loop
    let clock = new THREE.Clock();
    const animate = () => {
      const time = clock.getElapsedTime();

      // Camera smooth lerp
      if (targetCamPosRef.current && cameraRef.current && controlsRef.current) {
        cameraRef.current.position.lerp(targetCamPosRef.current, 0.08);
        if (cameraRef.current.position.distanceTo(targetCamPosRef.current) < 0.02) {
          targetCamPosRef.current = null;
        }
      }

      // Hotspot markers subtle breathing
      if (hotspotGroupRef.current) {
        hotspotGroupRef.current.children.forEach((hp, idx) => {
          const scale = 1.0 + Math.sin(time * 3 + idx) * 0.12;
          hp.scale.set(scale, scale, scale);
        });
      }

      // Hide floor when camera dips below so the entire 360 bottom of the craft is clearly visible
      if (groundMeshRef.current && cameraRef.current) {
        groundMeshRef.current.visible = cameraRef.current.position.y > 0.05;
      }

      controls.update();
      renderer.render(scene, camera);
      animFrameRef.current = requestAnimationFrame(animate);
    };
    animate();

    // 11. Resize Observer
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    const ro = new ResizeObserver(handleResize);
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animFrameRef.current);
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, [craft]);

  // Update Studio Backdrop (White Studio / Wood Workshop / Dark Studio)
  useEffect(() => {
    if (!sceneRef.current || !groundMeshRef.current) return;
    const scene = sceneRef.current;
    const ground = groundMeshRef.current;

    if (studioBackdrop === 'studio_white') {
      const col = new THREE.Color(0xf8fafc);
      scene.background = col;
      scene.fog = new THREE.FogExp2(0xf8fafc, 0.025);
      ground.material = new THREE.MeshStandardMaterial({
        color: 0xf1f5f9,
        roughness: 0.85,
        metalness: 0.02,
      });
    } else if (studioBackdrop === 'workshop_wood') {
      const col = new THREE.Color(0xf5ebe0);
      scene.background = col;
      scene.fog = new THREE.FogExp2(0xf5ebe0, 0.025);
      const woodTex = getWorkshopWoodFloorTexture();
      ground.material = new THREE.MeshStandardMaterial({
        map: woodTex,
        roughness: 0.75,
        metalness: 0.05,
      });
    } else if (studioBackdrop === 'studio_dark') {
      const col = new THREE.Color(0x0f172a); // Deep slate charcoal
      scene.background = col;
      scene.fog = new THREE.FogExp2(0x0f172a, 0.035);
      ground.material = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        roughness: 0.65,
        metalness: 0.2,
      });
    }
  }, [studioBackdrop]);

  // Update Studio Lighting Mode (Soft Studio / Natural Sun / Dramatic Rim)
  useEffect(() => {
    if (!keyLightRef.current || !fillLightRef.current || !rimLightRef.current || !hemiLightRef.current) return;

    if (lightingMode === 'soft_studio') {
      keyLightRef.current.color.setHex(0xfff7ed);
      keyLightRef.current.intensity = 2.2;
      fillLightRef.current.color.setHex(0xcfd8dc);
      fillLightRef.current.intensity = 0.85;
      rimLightRef.current.color.setHex(0xffffff);
      rimLightRef.current.intensity = 2.5;
      hemiLightRef.current.intensity = 0.65;
    } else if (lightingMode === 'natural_sun') {
      keyLightRef.current.color.setHex(0xfffbeb);
      keyLightRef.current.intensity = 2.8;
      fillLightRef.current.color.setHex(0xbbf7d0);
      fillLightRef.current.intensity = 0.6;
      rimLightRef.current.color.setHex(0xffedd5);
      rimLightRef.current.intensity = 1.8;
      hemiLightRef.current.intensity = 0.8;
    } else if (lightingMode === 'dramatic_rim') {
      keyLightRef.current.color.setHex(0xffffff);
      keyLightRef.current.intensity = 1.4;
      fillLightRef.current.color.setHex(0x38bdf8);
      fillLightRef.current.intensity = 0.5;
      rimLightRef.current.color.setHex(0x34d399);
      rimLightRef.current.intensity = 3.6; // High intensity edge pop
      hemiLightRef.current.intensity = 0.4;
    }
  }, [lightingMode]);

  // Synchronize Active Step Visuals (highlight cut lines or target parts)
  useEffect(() => {
    if (!craftGroupRef.current) return;
    const currentStep = safeSteps[currentStepIndex];
    const highlightTarget = currentStep?.highlightPart || 'body';

    craftGroupRef.current.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        const partName = mesh.name || '';

        // If mesh is the cut guide line
        if (partName === 'cut_guide_line') {
          mesh.visible = currentStepIndex === 0 || highlightTarget === 'cut_line';
        }

        // Highlight active part with gentle emission (ONLY for materials that natively support emissive)
        if (mesh.material && !Array.isArray(mesh.material)) {
          const mat = mesh.material as any;
          if (mat && ('isMeshStandardMaterial' in mat || 'isMeshPhysicalMaterial' in mat || 'isMeshPhongMaterial' in mat)) {
            if (mat.emissive) {
              if (partName.includes(highlightTarget) && highlightTarget !== 'all') {
                mat.emissive.setHex(0x10b981);
                mat.emissiveIntensity = 0.22;
              } else {
                mat.emissive.setHex(0x000000);
                mat.emissiveIntensity = 0;
              }
            }
          }
        }
      }
    });
  }, [currentStepIndex, craft, safeSteps]);

  // Apply Exploded View: Elevate entire craft into mid-air so users can inspect all parts without floor collision
  useEffect(() => {
    // 1. Lift entire craft group into mid-air proportional to explodedFactor
    if (craftGroupRef.current) {
      craftGroupRef.current.position.y = explodedFactor * 1.15;
    }

    // 2. Adjust camera orbit pivot to focus naturally on the floating constellation
    if (controlsRef.current) {
      controlsRef.current.target.y = 0.85 + explodedFactor * 0.75;
    }

    // 3. Naturally fade the ground contact shadow as the object floats up into the air
    if (contactShadowRef.current && contactShadowRef.current.material) {
      const mat = contactShadowRef.current.material as THREE.MeshBasicMaterial;
      mat.opacity = Math.max(0, 0.65 * (1 - explodedFactor * 1.25));
    }

    // 4. Spread individual components outward along their explosion vectors
    subpartsRef.current.forEach((item) => {
      const offset = item.explodeDir.clone().multiplyScalar(explodedFactor * 1.6);
      item.mesh.position.copy(item.basePos.clone().add(offset));
    });
  }, [explodedFactor]);

  // Synchronize Cute Decorative Elements Visibility
  useEffect(() => {
    if (!craftGroupRef.current) return;
    craftGroupRef.current.traverse((child) => {
      if (child.name === 'decorations' || child.userData?.isDecoration) {
        child.visible = showDecorations;
      }
    });
  }, [showDecorations]);

  // Auto-rotate effect
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = isAutoRotating;
      controlsRef.current.autoRotateSpeed = 2.0;
    }
  }, [isAutoRotating]);

  // Handle Hotspot Raycast Click on 3D Viewport
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mountRef.current || !cameraRef.current || !hotspotGroupRef.current) return;

    const rect = mountRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const intersects = raycaster.intersectObjects(hotspotGroupRef.current.children, true);
    if (intersects.length > 0) {
      const topObj = intersects[0].object;
      const data = topObj.userData as ComponentHotspot;
      if (data && data.name) {
        setSelectedHotspot(data);
      }
    }
  };

  // Camera presets transitions
  const setCameraAngle = (angle: 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom' | 'iso') => {
    if (!controlsRef.current) return;
    const targetY = 0.85 + explodedFactor * 0.75;
    const dist = 5.0 + explodedFactor * 0.6;
    controlsRef.current.target.set(0, targetY, 0);

    const positions: Record<string, THREE.Vector3> = {
      front: new THREE.Vector3(0, targetY, dist),
      back: new THREE.Vector3(0, targetY, -dist),
      left: new THREE.Vector3(-dist, targetY, 0),
      right: new THREE.Vector3(dist, targetY, 0),
      top: new THREE.Vector3(0, targetY + dist * 1.35, 0.001),
      bottom: new THREE.Vector3(0, Math.max(0.2, targetY - dist * 0.95), 0.001),
      iso: new THREE.Vector3(3.4, targetY + 1.55, 4.2),
    };

    targetCamPosRef.current = positions[angle] || positions.iso;
  };

  // Animate explode view quickly to 100% or 0%
  const animateExplodeTo = (targetVal: number) => {
    const startVal = explodedFactor;
    const startTime = performance.now();
    const duration = 500;

    const stepAnim = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      const eased = progress < 0.5 ? 2 * progress * progress : -1 + (4 - 2 * progress) * progress;
      const current = startVal + (targetVal - startVal) * eased;
      setExplodedFactor(current);

      if (progress < 1) {
        requestAnimationFrame(stepAnim);
      }
    };
    requestAnimationFrame(stepAnim);
  };

  // Capture High-Res Photorealistic Product Studio Snapshot
  const handleTakeSnapshot = () => {
    if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;
    setIsSnapshotting(true);

    try {
      // Re-render synchronously right before reading canvas
      rendererRef.current.render(sceneRef.current, cameraRef.current);
      const dataUrl = rendererRef.current.domElement.toDataURL('image/png', 1.0);

      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `${craft.title.toLowerCase().replace(/[\s/]/g, '_')}_photorealistic_3d.png`;
      link.click();

      setSnapshotToast('Đã tải ảnh chụp 3D Studio chất lượng cao!');
      setTimeout(() => setSnapshotToast(null), 3000);
    } catch (e) {
      console.warn('Snapshot error:', e);
    } finally {
      setIsSnapshotting(false);
    }
  };

  // GLTF/GLB Export
  const handleExportGLB = () => {
    if (!craftGroupRef.current) return;
    setExportingGlb(true);

    const exporter = new GLTFExporter();
    exporter.parse(
      craftGroupRef.current,
      (gltf) => {
        const blob = new Blob([gltf as ArrayBuffer], { type: 'application/octet-stream' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${craft.title.toLowerCase().replace(/[\s/]/g, '_')}_photoreal3d.glb`;
        link.click();
        URL.revokeObjectURL(link.href);
        setExportingGlb(false);
      },
      (error) => {
        console.error('An error happened while exporting GLB:', error);
        setExportingGlb(false);
      },
      { binary: true }
    );
  };

  const activeStep = safeSteps[currentStepIndex] || safeSteps[0];

  return (
    <div className="w-full space-y-3">
      <div
        className={`relative w-full rounded-3xl overflow-hidden bg-slate-50 border border-slate-200/90 shadow-lg transition-all ${
          isZenMode ? 'fixed inset-0 z-50 rounded-none h-screen w-screen' : ''
        }`}
        style={{ height: isZenMode ? '100vh' : height }}
      >
      {/* 3D Canvas Mount Point */}
      <div
        ref={mountRef}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-grab active:cursor-grabbing touch-none select-none"
        style={{ touchAction: 'none' }}
      />

      {/* Floating 360 Rotation Guide Badge */}
      <div className="absolute top-16 left-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-xl shadow-xs border border-slate-200 text-[10px] text-slate-600 font-medium pointer-events-none flex items-center gap-1.5 z-10">
        <Compass className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
        <span>Vuốt tay / kéo chuột để xoay 360° tự do</span>
      </div>

      {/* Top Left Step Indicator & Realistic PBR Badge */}
      <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none max-w-sm z-10">
        <div className="flex items-center gap-2 bg-white/95 backdrop-blur-md px-3.5 py-1.5 rounded-2xl shadow-sm border border-emerald-100 text-xs font-bold text-emerald-900">
          <Sparkles className="w-4 h-4 text-emerald-600" />
          <span>
            Bước {activeStep.stepNumber} / {safeSteps.length}: {activeStep.title}
          </span>
        </div>
        <div className="bg-slate-900/90 backdrop-blur-md text-white text-[11px] px-3 py-1 rounded-xl shadow-md flex items-center justify-between gap-3">
          <span className="text-emerald-400 font-bold flex items-center gap-1">
            <span>✨ Photorealistic 3D PBR</span>
          </span>
          <span className="text-slate-300 text-[10px]">
            Nhựa tái chế thực tế & Ánh sáng Studio
          </span>
        </div>
      </div>

      {/* Top Right Quick Tool Buttons & Studio Controls */}
      <div className="absolute top-3 right-3 flex items-center gap-2 z-10">
        {/* Studio Snapshot Photo Button */}
        <button
          onClick={handleTakeSnapshot}
          disabled={isSnapshotting}
          className="px-3 py-1.5 rounded-xl bg-white/95 backdrop-blur-md hover:bg-white text-slate-800 shadow-sm border border-slate-200 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
          title="Chụp ảnh sản phẩm thật (HD Snapshot)"
        >
          <Camera className="w-3.5 h-3.5 text-emerald-600" />
          <span className="hidden sm:inline">Chụp Studio HD</span>
        </button>

        {/* GLB Export */}
        <button
          onClick={handleExportGLB}
          disabled={exportingGlb}
          className="px-3 py-1.5 rounded-xl bg-white/95 backdrop-blur-md hover:bg-white text-slate-700 shadow-sm border border-slate-200 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
          title="Tải tệp mô hình 3D (.glb)"
        >
          <Download className="w-3.5 h-3.5 text-indigo-600" />
          <span className="hidden sm:inline">{exportingGlb ? 'Đang xuất...' : 'Tải GLB'}</span>
        </button>

        {/* Fullscreen / Zen Mode */}
        <button
          onClick={() => setIsZenMode(!isZenMode)}
          className="p-2 rounded-xl bg-white/95 backdrop-blur-md hover:bg-white text-slate-700 shadow-sm border border-slate-200 text-xs font-medium transition cursor-pointer"
          title={isZenMode ? 'Thu nhỏ' : 'Toàn màn hình'}
        >
          {isZenMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Snapshot Confirmation Toast */}
      {snapshotToast && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-xs px-4 py-2 rounded-2xl shadow-xl border border-emerald-500/30 flex items-center gap-2 animate-in fade-in z-30">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{snapshotToast}</span>
        </div>
      )}

      {/* Selected Component Hotspot Detail Card Popup */}
      {selectedHotspot && (
        <div className="absolute top-20 right-3 bg-white/95 backdrop-blur-md p-4 rounded-3xl shadow-2xl border border-emerald-200 text-xs space-y-2.5 max-w-xs animate-in fade-in z-20">
          <div className="flex items-center justify-between pb-1 border-b border-slate-100">
            <span className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5 text-emerald-800">
              <Info className="w-4 h-4 text-emerald-600" />
              <span>{selectedHotspot.name}</span>
            </span>
            <button
              onClick={() => setSelectedHotspot(null)}
              className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1.5 text-[11px]">
            <div>
              <span className="font-semibold text-slate-500 block">Chất liệu thực tế:</span>
              <span className="font-medium text-slate-800">{selectedHotspot.material}</span>
            </div>
            <div>
              <span className="font-semibold text-slate-500 block">Công dụng / Vai trò:</span>
              <span className="text-slate-700">{selectedHotspot.role}</span>
            </div>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-900 border border-emerald-100">
              <span className="font-bold block mb-0.5">Cách chế tạo thủ công:</span>
              <span>{selectedHotspot.howToMake}</span>
            </div>
            {selectedHotspot.safetyNotice && (
              <div className="p-2 rounded-xl bg-amber-50 text-amber-900 border border-amber-200">
                <span className="font-bold block mb-0.5 flex items-center gap-1">
                  <ShieldAlert className="w-3 h-3 text-amber-600" />
                  <span>Lưu ý an toàn:</span>
                </span>
                <span>{selectedHotspot.safetyNotice}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Zen Mode Floating Controls Bar (Chỉ hiển thị khi phóng to toàn màn hình) */}
      {isZenMode && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 max-w-[95%] w-fit bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-2xl border border-slate-200 flex items-center flex-wrap justify-center gap-2 sm:gap-3 text-xs z-30">
          <div className="flex items-center gap-1 font-mono font-bold text-slate-800">
            <button
              onClick={() => onStepChange && onStepChange(Math.max(0, currentStepIndex - 1))}
              disabled={currentStepIndex === 0}
              className="p-1 rounded-lg bg-slate-100 disabled:opacity-30"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span>{currentStepIndex + 1}/{safeSteps.length}</span>
            <button
              onClick={() => onStepChange && onStepChange(Math.min(safeSteps.length - 1, currentStepIndex + 1))}
              disabled={currentStepIndex === safeSteps.length - 1}
              className="p-1 rounded-lg bg-slate-100 disabled:opacity-30"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="w-[1px] h-4 bg-slate-200" />
          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 ${
              isAutoRotating ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isAutoRotating ? 'animate-spin' : ''}`} />
            <span>360°</span>
          </button>
          <button
            onClick={() => animateExplodeTo(explodedFactor > 0.5 ? 0 : 1)}
            className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 ${
              explodedFactor > 0.5 ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700'
            }`}
          >
            <Split className="w-3.5 h-3.5" />
            <span>{explodedFactor > 0.5 ? 'Lắp ráp' : 'Tách chi tiết'}</span>
          </button>
          <button
            onClick={() => setShowDecorations(!showDecorations)}
            className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 ${
              showDecorations ? 'bg-pink-500 text-white' : 'bg-slate-100 text-slate-700'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Decor</span>
          </button>
          <button
            onClick={() => setIsZenMode(false)}
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600"
            title="Thu nhỏ màn hình"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>

    {/* ========================================================
        BẢNG ĐIỀU KHIỂN & CÔNG CỤ TƯƠNG TÁC 3D (ĐẶT HOÀN TOÀN BÊN NGOÀI MÀN HÌNH 3D)
        Giúp màn hình 3D rộng rãi 100%, không bị che khuất tầm nhìn của người dùng
        ======================================================== */}
    {!isZenMode && (
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-3.5">
        {/* HÀNG 1: ĐIỀU HƯỚNG CÔNG ĐOẠN & THAO TÁC CẤU TẠO CHÍNH */}
        <div className="flex items-center justify-between flex-wrap gap-2.5 pb-3 border-b border-slate-100">
          {/* Step Navigation Pill */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 p-1 rounded-2xl">
            <button
              onClick={() => onStepChange && onStepChange(Math.max(0, currentStepIndex - 1))}
              disabled={currentStepIndex === 0}
              className="p-1.5 rounded-xl hover:bg-white text-slate-700 disabled:opacity-30 transition cursor-pointer shadow-2xs"
              title="Công đoạn trước"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <span className="font-bold text-slate-800 px-2 text-xs font-mono">
              Bước {currentStepIndex + 1}/{safeSteps.length}
            </span>

            <button
              onClick={() =>
                onStepChange && onStepChange(Math.min(safeSteps.length - 1, currentStepIndex + 1))
              }
              disabled={currentStepIndex === safeSteps.length - 1}
              className="p-1.5 rounded-xl hover:bg-white text-slate-700 disabled:opacity-30 transition cursor-pointer shadow-2xs"
              title="Công đoạn tiếp theo"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Main Interactive Action Buttons */}
          <div className="flex items-center flex-wrap gap-2 text-xs">
            {/* Play/Pause Simulation Autoplay */}
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`px-3 py-2 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs ${
                isSimulating
                  ? 'bg-amber-500 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
              }`}
              title="Tự động mô phỏng quy trình qua từng công đoạn"
            >
              {isSimulating ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>Dừng</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>Mô phỏng</span>
                </>
              )}
            </button>

            {/* Dedicated 360-degree Turntable continuous auto-spin button */}
            <button
              onClick={() => setIsAutoRotating(!isAutoRotating)}
              className={`px-3 py-2 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs ${
                isAutoRotating
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'
              }`}
              title="Bật/Tắt chế độ tự động xoay 360 độ quanh sản phẩm"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isAutoRotating ? 'animate-spin' : ''}`} />
              <span>{isAutoRotating ? 'Dừng xoay 360°' : 'Xoay 360°'}</span>
            </button>

            {/* Exploded View Action Button & Distance Slider */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 px-2.5 py-1.5 rounded-xl">
              <button
                onClick={() => animateExplodeTo(explodedFactor > 0.5 ? 0 : 1)}
                className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 transition cursor-pointer ${
                  explodedFactor > 0.5
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700'
                }`}
                title="Tách rời các bộ phận lên không trung để quan sát cấu tạo bên trong"
              >
                <Split className="w-3.5 h-3.5" />
                <span>{explodedFactor > 0.5 ? 'Lắp ráp lại' : 'Tách cấu tạo'}</span>
              </button>

              <input
                type="range"
                min={0}
                max={1}
                step={0.02}
                value={explodedFactor}
                onChange={(e) => setExplodedFactor(parseFloat(e.target.value))}
                className="w-16 sm:w-24 accent-indigo-600 cursor-pointer"
                title="Kéo trượt để nâng và bung khoảng cách chi tiết"
              />
            </div>

            {/* Toggle Cute Handcrafted Decorations */}
            <button
              onClick={() => setShowDecorations(!showDecorations)}
              className={`px-3 py-2 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs ${
                showDecorations
                  ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
              title="Bật/Tắt các chi tiết trang trí thủ công dễ thương (nơ thừng, mặt cười kawaii, hoa nở, tem đua...)"
            >
              <Palette className="w-3.5 h-3.5" />
              <span>{showDecorations ? 'Decor: Bật' : 'Decor: Tắt'}</span>
            </button>

            {/* Reset Camera */}
            <button
              onClick={() => {
                if (cameraRef.current && controlsRef.current) {
                  const targetY = 0.85 + explodedFactor * 0.75;
                  cameraRef.current.position.set(3.4, targetY + 1.55, 4.2);
                  controlsRef.current.target.set(0, targetY, 0);
                  controlsRef.current.update();
                }
              }}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition cursor-pointer"
              title="Đặt lại góc nhìn ban đầu"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* HÀNG 2: GÓC NHÌN NHANH 360° & PHÔNG NỀN STUDIO CHUYÊN NGHIỆP */}
        <div className="flex items-center justify-between flex-wrap gap-3 text-xs">
          {/* Dải nút Góc nhìn Camera 3D */}
          <div className="flex items-center flex-wrap gap-1.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1 flex items-center gap-1">
              <Compass className="w-3.5 h-3.5 text-indigo-500" />
              <span>Góc nhìn 3D:</span>
            </span>
            <button
              onClick={() => setCameraAngle('iso')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-semibold text-slate-700 transition cursor-pointer text-[11px]"
            >
              Phối cảnh
            </button>
            <button
              onClick={() => setCameraAngle('front')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
            >
              Chính diện
            </button>
            <button
              onClick={() => setCameraAngle('back')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
            >
              Mặt sau
            </button>
            <button
              onClick={() => setCameraAngle('left')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
            >
              Trái
            </button>
            <button
              onClick={() => setCameraAngle('right')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
            >
              Phải
            </button>
            <button
              onClick={() => setCameraAngle('top')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
            >
              Trên đỉnh
            </button>
            <button
              onClick={() => setCameraAngle('bottom')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
            >
              Dưới đáy
            </button>
          </div>

          {/* Dải nút Chọn Phông Nền Studio */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 px-2 py-1 rounded-2xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1">
              Phông nền:
            </span>
            <button
              onClick={() => setStudioBackdrop('studio_white')}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition cursor-pointer ${
                studioBackdrop === 'studio_white'
                  ? 'bg-slate-800 text-white shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600'
              }`}
              title="Phông nền Studio Trắng"
            >
              Trắng
            </button>
            <button
              onClick={() => setStudioBackdrop('workshop_wood')}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition cursor-pointer ${
                studioBackdrop === 'workshop_wood'
                  ? 'bg-amber-800 text-white shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600'
              }`}
              title="Bàn Gỗ Xưởng Tái Chế"
            >
              Gỗ
            </button>
            <button
              onClick={() => setStudioBackdrop('studio_dark')}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition cursor-pointer ${
                studioBackdrop === 'studio_dark'
                  ? 'bg-indigo-950 text-white shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600'
              }`}
              title="Studio Tối Sang Trọng"
            >
              Tối
            </button>
          </div>
        </div>

        {/* DÒNG HƯỚNG DẪN CỬ CHỈ GỌN GÀNG */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" />
            <span>Dùng 1 ngón tay / kéo chuột để xoay 360°, 2 ngón tay để thu phóng</span>
          </span>
          <span className="hidden sm:inline text-slate-400 text-[10px]">
            Chạm vào các điểm tròn trên vật thể để xem chi tiết linh kiện
          </span>
        </div>
      </div>
    )}
  </div>
);
};

// Generate 3D Interactive Hotspot Markers
function buildInteractiveHotspots(group: THREE.Group, craft: CraftProduct) {
  const modelType = craft.model3DType;

  const hotspotsMap: Record<string, ComponentHotspot[]> = {
    toy_car: [
      {
        id: 'hp_body',
        name: 'Khung gầm thân xe nhựa PET',
        material: 'Thân chai nhựa PET 500ml nguyên bản',
        role: 'Tạo thân chịu lực và cabin khoét mui cho xe.',
        howToMake: 'Cắt khoét ô chữ nhật trên mui, dùi 4 lỗ trục đối xứng xuyên qua thân.',
        safetyNotice: 'Dùi nhẹ tay tránh làm bẹp mép chai.',
        position: new THREE.Vector3(0, 0.9, 0),
      },
      {
        id: 'hp_wheels',
        name: 'Bánh xe nắp chai HDPE & Trục tre',
        material: '4 nắp chai nhựa HDPE + 2 que tăm tre + keo nến',
        role: 'Giúp xe lăn mượt mà trên mặt sàn phẳng.',
        howToMake: 'Đục lỗ tâm nắp chai, xỏ tăm tre qua thân chai và chấm keo nến chặn hai đầu.',
        safetyNotice: 'Không để keo dính chặt vào thân chai làm kẹt trục.',
        position: new THREE.Vector3(0.9, 0.35, 0.7),
      },
    ],
    planter: [
      {
        id: 'hp_reservoir',
        name: 'Khoang chứa nước tự dưỡng',
        material: 'Đáy chai nhựa PET 5 khía cánh hoa',
        role: 'Chứa nước sạch cung cấp độ ẩm liên tục cho cây cảnh cả tuần.',
        howToMake: 'Cắt ngang 1/3 thân chai tính từ đáy lên.',
        safetyNotice: 'Mài nhẹ viền cắt bằng giấy nhám.',
        position: new THREE.Vector3(0, 0.4, 0.8),
      },
      {
        id: 'hp_funnel',
        name: 'Phễu giữ đất & bấc thấm cotton',
        material: 'Miệng chai úp ngược + dây bấc cotton',
        role: 'Hút nước theo nguyên lý mao dẫn giữ đất ẩm vừa phải.',
        howToMake: 'Khoét lỗ 4mm ở nắp chai, luồn dây cotton thắt nút giữ một đầu.',
        safetyNotice: 'Cẩn thận khi dùi nắp nhựa cứng.',
        position: new THREE.Vector3(0, 1.4, 0.8),
      },
    ],
    fabric_tote: [
      {
        id: 'hp_scales',
        name: 'Vảy cá denim 3D',
        material: 'Vải quần jean cũ cắt vòm',
        role: 'Tạo họa tiết vảy cá xếp tầng so le đẹp mắt.',
        howToMake: 'Cắt các mảnh vải 4×5cm và may so le từ đuôi cá ngược lên thân.',
        safetyNotice: 'Dùng kim may vải jean số 14-16.',
        position: new THREE.Vector3(0, 1.2, 0.3),
      },
      {
        id: 'hp_strap',
        name: 'Quai đeo dây rút',
        material: 'Dây dù hoặc dây thừng đay',
        role: 'Đóng mở miệng túi nhanh gọn và đeo chéo.',
        howToMake: 'May nẹp gấp mép trên miệng túi và luồn dây.',
        safetyNotice: '',
        position: new THREE.Vector3(0, 2.3, 0),
      },
    ],
  };

  const currentHotspots = hotspotsMap[modelType] || [
    {
      id: 'hp_general',
      name: 'Thân sản phẩm tái chế',
      material: 'Vật liệu tái chế thực tế',
      role: 'Định hình kết cấu và công năng sản phẩm.',
      howToMake: 'Cắt ghép theo kích thước hướng dẫn từng bước.',
      safetyNotice: 'Đeo kính bảo hộ khi cắt vật liệu cứng.',
      position: new THREE.Vector3(0, 1.0, 0.8),
    },
  ];

  currentHotspots.forEach((hp) => {
    // Outer ring
    const ringGeo = new THREE.RingGeometry(0.08, 0.12, 16);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x10b981, side: THREE.DoubleSide });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.copy(hp.position);
    ring.userData = hp;

    // Center dot
    const dotGeo = new THREE.CircleGeometry(0.06, 16);
    const dotMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const dot = new THREE.Mesh(dotGeo, dotMat);
    dot.position.copy(hp.position).add(new THREE.Vector3(0, 0, 0.001));
    dot.userData = hp;

    group.add(ring);
    group.add(dot);
  });
}

// -------------------------------------------------------------------------------------
// Photorealistic Handcrafted Procedural Craft Models
// -------------------------------------------------------------------------------------

function buildPhotorealisticCraftMesh(
  group: THREE.Group,
  craft: CraftProduct,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const modelType = craft.model3DType;

  if (modelType === 'planter') {
    buildPhotorealPlanterCraft(group, subparts, showDecorations);
  } else if (modelType === 'toy_car') {
    buildPhotorealToyCarCraft(group, subparts, showDecorations);
  } else if (modelType === 'pen_holder') {
    buildPhotorealPenHolderCraft(group, subparts, showDecorations);
  } else if (modelType === 'cardboard_house') {
    buildPhotorealCardboardHouseCraft(group, subparts, showDecorations);
  } else if (modelType === 'tin_lamp') {
    buildPhotorealTinLampCraft(group, subparts, showDecorations);
  } else if (modelType === 'desk_organizer') {
    buildPhotorealDeskOrganizerCraft(group, subparts, showDecorations);
  } else if (modelType === 'fabric_tote') {
    buildPhotorealFabricToteCraft(group, subparts, showDecorations);
  } else if (modelType === 'cap_mosaic') {
    buildPhotorealCapMosaicCraft(group, subparts, showDecorations);
  } else {
    buildPhotorealPlanterCraft(group, subparts, showDecorations);
  }
}

// -------------------------------------------------------------
// Decorative Handcrafted Helpers (Thủ công mỹ nghệ)
// -------------------------------------------------------------

// Cute expressive glossy eye with shine reflection
function createCuteKawaiiEye(radius: number = 0.045): THREE.Group {
  const eyeGroup = new THREE.Group();
  const pupilGeo = new THREE.CircleGeometry(radius, 24);
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
  const pupil = new THREE.Mesh(pupilGeo, pupilMat);
  eyeGroup.add(pupil);

  // Big sparkle shine dot
  const shineGeo = new THREE.CircleGeometry(radius * 0.42, 16);
  const shineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const shine1 = new THREE.Mesh(shineGeo, shineMat);
  shine1.position.set(radius * 0.32, radius * 0.32, 0.001);
  eyeGroup.add(shine1);

  // Tiny catchlight dot
  const shine2Geo = new THREE.CircleGeometry(radius * 0.2, 12);
  const shine2 = new THREE.Mesh(shine2Geo, shineMat);
  shine2.position.set(-radius * 0.3, -radius * 0.28, 0.001);
  eyeGroup.add(shine2);

  return eyeGroup;
}

// Vintage rustic jute twine bow knot with dangling wooden beads
function createJuteTwineBow(twineMat: THREE.Material, woodMat: THREE.Material): THREE.Group {
  const bow = new THREE.Group();
  bow.name = 'decorations';
  bow.userData = { isDecoration: true };

  // Center knot
  const knot = new THREE.Mesh(new THREE.SphereGeometry(0.065, 12, 12), twineMat);
  bow.add(knot);

  // Left loop
  const loopL = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.024, 12, 24), twineMat);
  loopL.rotation.z = 0.45;
  loopL.position.set(-0.13, 0.04, 0);
  bow.add(loopL);

  // Right loop
  const loopR = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.024, 12, 24), twineMat);
  loopR.rotation.z = -0.45;
  loopR.position.set(0.13, 0.04, 0);
  bow.add(loopR);

  // Dangling tails with wooden beads
  for (let s of [-1, 1]) {
    const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.28, 8), twineMat);
    tail.rotation.z = s * 0.35;
    tail.position.set(s * 0.08, -0.16, 0);
    bow.add(tail);

    const bead = new THREE.Mesh(new THREE.SphereGeometry(0.042, 12, 12), woodMat);
    bead.position.set(s * 0.13, -0.3, 0);
    bead.castShadow = true;
    bow.add(bead);
  }

  return bow;
}

// 1. Photorealistic Self-Watering Planter (Chậu cây tự dưỡng từ chai nhựa PET thực tế + Decor xinh xắn)
function buildPhotorealPlanterCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const petMat = createRecycledPETMaterial();
  const cutLipMat = createHandCutLipMaterial();
  const capMat = createHDPECapMaterial(0x0284c7); // Vivid blue HDPE bottle cap
  const soilMat = createPottingSoilMaterial();
  const woodMat = createBambooAxleMaterial();

  const plantLeafMat = new THREE.MeshStandardMaterial({
    color: 0x22c55e,
    roughness: 0.28,
    metalness: 0.04,
  });

  const wickMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    roughness: 0.85,
    metalness: 0.02,
  });

  const juteMat = new THREE.MeshStandardMaterial({
    color: 0xd97706, // Natural warm burlap twine
    roughness: 0.92,
    metalness: 0.02,
  });

  // -------------------------------------------------------------
  // PART 1: Bottom Reservoir (Chân chai 5 khía cánh hoa thực tế)
  // -------------------------------------------------------------
  const reservoirGroup = new THREE.Group();
  reservoirGroup.name = 'bottom_reservoir';
  reservoirGroup.position.set(0, 0, 0);

  // Main lower cylindrical wall with realistic reinforcement rib indentations
  const baseCylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.78, 0.76, 1.1, 48, 1, true), petMat);
  baseCylinder.position.set(0, 0.55, 0);
  baseCylinder.castShadow = true;
  baseCylinder.receiveShadow = true;
  reservoirGroup.add(baseCylinder);

  // Real bottle waistline reinforcement rib (gân chịu lực lõm ngang trên chai nước)
  const ribGeo = new THREE.TorusGeometry(0.74, 0.035, 16, 48);
  const ribMesh = new THREE.Mesh(ribGeo, petMat);
  ribMesh.rotation.x = Math.PI / 2;
  ribMesh.position.set(0, 0.5, 0);
  reservoirGroup.add(ribMesh);

  // Handcrafted cut lip (gờ cắt kéo thủ công có viền mịn phản chiếu)
  const cutLipGeo = new THREE.TorusGeometry(0.78, 0.024, 16, 48);
  const cutLipMesh = new THREE.Mesh(cutLipGeo, cutLipMat);
  cutLipMesh.rotation.x = Math.PI / 2;
  cutLipMesh.position.set(0, 1.1, 0);
  reservoirGroup.add(cutLipMesh);

  // 5-Lobed Petal Base (Đáy chai 5 khía hoa chịu lực đặc trưng của chai PET ngoài đời)
  const baseFloor = new THREE.Mesh(new THREE.CircleGeometry(0.76, 32), petMat);
  baseFloor.rotation.x = Math.PI / 2;
  baseFloor.position.set(0, 0.03, 0);
  reservoirGroup.add(baseFloor);

  for (let i = 0; i < 5; i++) {
    const angle = (i / 5) * Math.PI * 2;
    const footMesh = new THREE.Mesh(new THREE.SphereGeometry(0.14, 16, 12), petMat);
    footMesh.scale.set(1.0, 0.45, 1.4);
    footMesh.rotation.y = angle;
    footMesh.position.set(Math.cos(angle) * 0.52, 0.05, Math.sin(angle) * 0.52);
    footMesh.castShadow = true;
    reservoirGroup.add(footMesh);
  }

  // Pure Water level with refractive surface
  const waterGeo = new THREE.CylinderGeometry(0.75, 0.73, 0.52, 40);
  const waterMat = new THREE.MeshPhysicalMaterial({
    color: 0x38bdf8,
    roughness: 0.04,
    transmission: 0.92,
    thickness: 0.8,
    ior: 1.33,
    transparent: true,
    opacity: 0.65,
    depthWrite: false,
  });
  const waterMesh = new THREE.Mesh(waterGeo, waterMat);
  waterMesh.name = 'bottom';
  waterMesh.position.set(0, 0.32, 0);
  reservoirGroup.add(waterMesh);

  // --- DECORATION 1: Cute Hand-painted Kawaii Face on Lower Pot Wall ---
  const faceGroup = new THREE.Group();
  faceGroup.name = 'decorations';
  faceGroup.userData = { isDecoration: true };
  faceGroup.visible = showDecorations;

  // Eyes
  const eyeLeft = createCuteKawaiiEye(0.045);
  eyeLeft.position.set(-0.2, 0.72, 0.78);
  faceGroup.add(eyeLeft);

  const eyeRight = createCuteKawaiiEye(0.045);
  eyeRight.position.set(0.2, 0.72, 0.78);
  faceGroup.add(eyeRight);

  // Soft Peach-Pink Blushing Cheeks
  const blushMat = new THREE.MeshBasicMaterial({
    color: 0xfda4af,
    transparent: true,
    opacity: 0.75,
  });
  const blushL = new THREE.Mesh(new THREE.CircleGeometry(0.055, 16), blushMat);
  blushL.position.set(-0.31, 0.64, 0.75);
  faceGroup.add(blushL);

  const blushR = new THREE.Mesh(new THREE.CircleGeometry(0.055, 16), blushMat);
  blushR.position.set(0.31, 0.64, 0.75);
  faceGroup.add(blushR);

  // Happy Smile Arc
  const smileCurve = new THREE.Mesh(
    new THREE.TorusGeometry(0.08, 0.012, 8, 24, Math.PI * 0.7),
    new THREE.MeshBasicMaterial({ color: 0x1e293b })
  );
  smileCurve.rotation.z = Math.PI * 0.65;
  smileCurve.position.set(0, 0.64, 0.78);
  faceGroup.add(smileCurve);

  reservoirGroup.add(faceGroup);

  group.add(reservoirGroup);
  subparts.push({ mesh: reservoirGroup, basePos: reservoirGroup.position.clone(), explodeDir: new THREE.Vector3(0, -0.4, 0) });

  // -------------------------------------------------------------
  // PART 2: Inverted Funnel (Miệng chai lộn ngược & nắp đục lỗ)
  // -------------------------------------------------------------
  const funnelGroup = new THREE.Group();
  funnelGroup.name = 'assembly_funnel';
  funnelGroup.position.set(0, 1.35, 0);

  // Inverted conical bottle shoulder
  const funnelGeo = new THREE.CylinderGeometry(0.76, 0.34, 1.05, 48, 1, true);
  const funnelMesh = new THREE.Mesh(funnelGeo, petMat);
  funnelMesh.name = 'body';
  funnelMesh.castShadow = true;
  funnelMesh.receiveShadow = true;
  funnelGroup.add(funnelMesh);

  // Upper cut lip on the funnel top
  const funnelLip = new THREE.Mesh(new THREE.TorusGeometry(0.76, 0.024, 16, 48), cutLipMat);
  funnelLip.rotation.x = Math.PI / 2;
  funnelLip.position.set(0, 0.52, 0);
  funnelGroup.add(funnelLip);

  // Bottle screw threads on neck
  const neckCylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.3, 32), petMat);
  neckCylinder.position.y = -0.55;
  funnelGroup.add(neckCylinder);

  const threadRing1 = new THREE.Mesh(new THREE.TorusGeometry(0.33, 0.015, 12, 32), petMat);
  threadRing1.rotation.x = Math.PI / 2;
  threadRing1.position.y = -0.50;
  funnelGroup.add(threadRing1);

  const threadRing2 = new THREE.Mesh(new THREE.TorusGeometry(0.33, 0.015, 12, 32), petMat);
  threadRing2.rotation.x = Math.PI / 2;
  threadRing2.position.y = -0.56;
  funnelGroup.add(threadRing2);

  // Screwed Blue HDPE Bottle Cap with hole
  const capMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.22, 32), capMat);
  capMesh.name = 'assembly';
  capMesh.position.y = -0.68;
  capMesh.castShadow = true;
  funnelGroup.add(capMesh);

  // Braided Cotton Wick passing through cap hole
  const wickGeo = new THREE.CylinderGeometry(0.045, 0.045, 1.0, 16);
  const wickMesh = new THREE.Mesh(wickGeo, wickMat);
  wickMesh.name = 'assembly';
  wickMesh.position.y = -0.75;
  wickMesh.castShadow = true;
  funnelGroup.add(wickMesh);

  // Potting Soil inside the funnel with granular surface
  const soilGeo = new THREE.CylinderGeometry(0.72, 0.35, 0.8, 36);
  const soilMesh = new THREE.Mesh(soilGeo, soilMat);
  soilMesh.name = 'body';
  soilMesh.position.y = 0.06;
  soilMesh.receiveShadow = true;
  funnelGroup.add(soilMesh);

  // --- DECORATION 2: Vintage Jute Twine Bow around the Planter Lip ---
  const twineGroup = new THREE.Group();
  twineGroup.name = 'decorations';
  twineGroup.userData = { isDecoration: true };
  twineGroup.visible = showDecorations;

  const twineRing = new THREE.Mesh(new THREE.TorusGeometry(0.77, 0.022, 12, 48), juteMat);
  twineRing.rotation.x = Math.PI / 2;
  twineRing.position.set(0, 0.49, 0);
  twineGroup.add(twineRing);

  const twineBow = createJuteTwineBow(juteMat, woodMat);
  twineBow.position.set(0, 0.49, 0.78);
  twineGroup.add(twineBow);
  funnelGroup.add(twineGroup);

  // --- DECORATION 3: Smooth Polished River Pebbles on Soil Surface ---
  const pebblesGroup = new THREE.Group();
  pebblesGroup.name = 'decorations';
  pebblesGroup.userData = { isDecoration: true };
  pebblesGroup.visible = showDecorations;

  const pebbleColors = [0xf8fafc, 0xfbcfe8, 0xa7f3d0, 0xfde68a, 0xe0e7ff, 0xfef08a, 0xffedd5];
  for (let p = 0; p < 8; p++) {
    const angle = (p / 8) * Math.PI * 2 + 0.3;
    const rad = 0.42 + (p % 3) * 0.08;
    const pMat = new THREE.MeshStandardMaterial({
      color: pebbleColors[p % pebbleColors.length],
      roughness: 0.18,
      metalness: 0.08,
    });
    const pebble = new THREE.Mesh(new THREE.SphereGeometry(0.075, 12, 10), pMat);
    pebble.scale.set(1.2, 0.45, 0.9);
    pebble.rotation.y = angle * 1.5;
    pebble.position.set(Math.cos(angle) * rad, 0.47, Math.sin(angle) * rad);
    pebble.castShadow = true;
    pebblesGroup.add(pebble);
  }
  funnelGroup.add(pebblesGroup);

  // --- DECORATION 4: Tiny Eco Garden Flag Tag ("Eco ♥") ---
  const flagGroup = new THREE.Group();
  flagGroup.name = 'decorations';
  flagGroup.userData = { isDecoration: true };
  flagGroup.visible = showDecorations;

  const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.42, 8), woodMat);
  stick.position.set(0.42, 0.65, -0.2);
  stick.rotation.z = -0.2;
  flagGroup.add(stick);

  const flag = new THREE.Mesh(
    new THREE.BoxGeometry(0.24, 0.14, 0.01),
    new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.7 })
  );
  flag.position.set(0.48, 0.76, -0.2);
  flag.rotation.z = -0.2;
  flagGroup.add(flag);

  // Tiny red heart on flag
  const heartDot = new THREE.Mesh(
    new THREE.SphereGeometry(0.03, 10, 10),
    new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.4 })
  );
  heartDot.position.set(0.48, 0.76, -0.19);
  flagGroup.add(heartDot);

  funnelGroup.add(flagGroup);

  // Succulent Plant rosette with organic gradient petals
  const plantGroup = new THREE.Group();
  plantGroup.name = 'top_plant';
  plantGroup.position.y = 0.46;

  // Concentric fleshy succulent leaves
  for (let ring = 0; ring < 2; ring++) {
    const leafCount = ring === 0 ? 8 : 6;
    const ringRadius = ring === 0 ? 0.26 : 0.16;
    const leafScale = ring === 0 ? 1.0 : 0.75;

    for (let i = 0; i < leafCount; i++) {
      const angle = (i / leafCount) * Math.PI * 2 + ring * 0.4;
      const leafGeo = new THREE.ConeGeometry(0.18 * leafScale, 0.48 * leafScale, 8);
      const leafMesh = new THREE.Mesh(leafGeo, plantLeafMat);
      leafMesh.rotation.z = 0.72;
      leafMesh.rotation.y = angle;
      leafMesh.position.set(Math.cos(angle) * ringRadius, 0.08 + ring * 0.08, Math.sin(angle) * ringRadius);
      leafMesh.castShadow = true;
      plantGroup.add(leafMesh);
    }
  }

  // --- DECORATION 5: Blooming Coral-Pink Flower with Golden Pollen Center ---
  const flowerGroup = new THREE.Group();
  flowerGroup.name = 'decorations';
  flowerGroup.userData = { isDecoration: true };
  flowerGroup.visible = showDecorations;

  // Slender flower stalk
  const stalk = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.32, 8), plantLeafMat);
  stalk.position.set(0.04, 0.24, 0.02);
  stalk.rotation.z = -0.12;
  flowerGroup.add(stalk);

  // Bright warm yellow pollen sphere
  const pollenMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    emissive: 0xd97706,
    emissiveIntensity: 0.3,
    roughness: 0.3,
  });
  const pollen = new THREE.Mesh(new THREE.SphereGeometry(0.055, 12, 12), pollenMat);
  pollen.position.set(0.07, 0.4, 0.02);
  flowerGroup.add(pollen);

  // 5 delicate coral-pink petals
  const petalMat = new THREE.MeshStandardMaterial({
    color: 0xf43f5e,
    roughness: 0.4,
  });
  for (let i = 0; i < 5; i++) {
    const pAngle = (i / 5) * Math.PI * 2;
    const petal = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.16, 6), petalMat);
    petal.position.set(0.07 + Math.cos(pAngle) * 0.07, 0.4, 0.02 + Math.sin(pAngle) * 0.07);
    petal.rotation.z = Math.PI / 2;
    petal.rotation.y = pAngle;
    flowerGroup.add(petal);
  }

  plantGroup.add(flowerGroup);
  funnelGroup.add(plantGroup);

  group.add(funnelGroup);
  subparts.push({ mesh: funnelGroup, basePos: funnelGroup.position.clone(), explodeDir: new THREE.Vector3(0, 0.6, 0) });

  // Cutting Guideline marker
  const cutLineGeo = new THREE.TorusGeometry(0.82, 0.02, 16, 64);
  const cutLineMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
  const cutLine = new THREE.Mesh(cutLineGeo, cutLineMat);
  cutLine.name = 'cut_guide_line';
  cutLine.rotation.x = Math.PI / 2;
  cutLine.position.y = 1.1;
  group.add(cutLine);
}

// 2. Photorealistic Toy Car (Xe Đua Bánh Nắp Chai Tái Chế 100% + Tem Đua #7, Vô Lăng & Spoiler)
function buildPhotorealToyCarCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const petMat = createRecycledPETMaterial();
  const cutLipMat = createHandCutLipMaterial();
  const capMatBlue = createHDPECapMaterial(0x1d4ed8);
  const capMatRed = createHDPECapMaterial(0xdc2626);
  const bambooMat = createBambooAxleMaterial();
  const glueMat = createHotGlueMaterial();
  const chromeMat = createBrushedAluminumMaterial();

  // -------------------------------------------------------------
  // CAR BODY: Horizontal PET bottle with handcrafted cockpit
  // -------------------------------------------------------------
  const carBody = new THREE.Group();
  carBody.name = 'body';
  carBody.position.set(0, 0.65, 0);

  // Main horizontal bottle cylinder
  const mainCylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 2.2, 48), petMat);
  mainCylinder.rotation.x = Math.PI / 2;
  mainCylinder.castShadow = true;
  mainCylinder.receiveShadow = true;
  carBody.add(mainCylinder);

  // Horizontal reinforcement ribs on car body
  for (let z of [-0.6, 0.1, 0.7]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.53, 0.025, 12, 40), petMat);
    ring.position.set(0, 0, z);
    carBody.add(ring);
  }

  // Front tapered bottle neck & threaded nose
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.48, 0.5, 32), petMat);
  neck.rotation.x = Math.PI / 2;
  neck.position.set(0, 0, 1.35);
  neck.castShadow = true;
  carBody.add(neck);

  // Front nose cap
  const frontCap = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.22, 32), capMatBlue);
  frontCap.rotation.x = Math.PI / 2;
  frontCap.position.set(0, 0, 1.65);
  frontCap.castShadow = true;
  carBody.add(frontCap);

  // Hand-cut cockpit opening with curled lip border
  const cockpitHole = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.06, 0.85), cutLipMat);
  cockpitHole.name = 'cut_guide_line';
  cockpitHole.position.set(0, 0.56, -0.2);
  carBody.add(cockpitHole);

  // Folded seat backrest inside cockpit
  const seatBack = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.05), petMat);
  seatBack.position.set(0, 0.35, -0.55);
  seatBack.rotation.x = -0.25;
  carBody.add(seatBack);

  // --- CAR DECORATION 1: Twin Racing Stripes along the Hood & Roof ---
  const stripesGroup = new THREE.Group();
  stripesGroup.name = 'decorations';
  stripesGroup.userData = { isDecoration: true };
  stripesGroup.visible = showDecorations;

  const whiteStripeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const yellowStripeMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });

  const stripeL = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.01, 1.6), whiteStripeMat);
  stripeL.position.set(-0.06, 0.56, 0.3);
  stripesGroup.add(stripeL);

  const stripeR = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.01, 1.6), yellowStripeMat);
  stripeR.position.set(0.06, 0.56, 0.3);
  stripesGroup.add(stripeR);

  // --- CAR DECORATION 2: Racing Number Plate "#7" Roundel on Hood ---
  const numBadgeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const numBadge = new THREE.Mesh(new THREE.CircleGeometry(0.18, 24), numBadgeMat);
  numBadge.rotation.x = -Math.PI / 2 + 0.2;
  numBadge.position.set(0, 0.53, 0.92);
  stripesGroup.add(numBadge);

  // "#7" digit decal
  const digitH = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.035, 0.005), new THREE.MeshBasicMaterial({ color: 0x1d4ed8 }));
  digitH.rotation.x = -Math.PI / 2 + 0.2;
  digitH.position.set(0, 0.535, 0.97);
  stripesGroup.add(digitH);

  const digitDiag = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.035, 0.005), new THREE.MeshBasicMaterial({ color: 0x1d4ed8 }));
  digitDiag.rotation.x = -Math.PI / 2 + 0.2;
  digitDiag.rotation.z = -0.7;
  digitDiag.position.set(-0.02, 0.535, 0.92);
  stripesGroup.add(digitDiag);

  // --- CAR DECORATION 3: Twin Amber Headlights with Chrome Bezels ---
  const headlampMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xf59e0b,
    emissiveIntensity: 0.6,
    roughness: 0.1,
  });

  for (let s of [-1, 1]) {
    const lampBezel = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.02, 12, 24), chromeMat);
    lampBezel.position.set(s * 0.36, 0.15, 1.48);
    stripesGroup.add(lampBezel);

    const lampLens = new THREE.Mesh(new THREE.SphereGeometry(0.08, 16, 12), headlampMat);
    lampLens.scale.set(1, 1, 0.5);
    lampLens.position.set(s * 0.36, 0.15, 1.5);
    stripesGroup.add(lampLens);
  }

  // --- CAR DECORATION 4: Twin Red Sport Tail-lights ---
  const taillampMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xdc2626,
    emissiveIntensity: 0.5,
    roughness: 0.2,
  });
  for (let s of [-1, 1]) {
    const tailLens = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.04, 16), taillampMat);
    tailLens.rotation.x = Math.PI / 2;
    tailLens.position.set(s * 0.38, 0.12, -1.1);
    stripesGroup.add(tailLens);
  }

  // --- CAR DECORATION 5: Mini Cockpit Steering Wheel ---
  const steeringGroup = new THREE.Group();
  steeringGroup.position.set(0, 0.28, 0.05);

  const steerCol = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.25, 8), bambooMat);
  steerCol.rotation.x = 0.5;
  steeringGroup.add(steerCol);

  const steerWheel = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.022, 12, 24), capMatBlue);
  steerWheel.rotation.x = 0.5;
  steerWheel.position.set(0, 0.1, 0.05);
  steeringGroup.add(steerWheel);

  stripesGroup.add(steeringGroup);

  // --- CAR DECORATION 6: Aerodynamic Rear Spoiler Wing ---
  const spoilerGroup = new THREE.Group();
  spoilerGroup.position.set(0, 0.5, -0.95);

  // Upright struts
  for (let s of [-1, 1]) {
    const strut = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.28, 0.06), cutLipMat);
    strut.position.set(s * 0.42, 0.14, 0);
    spoilerGroup.add(strut);
  }

  // Horizontal Aerofoil
  const aerofoil = new THREE.Mesh(
    new THREE.BoxGeometry(1.22, 0.035, 0.26),
    new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.35 })
  );
  aerofoil.position.set(0, 0.28, 0);
  aerofoil.castShadow = true;
  spoilerGroup.add(aerofoil);

  // Endplates in vibrant yellow
  for (let s of [-1, 1]) {
    const endplate = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.14, 0.3),
      new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.4 })
    );
    endplate.position.set(s * 0.61, 0.28, 0);
    spoilerGroup.add(endplate);
  }

  stripesGroup.add(spoilerGroup);

  // --- CAR DECORATION 7: Dual Chrome Exhaust Pipes ---
  for (let s of [-1, 1]) {
    const exhaust = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.22, 16, 1, true), chromeMat);
    exhaust.rotation.x = Math.PI / 2;
    exhaust.position.set(s * 0.18, -0.15, -1.18);
    stripesGroup.add(exhaust);
  }

  carBody.add(stripesGroup);

  group.add(carBody);
  subparts.push({ mesh: carBody, basePos: carBody.position.clone(), explodeDir: new THREE.Vector3(0, 0.5, 0) });

  // -------------------------------------------------------------
  // FRONT AXLE & WHEELS (Bamboo skewer + Blue HDPE Caps + Glue beads)
  // -------------------------------------------------------------
  const frontAxleGroup = new THREE.Group();
  frontAxleGroup.name = 'assembly_front_wheels';
  frontAxleGroup.position.set(0, 0.35, 0.7);

  const axleFront = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.9, 16), bambooMat);
  axleFront.rotation.z = Math.PI / 2;
  axleFront.castShadow = true;
  frontAxleGroup.add(axleFront);

  // Left wheel (Blue cap)
  const wheelFL = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.2, 32), capMatBlue);
  wheelFL.rotation.z = Math.PI / 2;
  wheelFL.position.set(0.92, 0, 0);
  wheelFL.castShadow = true;
  frontAxleGroup.add(wheelFL);

  const glueFL = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 12), glueMat);
  glueFL.position.set(1.04, 0, 0);
  frontAxleGroup.add(glueFL);

  // Right wheel (Blue cap)
  const wheelFR = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.2, 32), capMatBlue);
  wheelFR.rotation.z = Math.PI / 2;
  wheelFR.position.set(-0.92, 0, 0);
  wheelFR.castShadow = true;
  frontAxleGroup.add(wheelFR);

  const glueFR = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 12), glueMat);
  glueFR.position.set(-1.04, 0, 0);
  frontAxleGroup.add(glueFR);

  group.add(frontAxleGroup);
  subparts.push({ mesh: frontAxleGroup, basePos: frontAxleGroup.position.clone(), explodeDir: new THREE.Vector3(0, -0.4, 0.4) });

  // -------------------------------------------------------------
  // REAR AXLE & WHEELS (Bamboo skewer + Red HDPE Caps + Glue beads)
  // -------------------------------------------------------------
  const rearAxleGroup = new THREE.Group();
  rearAxleGroup.name = 'assembly_rear_wheels';
  rearAxleGroup.position.set(0, 0.35, -0.7);

  const axleRear = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.9, 16), bambooMat);
  axleRear.rotation.z = Math.PI / 2;
  axleRear.castShadow = true;
  rearAxleGroup.add(axleRear);

  // Left rear wheel (Red cap)
  const wheelRL = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.2, 32), capMatRed);
  wheelRL.rotation.z = Math.PI / 2;
  wheelRL.position.set(0.92, 0, 0);
  wheelRL.castShadow = true;
  rearAxleGroup.add(wheelRL);

  const glueRL = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 12), glueMat);
  glueRL.position.set(1.04, 0, 0);
  rearAxleGroup.add(glueRL);

  // Right rear wheel (Red cap)
  const wheelRR = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.2, 32), capMatRed);
  wheelRR.rotation.z = Math.PI / 2;
  wheelRR.position.set(-0.92, 0, 0);
  wheelRR.castShadow = true;
  rearAxleGroup.add(wheelRR);

  const glueRR = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 12), glueMat);
  glueRR.position.set(-1.04, 0, 0);
  rearAxleGroup.add(glueRR);

  group.add(rearAxleGroup);
  subparts.push({ mesh: rearAxleGroup, basePos: rearAxleGroup.position.clone(), explodeDir: new THREE.Vector3(0, -0.4, -0.4) });
}

// 3. Photorealistic Cute Cat-Ear Pen Holder (Hộp cắm bút tai mèo + Chuông Vàng, Thước Kẻ & Gôm Thỏ)
function buildPhotorealPenHolderCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const petMat = createRecycledPETMaterial({ tintColor: 0xfef08a, roughness: 0.3 });
  const cutLipMat = createHandCutLipMaterial();
  const woodMat = createBambooAxleMaterial();

  const bodyH = 1.6;
  const bodyGeo = new THREE.CylinderGeometry(0.66, 0.64, bodyH, 48, 1, true);
  const bodyMesh = new THREE.Mesh(bodyGeo, petMat);
  bodyMesh.name = 'body';
  bodyMesh.position.y = bodyH / 2;
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  group.add(bodyMesh);
  subparts.push({ mesh: bodyMesh, basePos: bodyMesh.position.clone(), explodeDir: new THREE.Vector3(0, 0, 0) });

  // 5-lobed base
  const baseMesh = new THREE.Mesh(new THREE.CircleGeometry(0.64, 32), petMat);
  baseMesh.name = 'bottom';
  baseMesh.rotation.x = Math.PI / 2;
  baseMesh.position.y = 0.02;
  group.add(baseMesh);

  // Hand-cut Cat Ears at the top rim
  const earL = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.38, 4), cutLipMat);
  earL.name = 'top';
  earL.position.set(-0.35, bodyH + 0.12, 0.45);
  earL.rotation.z = -0.22;
  earL.castShadow = true;
  group.add(earL);

  const earR = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.38, 4), cutLipMat);
  earR.name = 'top';
  earR.position.set(0.35, bodyH + 0.12, 0.45);
  earR.rotation.z = 0.22;
  earR.castShadow = true;
  group.add(earR);

  // --- PEN HOLDER DECORATION 1: Soft Pastel Pink Inner Ears ---
  const earsDecorGroup = new THREE.Group();
  earsDecorGroup.name = 'decorations';
  earsDecorGroup.userData = { isDecoration: true };
  earsDecorGroup.visible = showDecorations;

  const innerEarMat = new THREE.MeshStandardMaterial({ color: 0xfbcfe8, roughness: 0.7 });
  const innerEarL = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.26, 4), innerEarMat);
  innerEarL.position.set(-0.35, bodyH + 0.1, 0.48);
  innerEarL.rotation.z = -0.22;
  earsDecorGroup.add(innerEarL);

  const innerEarR = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.26, 4), innerEarMat);
  innerEarR.position.set(0.35, bodyH + 0.1, 0.48);
  innerEarR.rotation.z = 0.22;
  earsDecorGroup.add(innerEarR);

  // --- PEN HOLDER DECORATION 2: Kawaii Cat Face Details ---
  // Cute glossy anime eyes
  const catEyeL = createCuteKawaiiEye(0.05);
  catEyeL.position.set(-0.24, 1.15, 0.66);
  earsDecorGroup.add(catEyeL);

  const catEyeR = createCuteKawaiiEye(0.05);
  catEyeR.position.set(0.24, 1.15, 0.66);
  earsDecorGroup.add(catEyeR);

  // Pink triangle heart nose
  const nose = new THREE.Mesh(
    new THREE.ConeGeometry(0.04, 0.05, 3),
    new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.3 })
  );
  nose.rotation.z = Math.PI;
  nose.position.set(0, 1.05, 0.67);
  earsDecorGroup.add(nose);

  // Soft peach blush cheeks
  const blushMat = new THREE.MeshBasicMaterial({ color: 0xfda4af, transparent: true, opacity: 0.75 });
  const catBlushL = new THREE.Mesh(new THREE.CircleGeometry(0.06, 16), blushMat);
  catBlushL.position.set(-0.38, 1.02, 0.62);
  earsDecorGroup.add(catBlushL);

  const catBlushR = new THREE.Mesh(new THREE.CircleGeometry(0.06, 16), blushMat);
  catBlushR.position.set(0.38, 1.02, 0.62);
  earsDecorGroup.add(catBlushR);

  // Hand-drawn marker whiskers on the front
  const markerMat = new THREE.MeshBasicMaterial({ color: 0x1f2937 });
  for (let s of [-1, 1]) {
    for (let w = 0; w < 3; w++) {
      const whisker = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.015, 0.01), markerMat);
      whisker.position.set(s * 0.32, 0.95 + (w - 1) * 0.06, 0.65);
      whisker.rotation.z = s * (w - 1) * 0.12;
      earsDecorGroup.add(whisker);
    }
  }

  // --- PEN HOLDER DECORATION 3: Crimson Collar with Golden Bell ---
  const collarRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.665, 0.026, 16, 48),
    new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.5 })
  );
  collarRing.rotation.x = Math.PI / 2;
  collarRing.position.set(0, 0.55, 0);
  earsDecorGroup.add(collarRing);

  // Golden Bell Sphere
  const bellMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    metalness: 0.88,
    roughness: 0.16,
  });
  const goldenBell = new THREE.Mesh(new THREE.SphereGeometry(0.085, 16, 16), bellMat);
  goldenBell.position.set(0, 0.53, 0.74);
  goldenBell.castShadow = true;
  earsDecorGroup.add(goldenBell);

  // Small slit on bell
  const bellSlit = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.012, 0.02), new THREE.MeshBasicMaterial({ color: 0x78350f }));
  bellSlit.position.set(0, 0.5, 0.79);
  earsDecorGroup.add(bellSlit);

  group.add(earsDecorGroup);

  // -------------------------------------------------------------
  // Stationery inside (gel pen, pencil, 15cm ruler, bunny eraser)
  // -------------------------------------------------------------
  const penGroup = new THREE.Group();
  penGroup.name = 'assembly_pens';
  penGroup.position.set(0, bodyH * 0.6, 0);

  // Clear gel pen with blue ink core
  const penBarrel = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.05, 1.45, 16),
    new THREE.MeshPhysicalMaterial({ transmission: 0.9, roughness: 0.1, thickness: 0.4 })
  );
  penBarrel.position.set(0.18, 0.4, 0);
  penBarrel.rotation.z = -0.15;
  penBarrel.castShadow = true;
  penGroup.add(penBarrel);

  const penInk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.02, 0.02, 1.1, 12),
    new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.2 })
  );
  penInk.position.set(0.18, 0.35, 0);
  penInk.rotation.z = -0.15;
  penGroup.add(penInk);

  // Yellow wooden pencil with pink eraser
  const pencilBody = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.55, 6), woodMat);
  pencilBody.position.set(-0.16, 0.45, 0.1);
  pencilBody.rotation.z = 0.18;
  pencilBody.castShadow = true;
  penGroup.add(pencilBody);

  // --- PEN HOLDER DECORATION 4: Cute Pink Bunny Eraser Topper ---
  const bunnyGroup = new THREE.Group();
  bunnyGroup.name = 'decorations';
  bunnyGroup.userData = { isDecoration: true };
  bunnyGroup.visible = showDecorations;
  bunnyGroup.position.set(-0.16, 1.25, 0.1);
  bunnyGroup.rotation.z = 0.18;

  const bunnyMat = new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.7 });
  const bunnyBody = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.16, 0.12), bunnyMat);
  bunnyGroup.add(bunnyBody);

  const earBL = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.14, 8), bunnyMat);
  earBL.position.set(-0.04, 0.14, 0);
  bunnyGroup.add(earBL);

  const earBR = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.14, 8), bunnyMat);
  earBR.position.set(0.04, 0.14, 0);
  bunnyGroup.add(earBR);
  penGroup.add(bunnyGroup);

  // --- PEN HOLDER DECORATION 5: Translucent Yellow 15cm School Ruler ---
  const rulerGroup = new THREE.Group();
  rulerGroup.name = 'decorations';
  rulerGroup.userData = { isDecoration: true };
  rulerGroup.visible = showDecorations;

  const rulerMat = new THREE.MeshPhysicalMaterial({
    color: 0xfde047,
    roughness: 0.15,
    transmission: 0.85,
    thickness: 0.2,
    transparent: true,
    opacity: 0.9,
  });
  const rulerMesh = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.55, 0.02), rulerMat);
  rulerMesh.position.set(-0.02, 0.5, -0.12);
  rulerMesh.rotation.z = -0.08;
  rulerMesh.rotation.x = -0.15;
  rulerMesh.castShadow = true;
  rulerGroup.add(rulerMesh);

  // Ruler tick marks
  const tickMat = new THREE.MeshBasicMaterial({ color: 0x854d0e });
  for (let t = 0; t < 12; t++) {
    const tick = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.008, 0.022), tickMat);
    tick.position.set(0.03, -0.6 + t * 0.11, 0);
    rulerMesh.add(tick);
  }
  penGroup.add(rulerGroup);

  group.add(penGroup);
  subparts.push({ mesh: penGroup, basePos: penGroup.position.clone(), explodeDir: new THREE.Vector3(0, 0.8, 0) });
}

// 4. Photorealistic Cardboard Miniature House (Ngôi Nhà Bìa Carton + Bồn Hoa Bậu Cửa & Dây Đèn LED)
function buildPhotorealCardboardHouseCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const kraftMat = createKraftCardboardMaterial();
  const glueMat = createHotGlueMaterial();
  const woodMat = createBambooAxleMaterial();

  const houseW = 1.8;
  const houseH = 1.3;
  const houseD = 1.5;

  // Main Kraft walls box
  const wallsGeo = new THREE.BoxGeometry(houseW, houseH, houseD);
  const wallsMesh = new THREE.Mesh(wallsGeo, kraftMat);
  wallsMesh.name = 'body';
  wallsMesh.position.y = houseH / 2;
  wallsMesh.castShadow = true;
  wallsMesh.receiveShadow = true;
  group.add(wallsMesh);
  subparts.push({ mesh: wallsMesh, basePos: wallsMesh.position.clone(), explodeDir: new THREE.Vector3(0, 0, 0) });

  // --- HOUSE DECORATION 1: Window Flower Planter Box with Blooming Daisies ---
  const houseDecorGroup = new THREE.Group();
  houseDecorGroup.name = 'decorations';
  houseDecorGroup.userData = { isDecoration: true };
  houseDecorGroup.visible = showDecorations;

  // Window frame cut
  const windowFrame = new THREE.Mesh(
    new THREE.BoxGeometry(0.55, 0.55, 0.02),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 })
  );
  windowFrame.position.set(-0.35, 0.82, houseD / 2 + 0.01);
  houseDecorGroup.add(windowFrame);

  // Planter box under window
  const planterBox = new THREE.Mesh(
    new THREE.BoxGeometry(0.65, 0.14, 0.18),
    new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.8 })
  );
  planterBox.position.set(-0.35, 0.5, houseD / 2 + 0.1);
  planterBox.castShadow = true;
  houseDecorGroup.add(planterBox);

  // Soil inside window box
  const boxSoil = new THREE.Mesh(
    new THREE.BoxGeometry(0.62, 0.04, 0.15),
    new THREE.MeshStandardMaterial({ color: 0x3f2e1e, roughness: 0.95 })
  );
  boxSoil.position.set(-0.35, 0.56, houseD / 2 + 0.1);
  houseDecorGroup.add(boxSoil);

  // 5 mini blooming flowers (white daisies with yellow centers)
  const daisyYellowMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.3 });
  const daisyWhiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });
  for (let f = 0; f < 5; f++) {
    const fx = -0.58 + f * 0.11;
    const center = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), daisyYellowMat);
    center.position.set(fx, 0.62, houseD / 2 + 0.1 + (f % 2) * 0.03);
    houseDecorGroup.add(center);

    const petals = new THREE.Mesh(new THREE.CircleGeometry(0.045, 6), daisyWhiteMat);
    petals.rotation.x = -0.3;
    petals.position.set(fx, 0.62, houseD / 2 + 0.1 + (f % 2) * 0.03);
    houseDecorGroup.add(petals);
  }

  // --- HOUSE DECORATION 2: Front Porch Wooden Step & Brass Doorknob ---
  const doorstep = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.06, 0.28), woodMat);
  doorstep.position.set(0.45, 0.03, houseD / 2 + 0.14);
  doorstep.castShadow = true;
  houseDecorGroup.add(doorstep);

  const door = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.8, 0.02),
    new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.7 })
  );
  door.position.set(0.45, 0.44, houseD / 2 + 0.01);
  houseDecorGroup.add(door);

  const doorknob = new THREE.Mesh(
    new THREE.SphereGeometry(0.032, 12, 12),
    new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.85, roughness: 0.2 })
  );
  doorknob.position.set(0.6, 0.44, houseD / 2 + 0.03);
  houseDecorGroup.add(doorknob);

  // Tiny craft picket fence beside porch
  for (let p = 0; p < 3; p++) {
    const post = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 0.32, 0.02),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 })
    );
    post.position.set(0.75 + p * 0.08, 0.16, houseD / 2 + 0.15);
    houseDecorGroup.add(post);
  }

  group.add(houseDecorGroup);

  // -------------------------------------------------------------
  // Corrugated Gable Roof with exposed fluting edge & Fairy Lights
  // -------------------------------------------------------------
  const roofGroup = new THREE.Group();
  roofGroup.name = 'top_roof';
  roofGroup.position.set(0, houseH, 0);

  const roofGeo = new THREE.ConeGeometry(1.3, 0.9, 4);
  const roofMesh = new THREE.Mesh(roofGeo, kraftMat);
  roofMesh.rotation.y = Math.PI / 4;
  roofMesh.scale.set(1.12, 1.0, 0.92);
  roofMesh.position.y = 0.45;
  roofMesh.castShadow = true;
  roofGroup.add(roofMesh);

  // Chimney made from folded carton
  const chimGeo = new THREE.BoxGeometry(0.26, 0.62, 0.26);
  const chimMesh = new THREE.Mesh(chimGeo, kraftMat);
  chimMesh.position.set(0.45, 0.6, 0.2);
  chimMesh.castShadow = true;
  roofGroup.add(chimMesh);

  // Visible hot glue bead along the roof ridge
  for (let z of [-0.3, 0, 0.3]) {
    const glueDrop = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 10), glueMat);
    glueDrop.position.set(0, 0.9, z);
    roofGroup.add(glueDrop);
  }

  // --- HOUSE DECORATION 3: Fairy String Lights with Glowing Colorful LEDs ---
  const fairyGroup = new THREE.Group();
  fairyGroup.name = 'decorations';
  fairyGroup.userData = { isDecoration: true };
  fairyGroup.visible = showDecorations;

  // Draped catenary wire along the front roof eaves
  const wireGeo = new THREE.CylinderGeometry(0.008, 0.008, 1.6, 16);
  const wireMesh = new THREE.Mesh(wireGeo, new THREE.MeshBasicMaterial({ color: 0x334155 }));
  wireMesh.rotation.z = Math.PI / 2;
  wireMesh.position.set(0, 0.08, houseD / 2 + 0.05);
  fairyGroup.add(wireMesh);

  // 7 colorful glowing mini LED droplets
  const ledColors = [0xfef08a, 0xfbcfe8, 0xa7f3d0, 0xbae6fd, 0xfde047, 0xf472b6, 0x6ee7b7];
  for (let i = 0; i < 7; i++) {
    const lx = -0.65 + i * 0.21;
    const ly = 0.04 - Math.sin((i / 6) * Math.PI) * 0.06; // catenary sag
    const col = ledColors[i % ledColors.length];
    const bulbMat = new THREE.MeshStandardMaterial({
      color: col,
      emissive: col,
      emissiveIntensity: 0.9,
      roughness: 0.1,
    });
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.038, 10, 10), bulbMat);
    bulb.scale.set(1.0, 1.35, 1.0);
    bulb.position.set(lx, ly, houseD / 2 + 0.06);
    fairyGroup.add(bulb);
  }

  roofGroup.add(fairyGroup);

  group.add(roofGroup);
  subparts.push({ mesh: roofGroup, basePos: roofGroup.position.clone(), explodeDir: new THREE.Vector3(0, 0.8, 0) });
}

// 5. Photorealistic Aluminum Tin Lantern (Đèn Lon Nhôm Đục Lỗ Nghệ Thuật + Dây Thừng Mộc)
function buildPhotorealTinLampCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const metalMat = createBrushedAluminumMaterial();
  const woodMat = createBambooAxleMaterial();

  const glowMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.2,
    roughness: 0.1,
  });

  const canH = 1.6;
  const canGeo = new THREE.CylinderGeometry(0.65, 0.65, canH, 48, 1, true);
  const canMesh = new THREE.Mesh(canGeo, metalMat);
  canMesh.name = 'body';
  canMesh.position.y = canH / 2;
  canMesh.castShadow = true;
  canMesh.receiveShadow = true;
  group.add(canMesh);
  subparts.push({ mesh: canMesh, basePos: canMesh.position.clone(), explodeDir: new THREE.Vector3(0, 0, 0) });

  // Stamped bottom rim
  const baseMesh = new THREE.Mesh(new THREE.CircleGeometry(0.65, 32), metalMat);
  baseMesh.name = 'bottom';
  baseMesh.rotation.x = Math.PI / 2;
  baseMesh.position.y = 0.01;
  group.add(baseMesh);

  // Warm LED Candle inside
  const ledMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.35, 24), glowMat);
  ledMesh.name = 'assembly';
  ledMesh.position.y = 0.2;
  group.add(ledMesh);
  subparts.push({ mesh: ledMesh, basePos: ledMesh.position.clone(), explodeDir: new THREE.Vector3(0, -0.4, 0) });

  // Punched holes pattern
  const holeMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
  for (let i = 0; i < 28; i++) {
    const angle = (i / 28) * Math.PI * 2;
    const y = 0.35 + (i % 6) * 0.18;
    const dotGeo = new THREE.SphereGeometry(0.032, 8, 8);
    const dot = new THREE.Mesh(dotGeo, holeMat);
    dot.position.set(Math.cos(angle) * 0.655, y, Math.sin(angle) * 0.655);
    group.add(dot);
  }

  // --- TIN LAMP DECORATION: Rustic Jute Ribbon & 4-Hole Wooden Button ---
  const tinDecorGroup = new THREE.Group();
  tinDecorGroup.name = 'decorations';
  tinDecorGroup.userData = { isDecoration: true };
  tinDecorGroup.visible = showDecorations;

  const ribbonMesh = new THREE.Mesh(
    new THREE.TorusGeometry(0.655, 0.024, 12, 48),
    new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.9 })
  );
  ribbonMesh.rotation.x = Math.PI / 2;
  ribbonMesh.position.set(0, canH - 0.18, 0);
  tinDecorGroup.add(ribbonMesh);

  const buttonMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.03, 24), woodMat);
  buttonMesh.rotation.x = Math.PI / 2;
  buttonMesh.position.set(0, canH - 0.18, 0.68);
  tinDecorGroup.add(buttonMesh);

  // Button thread cross
  const threadMat = new THREE.MeshBasicMaterial({ color: 0x92400e });
  const thread1 = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.01, 0.01), threadMat);
  thread1.position.set(0, canH - 0.18, 0.7);
  tinDecorGroup.add(thread1);

  group.add(tinDecorGroup);

  // Handle wire arch
  const handleGeo = new THREE.TorusGeometry(0.55, 0.02, 16, 32, Math.PI);
  const handleMesh = new THREE.Mesh(handleGeo, metalMat);
  handleMesh.name = 'top';
  handleMesh.position.set(0, canH, 0);
  handleMesh.castShadow = true;
  group.add(handleMesh);
  subparts.push({ mesh: handleMesh, basePos: handleMesh.position.clone(), explodeDir: new THREE.Vector3(0, 0.5, 0) });
}

// 6. Photorealistic Tiered Desk Organizer (Kệ Bậc Thang Bìa Carton + Post-it & Kẹp Giấy Xinh)
function buildPhotorealDeskOrganizerCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const kraftMat = createKraftCardboardMaterial();

  const baseMesh = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.1, 1.4), kraftMat);
  baseMesh.name = 'bottom';
  baseMesh.position.set(0, 0.05, 0);
  baseMesh.castShadow = true;
  baseMesh.receiveShadow = true;
  group.add(baseMesh);

  const tier1 = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.5, 0.4), kraftMat);
  tier1.name = 'body';
  tier1.position.set(0, 0.35, 0.45);
  tier1.castShadow = true;
  group.add(tier1);
  subparts.push({ mesh: tier1, basePos: tier1.position.clone(), explodeDir: new THREE.Vector3(0, 0, 0.4) });

  // --- ORGANIZER DECORATION: Canary Yellow Sticky Notes Pad & Pastel Paperclips ---
  const orgDecorGroup = new THREE.Group();
  orgDecorGroup.name = 'decorations';
  orgDecorGroup.userData = { isDecoration: true };
  orgDecorGroup.visible = showDecorations;

  const postIt = new THREE.Mesh(
    new THREE.BoxGeometry(0.36, 0.04, 0.36),
    new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.6 })
  );
  postIt.position.set(-0.45, 0.62, 0.45);
  orgDecorGroup.add(postIt);

  // 3 colorful paperclips
  const clipColors = [0xec4899, 0x3b82f6, 0x10b981];
  for (let c = 0; c < 3; c++) {
    const clip = new THREE.Mesh(
      new THREE.TorusGeometry(0.045, 0.008, 8, 16, Math.PI),
      new THREE.MeshStandardMaterial({ color: clipColors[c], metalness: 0.7, roughness: 0.3 })
    );
    clip.position.set(0.3 + c * 0.12, 0.62, 0.45);
    clip.rotation.x = -Math.PI / 2;
    orgDecorGroup.add(clip);
  }
  tier1.add(orgDecorGroup);

  const tier2 = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.9, 0.4), kraftMat);
  tier2.name = 'body';
  tier2.position.set(0, 0.55, 0);
  tier2.castShadow = true;
  group.add(tier2);
  subparts.push({ mesh: tier2, basePos: tier2.position.clone(), explodeDir: new THREE.Vector3(0, 0.2, 0) });

  const tier3 = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.3, 0.4), kraftMat);
  tier3.name = 'assembly';
  tier3.position.set(0, 0.75, -0.45);
  tier3.castShadow = true;
  group.add(tier3);
  subparts.push({ mesh: tier3, basePos: tier3.position.clone(), explodeDir: new THREE.Vector3(0, 0, -0.4) });
}

// 7. Photorealistic Denim Fish Bag (Túi Cá Vải Jean Cũ + Vây Bơi 3D & Má Hồng Thêu)
function buildPhotorealFabricToteCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const denimDarkMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.88 });
  const denimLightMat = new THREE.MeshStandardMaterial({ color: 0x60a5fa, roughness: 0.88 });
  const woodButtonMat = createBambooAxleMaterial();

  const pouchGroup = new THREE.Group();
  pouchGroup.name = 'body';
  pouchGroup.position.set(0, 1.2, 0);

  const mainPouch = new THREE.Mesh(new THREE.CapsuleGeometry(0.65, 1.2, 16, 32), denimDarkMat);
  mainPouch.scale.set(1.0, 1.2, 0.5);
  mainPouch.castShadow = true;
  pouchGroup.add(mainPouch);

  for (let row = 0; row < 4; row++) {
    const y = -0.5 + row * 0.3;
    const isEven = row % 2 === 0;
    const count = isEven ? 3 : 2;
    for (let c = 0; c < count; c++) {
      const x = (c - (count - 1) / 2) * 0.38;
      const scaleMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.18, 0.18, 0.05, 16, 1, false, 0, Math.PI),
        isEven ? denimLightMat : denimDarkMat
      );
      scaleMesh.rotation.x = Math.PI / 2;
      scaleMesh.position.set(x, y, 0.28);
      pouchGroup.add(scaleMesh);
    }
  }

  // Wooden button eyes
  const eyeL = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.06, 16), woodButtonMat);
  eyeL.rotation.x = Math.PI / 2;
  eyeL.position.set(0.35, 0.7, 0.26);
  pouchGroup.add(eyeL);

  const eyeR = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.06, 16), woodButtonMat);
  eyeR.rotation.x = Math.PI / 2;
  eyeR.position.set(-0.35, 0.7, 0.26);
  pouchGroup.add(eyeR);

  // --- FABRIC FISH DECORATION: 3D Swimming Side Fins & Tail Fin ---
  const fishDecorGroup = new THREE.Group();
  fishDecorGroup.name = 'decorations';
  fishDecorGroup.userData = { isDecoration: true };
  fishDecorGroup.visible = showDecorations;

  // Pair of side fins
  for (let s of [-1, 1]) {
    const sideFin = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.45, 3), denimLightMat);
    sideFin.scale.set(1.0, 1.0, 0.15);
    sideFin.rotation.z = s * 0.9;
    sideFin.rotation.y = s * 0.2;
    sideFin.position.set(s * 0.78, 0.1, 0.1);
    sideFin.castShadow = true;
    fishDecorGroup.add(sideFin);
  }

  // Cute embroidered blush stitches under eyes
  const stitchMat = new THREE.MeshBasicMaterial({ color: 0xf472b6 });
  for (let s of [-1, 1]) {
    const blushStitch = new THREE.Mesh(new THREE.CircleGeometry(0.065, 16), stitchMat);
    blushStitch.position.set(s * 0.35, 0.52, 0.28);
    fishDecorGroup.add(blushStitch);
  }

  pouchGroup.add(fishDecorGroup);

  group.add(pouchGroup);
  subparts.push({ mesh: pouchGroup, basePos: pouchGroup.position.clone(), explodeDir: new THREE.Vector3(0, 0.3, 0) });
}

// 8. Photorealistic Bottle Cap Turtle Figure (Chú Rùa Nắp Chai Nhựa + Hoa Văn Lục Giác & Nơ Xinh)
function buildPhotorealCapMosaicCraft(
  group: THREE.Group,
  subparts: { mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3 }[],
  showDecorations: boolean = true
) {
  const capMatGreen = createHDPECapMaterial(0x15803d);
  const foamMat = new THREE.MeshStandardMaterial({ color: 0x86efac, roughness: 0.85 });
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });

  const turtleGroup = new THREE.Group();
  turtleGroup.name = 'body';
  turtleGroup.position.set(0, 0.4, 0);

  const shell = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.72, 0.42, 32), capMatGreen);
  shell.castShadow = true;
  turtleGroup.add(shell);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 16), foamMat);
  head.position.set(0, 0.05, 0.85);
  head.castShadow = true;
  turtleGroup.add(head);

  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), eyeMat);
  eyeL.position.set(0.14, 0.22, 0.98);
  turtleGroup.add(eyeL);

  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), eyeMat);
  eyeR.position.set(-0.14, 0.22, 0.98);
  turtleGroup.add(eyeR);

  // --- TURTLE DECORATION: Hexagonal Gold Shell Plates & Sweet Pink Head Bow ---
  const turtleDecorGroup = new THREE.Group();
  turtleDecorGroup.name = 'decorations';
  turtleDecorGroup.userData = { isDecoration: true };
  turtleDecorGroup.visible = showDecorations;

  // Center gold hexagonal emblem
  const plateMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.4, metalness: 0.1 });
  const centerPlate = new THREE.Mesh(new THREE.CircleGeometry(0.24, 6), plateMat);
  centerPlate.rotation.x = -Math.PI / 2;
  centerPlate.position.set(0, 0.22, 0);
  turtleDecorGroup.add(centerPlate);

  // 5 surrounding shell plates
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    const ringPlate = new THREE.Mesh(new THREE.CircleGeometry(0.15, 6), plateMat);
    ringPlate.rotation.x = -Math.PI / 2;
    ringPlate.position.set(Math.cos(a) * 0.45, 0.22, Math.sin(a) * 0.45);
    turtleDecorGroup.add(ringPlate);
  }

  // Sweet bow on turtle's head
  const bowMat = new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.5 });
  const bowL = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.15, 4), bowMat);
  bowL.position.set(0.18, 0.35, 0.85);
  bowL.rotation.z = -0.5;
  turtleDecorGroup.add(bowL);

  const bowR = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.15, 4), bowMat);
  bowR.position.set(0.28, 0.35, 0.85);
  bowR.rotation.z = 0.5;
  turtleDecorGroup.add(bowR);

  turtleGroup.add(turtleDecorGroup);

  group.add(turtleGroup);
  subparts.push({ mesh: turtleGroup, basePos: turtleGroup.position.clone(), explodeDir: new THREE.Vector3(0, 0.4, 0) });
}

