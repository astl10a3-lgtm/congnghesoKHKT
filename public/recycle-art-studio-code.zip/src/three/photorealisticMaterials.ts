import * as THREE from 'three';
import {
  getRecycledPETTextures,
  getCutEdgeNormalTexture,
  getBottleCapTextures,
  getKraftCardboardTexture,
  getBambooWoodTexture,
  getPottingSoilTexture,
} from './photorealisticTextures';

/**
 * Creates realistic recycled PET plastic material with transmission, clearcoat,
 * subtle micro-scratches, and authentic physical index of refraction (IOR 1.52).
 */
export function createRecycledPETMaterial(options?: {
  tintColor?: number;
  transmission?: number;
  roughness?: number;
}): THREE.MeshPhysicalMaterial {
  const { normalMap, roughnessMap } = getRecycledPETTextures();

  return new THREE.MeshPhysicalMaterial({
    color: options?.tintColor ?? 0xffffff,
    metalness: 0.02,
    roughness: options?.roughness ?? 0.22,
    transmission: options?.transmission ?? 0.84,
    thickness: 0.7,
    ior: 1.52, // Authentic PET plastic IOR
    attenuationColor: new THREE.Color(0xdbeafe),
    attenuationDistance: 2.2,
    clearcoat: 0.88,
    clearcoatRoughness: 0.18,
    normalMap: normalMap,
    normalScale: new THREE.Vector2(0.4, 0.4),
    roughnessMap: roughnessMap,
    transparent: true,
    opacity: 1.0,
    depthWrite: false, // Essential for proper nested refraction
    side: THREE.DoubleSide,
  });
}

/**
 * Creates material for the sheared hand-cut edge (gờ cắt thủ công).
 * Shows the slightly frosted, micro-serrated cut lip where the scissors or cutter made contact.
 */
export function createHandCutLipMaterial(): THREE.MeshPhysicalMaterial {
  const normalMap = getCutEdgeNormalTexture();

  return new THREE.MeshPhysicalMaterial({
    color: 0xf1f5f9,
    metalness: 0.04,
    roughness: 0.42,
    transmission: 0.45,
    thickness: 0.4,
    ior: 1.52,
    clearcoat: 0.4,
    clearcoatRoughness: 0.3,
    normalMap: normalMap,
    normalScale: new THREE.Vector2(0.8, 0.8),
    transparent: true,
    opacity: 0.95,
    depthWrite: true,
    side: THREE.DoubleSide,
  });
}

/**
 * Creates HDPE bottle cap material with molded side flutes and mold sprue pip.
 */
export function createHDPECapMaterial(colorHex: number): THREE.MeshStandardMaterial {
  const { bumpMap } = getBottleCapTextures();

  return new THREE.MeshStandardMaterial({
    color: colorHex,
    roughness: 0.36,
    metalness: 0.03,
    bumpMap: bumpMap,
    bumpScale: 0.04,
  });
}

/**
 * Creates realistic hot melt glue droplet (keo nến trong suốt có độ bóng cao).
 */
export function createHotGlueMaterial(): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    metalness: 0.0,
    roughness: 0.14,
    transmission: 0.75,
    thickness: 0.5,
    ior: 1.48,
    clearcoat: 1.0,
    clearcoatRoughness: 0.08,
    transparent: true,
    opacity: 0.9,
    depthWrite: false,
  });
}

/**
 * Creates bamboo skewer / wooden axle material with real wood grain.
 */
export function createBambooAxleMaterial(): THREE.MeshStandardMaterial {
  const woodTex = getBambooWoodTexture();

  return new THREE.MeshStandardMaterial({
    color: 0xdeb887,
    roughness: 0.72,
    metalness: 0.02,
    map: woodTex,
    bumpMap: woodTex,
    bumpScale: 0.02,
  });
}

/**
 * Creates realistic organic potting soil with white perlite specks.
 */
export function createPottingSoilMaterial(): THREE.MeshStandardMaterial {
  const soilTex = getPottingSoilTexture();

  return new THREE.MeshStandardMaterial({
    map: soilTex,
    bumpMap: soilTex,
    bumpScale: 0.05,
    roughness: 0.96,
    metalness: 0.01,
  });
}

/**
 * Creates Kraft cardboard material with fibers and corrugated ridges.
 */
export function createKraftCardboardMaterial(): THREE.MeshStandardMaterial {
  const { colorMap, bumpMap } = getKraftCardboardTexture();

  return new THREE.MeshStandardMaterial({
    map: colorMap,
    bumpMap: bumpMap,
    bumpScale: 0.03,
    roughness: 0.88,
    metalness: 0.01,
  });
}

/**
 * Creates brushed aluminum tin can material with realistic anisotropic highlights.
 */
export function createBrushedAluminumMaterial(): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color: 0xa8b2c1,
    metalness: 0.88,
    roughness: 0.28,
  });
}
