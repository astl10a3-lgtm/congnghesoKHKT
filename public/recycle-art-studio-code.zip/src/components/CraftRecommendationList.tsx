import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  TreePine,
  Layers,
  Clock,
  Hammer,
  ArrowRight,
  Filter,
  DollarSign,
  CheckCircle,
  PlusCircle,
  HelpCircle,
  AlertCircle,
  Wand2,
  RefreshCw,
  Box,
  Image as ImageIcon,
  Check
} from 'lucide-react';
import { CraftProduct } from '../../server/db';

interface CraftRecommendationListProps {
  group100Percent: CraftProduct[];
  groupWithAddedMaterials: CraftProduct[];
  onSelectCraft: (craft: CraftProduct) => void;
  onUpdateCraft?: (updated: CraftProduct) => void;
}

export const CraftRecommendationList: React.FC<CraftRecommendationListProps> = ({
  group100Percent,
  groupWithAddedMaterials,
  onSelectCraft,
  onUpdateCraft,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | '100_percent' | 'with_added'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'recycled_ratio' | 'easiest' | 'fastest' | 'lowest_cost'>('recycled_ratio');

  const categories = [
    { id: 'all', label: 'Tất cả danh mục' },
    { id: 'garden', label: 'Làm vườn & Cây xanh' },
    { id: 'study', label: 'Đồ dùng học tập' },
    { id: 'decor', label: 'Trang trí phòng' },
    { id: 'stem_toy', label: 'Đồ chơi STEM' },
    { id: 'home', label: 'Gia đình' },
  ];

  // Filter & sort logic
  const filtered100 = useMemo(() => {
    let list = [...group100Percent];
    if (selectedCategory !== 'all') {
      list = list.filter((c) => c.category === selectedCategory);
    }
    return list;
  }, [group100Percent, selectedCategory]);

  const filteredAdded = useMemo(() => {
    let list = [...groupWithAddedMaterials];
    if (selectedCategory !== 'all') {
      list = list.filter((c) => c.category === selectedCategory);
    }
    return list;
  }, [groupWithAddedMaterials, selectedCategory]);

  const sortProducts = (products: CraftProduct[]) => {
    return [...products].sort((a, b) => {
      if (sortBy === 'recycled_ratio') {
        return b.recycledMaterialRatio - a.recycledMaterialRatio;
      }
      if (sortBy === 'fastest') {
        const timeA = parseInt(a.estimatedTime) || 30;
        const timeB = parseInt(b.estimatedTime) || 30;
        return timeA - timeB;
      }
      if (sortBy === 'easiest') {
        const diffRank: Record<string, number> = { Dễ: 1, 'Trung bình': 2, Khó: 3 };
        return (diffRank[a.difficulty] || 2) - (diffRank[b.difficulty] || 2);
      }
      if (sortBy === 'lowest_cost') {
        const costA = a.materialsNeededExtra.reduce((acc, m) => acc + m.estimatedCostVnd, 0);
        const costB = b.materialsNeededExtra.reduce((acc, m) => acc + m.estimatedCostVnd, 0);
        return costA - costB;
      }
      return 0;
    });
  };

  const sorted100 = useMemo(() => sortProducts(filtered100), [filtered100, sortBy]);
  const sortedAdded = useMemo(() => sortProducts(filteredAdded), [filteredAdded, sortBy]);

  return (
    <div className="space-y-10 py-4">
      {/* Header and Filter Bar */}
      <div className="space-y-4">
        <div className="text-center max-w-2xl mx-auto space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>BƯỚC 5: ĐỀ XUẤT SẢN PHẨM TÁI CHẾ VỚI GEMINI & CHATGPT</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Ý tưởng sáng tạo được tối ưu theo vật liệu của bạn
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Hệ thống AI phân loại rõ ràng 2 nhóm sản phẩm. Nếu món đồ nào chưa có hình ảnh, bạn có thể bấm để Gemini hoặc ChatGPT vẽ mô hình 3D mô phỏng tương tác ngay lập tức.
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Mode Pill Filter */}
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 w-full md:w-auto">
            <button
              onClick={() => setFilterMode('all')}
              className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                filterMode === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả ({group100Percent.length + groupWithAddedMaterials.length})
            </button>
            <button
              onClick={() => setFilterMode('100_percent')}
              className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                filterMode === '100_percent'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-emerald-700 hover:text-emerald-900'
              }`}
            >
              <span>🌿 100% Có sẵn</span>
              <span className="text-[10px] opacity-80">({group100Percent.length})</span>
            </button>
            <button
              onClick={() => setFilterMode('with_added')}
              className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                filterMode === 'with_added'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-indigo-700 hover:text-indigo-900'
              }`}
            >
              <span>✨ Thêm phụ liệu</span>
              <span className="text-[10px] opacity-80">({groupWithAddedMaterials.length})</span>
            </button>
          </div>

          {/* Category & Sorting Selectors */}
          <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="p-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="p-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white"
            >
              <option value="recycled_ratio">Tận dụng nhiều rác nhất (%)</option>
              <option value="lowest_cost">Ít tốn chi phí mua thêm nhất</option>
              <option value="easiest">Dễ thực hiện nhất</option>
              <option value="fastest">Thời gian ngắn nhất</option>
            </select>
          </div>
        </div>
      </div>

      {/* SECTION 1: NHÓM 1: 100% RECYCLED MATERIALS */}
      {(filterMode === 'all' || filterMode === '100_percent') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-emerald-200">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                1
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
                  <span>Khu vực 1: Sáng tạo 100% từ vật liệu của bạn</span>
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                    Không cần mua thêm
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Tận dụng tối đa rác thải đã tải lên, không tốn thêm chi phí nguyên liệu.
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-emerald-700 hidden sm:inline">
              {sorted100.length} sản phẩm
            </span>
          </div>

          {sorted100.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
              Không có sản phẩm nào phù hợp với bộ lọc hiện tại trong nhóm này.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sorted100.map((craft) => (
                <CraftCard
                  key={craft.id}
                  craft={craft}
                  onSelect={onSelectCraft}
                  onUpdateCraft={onUpdateCraft}
                />
              ))}
            </div>
          )}
        </section>
      )}

      {/* SECTION 2: NHÓM 2: COMBINED WITH ADDED MATERIALS */}
      {(filterMode === 'all' || filterMode === 'with_added') && (
        <section className="space-y-4 pt-4">
          <div className="flex items-center justify-between pb-2 border-b border-indigo-200">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                2
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
                  <span>Khu vực 2: Mở rộng sáng tạo với vật liệu bổ sung</span>
                  <span className="text-xs font-bold text-indigo-800 bg-indigo-100 px-2 py-0.5 rounded-full">
                    Phụ liệu dễ tìm & an toàn
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Vật liệu tái chế đóng vai trò chủ đạo, kết hợp phụ liệu chi phí thấp (đèn LED 3V, sỏi, dây bấc...).
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-indigo-700 hidden sm:inline">
              {sortedAdded.length} sản phẩm
            </span>
          </div>

          {sortedAdded.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
              Không có sản phẩm nào phù hợp với bộ lọc hiện tại trong nhóm này.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedAdded.map((craft) => (
                <CraftCard
                  key={craft.id}
                  craft={craft}
                  onSelect={onSelectCraft}
                  onUpdateCraft={onUpdateCraft}
                />
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
};

// Sub-component: Craft Card with 3D Simulation Generator
const CraftCard: React.FC<{
  craft: CraftProduct;
  onSelect: (craft: CraftProduct) => void;
  onUpdateCraft?: (craft: CraftProduct) => void;
}> = ({ craft, onSelect, onUpdateCraft }) => {
  const is100 = craft.type === '100_percent_recycled';
  const totalExtraCost = craft.materialsNeededExtra.reduce((acc, m) => acc + m.estimatedCostVnd, 0);

  const [currentCraft, setCurrentCraft] = useState<CraftProduct>(craft);
  const [isGenerating3D, setIsGenerating3D] = useState<boolean>(false);
  const [showEngineOptions, setShowEngineOptions] = useState<boolean>(false);
  const [generationMsg, setGenerationMsg] = useState<string | null>(null);

  // Sync state if prop changes
  React.useEffect(() => {
    setCurrentCraft(craft);
  }, [craft]);

  const hasMissingImage = currentCraft.imageStatus === 'pending' || !currentCraft.imageUrl;

  const handleGenerate3DVisual = async (engine: 'gemini' | 'chatgpt') => {
    setIsGenerating3D(true);
    setShowEngineOptions(false);
    setGenerationMsg(
      engine === 'gemini'
        ? 'Gemini đang vẽ bản vẽ 3D Isometric...'
        : 'ChatGPT-4o đang mô phỏng cấu trúc 3D...'
    );

    try {
      const res = await fetch('/api/generate-craft-visual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          craftId: currentCraft.id,
          craftTitle: currentCraft.title,
          category: currentCraft.category,
          materialName: currentCraft.materialsUsed?.[0]?.name || 'Vật liệu tái chế',
          aiEngine: engine,
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Lỗi khi vẽ mô hình 3D');
      }

      const updated: CraftProduct = {
        ...currentCraft,
        imageUrl: json.data.imageUrl,
        model3DType: json.data.model3DType,
        imageStatus: 'completed',
        guideStatus: 'completed',
        steps: (json.data.enhancedSteps && json.data.enhancedSteps.length > 0)
          ? json.data.enhancedSteps
          : currentCraft.steps,
      };

      setCurrentCraft(updated);
      if (onUpdateCraft) {
        onUpdateCraft(updated);
      }
      setGenerationMsg(`Đã tạo mô hình 3D thành công bằng ${engine === 'gemini' ? 'Gemini' : 'ChatGPT'}!`);
      setTimeout(() => setGenerationMsg(null), 3000);
    } catch (err: any) {
      console.error('Error generating 3D visual:', err);
      setGenerationMsg('Lỗi khi vẽ 3D, vui lòng thử lại.');
      setTimeout(() => setGenerationMsg(null), 3000);
    } finally {
      setIsGenerating3D(false);
    }
  };

  return (
    <div className="flex flex-col rounded-3xl bg-white border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-xl hover:border-emerald-300 transition duration-300 group">
      {/* Cover Image / 3D Simulation Viewport */}
      <div className="relative h-52 w-full bg-slate-900 overflow-hidden flex items-center justify-center">
        {currentCraft.imageUrl && !hasMissingImage ? (
          <img
            src={currentCraft.imageUrl}
            alt={currentCraft.title}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-center space-y-3">
            <Box className="w-10 h-10 text-indigo-400 animate-pulse" />
            <div className="space-y-1">
              <span className="text-white text-xs font-bold block">
                Chưa có ảnh chụp thực tế
              </span>
              <p className="text-[11px] text-slate-300 max-w-xs">
                Bạn có thể dùng ChatGPT hoặc Gemini để vẽ mô hình 3D mô phỏng ngay bên dưới.
              </p>
            </div>
          </div>
        )}

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 z-10 pointer-events-none">
          <span
            className={`px-3 py-1 rounded-xl text-[11px] font-extrabold shadow-sm ${
              is100 ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white'
            }`}
          >
            {is100 ? '🌿 100% Rác tái chế' : '✨ Có phụ liệu an toàn'}
          </span>
          {hasMissingImage && (
            <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black bg-purple-600 text-white shadow-sm flex items-center gap-1">
              <Wand2 className="w-3 h-3" />
              <span>Chờ AI dựng 3D</span>
            </span>
          )}
        </div>

        {/* 3D Model Badge & Quick Time */}
        <div className="absolute bottom-3 right-3 bg-slate-900/85 backdrop-blur-md text-white text-[11px] px-2.5 py-1 rounded-lg font-medium flex items-center gap-1.5 z-10">
          <Clock className="w-3.5 h-3.5 text-emerald-400" />
          <span>{currentCraft.estimatedTime}</span>
          <span>•</span>
          <span className="font-semibold text-teal-300">3D: {currentCraft.model3DType}</span>
        </div>

        {/* Quick AI 3D Draw Overlay button on image */}
        <div className="absolute top-3 right-3 z-10">
          <button
            type="button"
            onClick={() => setShowEngineOptions(!showEngineOptions)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-900 text-white text-[11px] font-bold backdrop-blur-md border border-white/20 shadow-md flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            title="Dùng ChatGPT hoặc Gemini để vẽ mô hình 3D mô phỏng"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{hasMissingImage ? 'Vẽ 3D' : 'Vẽ lại 3D'}</span>
          </button>
        </div>

        {/* Engine Dropdown selection */}
        {showEngineOptions && (
          <div className="absolute top-12 right-3 z-20 bg-white p-2 rounded-2xl shadow-2xl border border-slate-200 text-xs space-y-1.5 w-52 animate-in fade-in">
            <div className="px-2 py-1 font-bold text-slate-700 text-[11px] border-b border-slate-100 flex items-center justify-between">
              <span>Chọn AI vẽ mô hình 3D:</span>
              <button
                onClick={() => setShowEngineOptions(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>
            <button
              onClick={() => handleGenerate3DVisual('gemini')}
              className="w-full text-left p-2 rounded-xl hover:bg-emerald-50 text-emerald-800 font-semibold flex items-center gap-2 transition cursor-pointer"
            >
              <span>🌟</span>
              <div>
                <span className="block font-bold">Google Gemini 3.8</span>
                <span className="text-[10px] text-emerald-600 block">Dựng bản vẽ kỹ thuật 3D</span>
              </div>
            </button>
            <button
              onClick={() => handleGenerate3DVisual('chatgpt')}
              className="w-full text-left p-2 rounded-xl hover:bg-indigo-50 text-indigo-800 font-semibold flex items-center gap-2 transition cursor-pointer"
            >
              <span>🤖</span>
              <div>
                <span className="block font-bold">OpenAI ChatGPT-4o</span>
                <span className="text-[10px] text-indigo-600 block">Mô phỏng phối cảnh sáng tạo</span>
              </div>
            </button>
          </div>
        )}

        {/* Loading Spinner during Generation */}
        {isGenerating3D && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-30 space-y-2">
            <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
            <span className="text-white text-xs font-bold">{generationMsg}</span>
          </div>
        )}
      </div>

      {/* Generation Status Feedback Toast */}
      {generationMsg && !isGenerating3D && (
        <div className="bg-emerald-50 border-b border-emerald-100 text-emerald-800 text-xs px-4 py-1.5 flex items-center justify-center gap-1.5 font-semibold">
          <Check className="w-3.5 h-3.5 text-emerald-600" />
          <span>{generationMsg}</span>
        </div>
      )}

      {/* Content */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold text-slate-500 uppercase">{currentCraft.categoryLabel}</span>
            <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              {currentCraft.recycledMaterialRatio}% Tái chế
            </span>
          </div>

          <h3 className="font-bold text-slate-900 text-base group-hover:text-emerald-700 transition line-clamp-1">
            {currentCraft.title}
          </h3>

          <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
            {currentCraft.description}
          </p>
        </div>

        {/* Prominent Action for Missing Image */}
        {hasMissingImage && (
          <div className="p-3 rounded-2xl bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200/80 space-y-2">
            <div className="flex items-center gap-2 text-indigo-900 font-bold text-xs">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Chưa có ảnh: Dùng AI vẽ mô hình 3D</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleGenerate3DVisual('gemini')}
                disabled={isGenerating3D}
                className="py-1.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-xs flex items-center justify-center gap-1 transition cursor-pointer"
              >
                <span>🌟 Gemini 3D</span>
              </button>
              <button
                type="button"
                onClick={() => handleGenerate3DVisual('chatgpt')}
                disabled={isGenerating3D}
                className="py-1.5 px-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] shadow-xs flex items-center justify-center gap-1 transition cursor-pointer"
              >
                <span>🤖 ChatGPT 3D</span>
              </button>
            </div>
          </div>
        )}

        {/* Materials Summary List */}
        <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs">
          <p className="font-semibold text-slate-700 text-[11px] flex items-center justify-between">
            <span>Nguyên liệu sử dụng:</span>
            {totalExtraCost > 0 ? (
              <span className="text-amber-700 font-bold">
                Phụ liệu: ~{totalExtraCost.toLocaleString('vi-VN')} đ
              </span>
            ) : (
              <span className="text-emerald-700 font-bold">0 đ bổ sung</span>
            )}
          </p>

          <div className="space-y-1">
            {currentCraft.materialsUsed.map((m, i) => (
              <div key={i} className="flex items-center gap-1.5 text-slate-600 text-[11px]">
                <CheckCircle className="w-3 h-3 text-emerald-600 shrink-0" />
                <span className="truncate">{m.name}</span>
                <span className="text-[10px] text-slate-400">({m.role})</span>
              </div>
            ))}

            {currentCraft.materialsNeededExtra.map((extra, idx) => (
              <div key={idx} className="flex items-center gap-1.5 text-indigo-700 text-[11px]">
                <PlusCircle className="w-3 h-3 text-indigo-500 shrink-0" />
                <span className="truncate">{extra.name}</span>
                <span className="text-[10px] text-slate-400">({extra.purpose})</span>
              </div>
            ))}
          </div>
        </div>

        {/* Finished Dimensions */}
        <div className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xl flex items-center justify-between">
          <span>Kích thước sản phẩm:</span>
          <span className="font-mono font-medium text-slate-700">
            {currentCraft.dimensionsFinished.lengthCm} × {currentCraft.dimensionsFinished.widthCm} ×{' '}
            {currentCraft.dimensionsFinished.heightCm} cm
          </span>
        </div>

        {/* Action Button */}
        <button
          onClick={() => onSelect(currentCraft)}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
        >
          <Hammer className="w-4 h-4" />
          <span>Vào Xưởng Chế Tạo 3D ({currentCraft.steps.length} bước)</span>
        </button>
      </div>
    </div>
  );
};
