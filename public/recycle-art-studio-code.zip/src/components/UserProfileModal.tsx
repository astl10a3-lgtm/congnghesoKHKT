import React, { useState } from 'react';
import {
  X,
  Award,
  TreePine,
  Heart,
  CheckCircle,
  Calendar,
  Edit2,
  Save,
  Recycle,
  Sparkles
} from 'lucide-react';
import { UserProfile } from '../../server/db';

interface UserProfileModalProps {
  user: UserProfile;
  onClose: () => void;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  user,
  onClose,
  onUpdateProfile,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [bio, setBio] = useState(user.bio);

  const handleSave = () => {
    onUpdateProfile({ name: name.trim(), bio: bio.trim() });
    setIsEditing(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl p-6 sm:p-8 space-y-6 border border-slate-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* User Card Top */}
        <div className="flex items-center gap-4">
          <img
            src={user.avatar}
            alt={user.name}
            className="w-16 h-16 rounded-2xl object-cover ring-4 ring-emerald-500/20 shadow-md"
          />
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-slate-900 text-lg sm:text-xl">{user.name}</h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                Thành viên Xanh
              </span>
            </div>
            <p className="text-xs text-slate-500 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>Tham gia từ: {user.joinedDate}</span>
            </p>
          </div>
        </div>

        {/* Bio Section */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs text-slate-700 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-900">Giới thiệu & Mục tiêu xanh:</span>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="text-emerald-700 hover:underline font-bold text-[11px] flex items-center gap-1"
            >
              <Edit2 className="w-3 h-3" />
              <span>{isEditing ? 'Hủy' : 'Chỉnh sửa'}</span>
            </button>
          </div>

          {isEditing ? (
            <div className="space-y-3 pt-1">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Tên hiển thị"
                className="w-full p-2 rounded-lg border bg-white"
              />
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full p-2 rounded-lg border bg-white"
              />
              <button
                onClick={handleSave}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Lưu thông tin</span>
              </button>
            </div>
          ) : (
            <p className="leading-relaxed italic">{user.bio}</p>
          )}
        </div>

        {/* Environmental Statistics Cards */}
        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
            <TreePine className="w-5 h-5 text-emerald-600 mx-auto" />
            <p className="text-xl font-black text-emerald-700">{user.savedWasteKg} kg</p>
            <p className="text-[11px] text-emerald-800 font-semibold leading-tight">
              Rác thải đã giảm
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 space-y-1">
            <CheckCircle className="w-5 h-5 text-teal-600 mx-auto" />
            <p className="text-xl font-black text-teal-700">{user.totalCraftsMade}</p>
            <p className="text-[11px] text-teal-800 font-semibold leading-tight">
              Đồ thủ công hoàn thành
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-1">
            <Heart className="w-5 h-5 text-rose-500 mx-auto fill-rose-500" />
            <p className="text-xl font-black text-rose-600">{user.totalLikesReceived}</p>
            <p className="text-[11px] text-rose-800 font-semibold leading-tight">
              Lượt tim nhận được
            </p>
          </div>
        </div>

        {/* Environmental Badge */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center gap-3 text-xs">
          <Award className="w-6 h-6 text-emerald-200 shrink-0" />
          <p className="leading-relaxed">
            Huy hiệu <strong>"Đại Sứ Tái Chế Cấp 2"</strong>: Bạn đã đóng góp giảm phát thải carbon và truyền cảm hứng lối sống xanh cho cộng đồng học đường!
          </p>
        </div>
      </div>
    </div>
  );
};
