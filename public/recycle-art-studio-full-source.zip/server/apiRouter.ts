import { Router } from 'express';
import { db } from './db.ts';
import type { CommunityComment, UserProject, CommunityPost, MaterialItem } from './db.ts';
import { analyzeRecycleMaterials } from './gemini.ts';

export const apiRouter = Router();

// Check API status
apiRouter.get('/status', (req, res) => {
  const hasGemini = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  const hasOpenAi = Boolean(process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== 'MY_OPENAI_API_KEY');
  res.json({
    success: true,
    hasGeminiApiKey: hasGemini,
    hasOpenAiApiKey: hasOpenAi,
    availableEngines: ['gemini', 'chatgpt', 'dual'],
    defaultEngine: 'gemini',
    model: 'gemini-3.8-flash & gpt-4o',
    appName: 'Recycle Art Studio',
    timestamp: new Date().toISOString()
  });
});

// AI Multimodal Material Analysis (Supports Gemini 3.8 Flash, OpenAI ChatGPT-4o, and Dual Mode)
apiRouter.post('/analyze-materials', async (req, res) => {
  try {
    const { images, angles, referenceObject, userNotes, aiEngine, openaiApiKey } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ error: 'Cần cung cấp ít nhất 1 hình ảnh vật liệu.' });
    }

    const result = await analyzeRecycleMaterials({
      images,
      angles,
      referenceObject,
      userNotes,
      aiEngine,
      openaiApiKey
    });

    res.json({
      success: true,
      data: result
    });
  } catch (err: any) {
    console.error('API Error in /api/analyze-materials:', err);
    res.status(500).json({
      error: 'Lỗi phân tích hình ảnh AI: ' + (err?.message || 'Không xác định')
    });
  }
});

// Material Inventory
apiRouter.get('/inventory', (req, res) => {
  const state = db.get();
  res.json({ success: true, data: state.materials });
});

apiRouter.post('/inventory', (req, res) => {
  const item = req.body as MaterialItem;
  if (!item.name) {
    return res.status(400).json({ error: 'Tên vật liệu là bắt buộc' });
  }
  const newItem: MaterialItem = {
    ...item,
    id: item.id || 'mat_' + Date.now(),
    dateAdded: item.dateAdded || new Date().toISOString().split('T')[0]
  };
  db.update(state => {
    state.materials.unshift(newItem);
  });
  res.json({ success: true, data: newItem });
});

apiRouter.put('/inventory/:id', (req, res) => {
  const { id } = req.params;
  let updatedItem: MaterialItem | null = null;
  db.update(state => {
    const idx = state.materials.findIndex(m => m.id === id);
    if (idx !== -1) {
      state.materials[idx] = { ...state.materials[idx], ...req.body };
      updatedItem = state.materials[idx];
    }
  });
  if (!updatedItem) {
    return res.status(404).json({ error: 'Không tìm thấy vật liệu' });
  }
  res.json({ success: true, data: updatedItem });
});

apiRouter.delete('/inventory/:id', (req, res) => {
  const { id } = req.params;
  db.update(state => {
    state.materials = state.materials.filter(m => m.id !== id);
  });
  res.json({ success: true, message: 'Đã xóa vật liệu' });
});

// User Projects
apiRouter.get('/projects', (req, res) => {
  const state = db.get();
  res.json({ success: true, data: state.projects });
});

apiRouter.post('/projects', (req, res) => {
  const project = req.body as UserProject;
  const newProject: UserProject = {
    ...project,
    id: project.id || 'proj_' + Date.now(),
    userId: project.userId || 'user_default',
    createdAt: new Date().toISOString().split('T')[0],
    updatedAt: new Date().toISOString().split('T')[0]
  };
  db.update(state => {
    state.projects.unshift(newProject);
    const user = state.users.find(u => u.id === 'user_default');
    if (user && newProject.status === 'completed') {
      user.totalCraftsMade += 1;
      user.savedWasteKg += 0.5;
    }
  });
  res.json({ success: true, data: newProject });
});

apiRouter.put('/projects/:id', (req, res) => {
  const { id } = req.params;
  let updatedProj: UserProject | null = null;
  db.update(state => {
    const idx = state.projects.findIndex(p => p.id === id);
    if (idx !== -1) {
      const wasCompleted = state.projects[idx].status === 'completed';
      state.projects[idx] = {
        ...state.projects[idx],
        ...req.body,
        updatedAt: new Date().toISOString().split('T')[0]
      };
      updatedProj = state.projects[idx];

      if (!wasCompleted && updatedProj.status === 'completed') {
        const user = state.users.find(u => u.id === 'user_default');
        if (user) {
          user.totalCraftsMade += 1;
          user.savedWasteKg = Number((user.savedWasteKg + 0.4).toFixed(1));
        }
      }
    }
  });
  if (!updatedProj) {
    return res.status(404).json({ error: 'Không tìm thấy dự án' });
  }
  res.json({ success: true, data: updatedProj });
});

apiRouter.delete('/projects/:id', (req, res) => {
  const { id } = req.params;
  db.update(state => {
    state.projects = state.projects.filter(p => p.id !== id);
  });
  res.json({ success: true, message: 'Đã xóa dự án' });
});

// Community Posts
apiRouter.get('/community', (req, res) => {
  const state = db.get();
  const userId = (req.query.userId as string) || 'user_default';
  const likedPostIds = new Set(state.userLikes[userId] || []);
  const savedPostIds = new Set(state.savedProjects[userId] || []);

  const enriched = state.communityPosts.map(post => ({
    ...post,
    isLiked: likedPostIds.has(post.id),
    isSaved: savedPostIds.has(post.id)
  }));

  res.json({ success: true, data: enriched });
});

apiRouter.get('/community/:id', (req, res) => {
  const { id } = req.params;
  const state = db.get();
  const post = state.communityPosts.find(p => p.id === id);
  if (!post) {
    return res.status(404).json({ error: 'Không tìm thấy bài đăng' });
  }
  const userId = (req.query.userId as string) || 'user_default';
  const isLiked = (state.userLikes[userId] || []).includes(post.id);
  const isSaved = (state.savedProjects[userId] || []).includes(post.id);

  res.json({
    success: true,
    data: {
      ...post,
      isLiked,
      isSaved
    }
  });
});

apiRouter.post('/community', (req, res) => {
  const body = req.body as Partial<CommunityPost>;
  const state = db.get();
  const user = state.users.find(u => u.id === 'user_default') || {
    name: 'Sáng Tạo Xanh (Bạn)',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    id: 'user_default'
  };

  const newPost: CommunityPost = {
    id: 'post_' + Date.now(),
    projectId: body.projectId,
    title: body.title || 'Sản phẩm tái chế mới',
    authorId: user.id,
    authorName: user.name,
    authorAvatar: user.avatar,
    description: body.description || '',
    coverImage: body.coverImage || 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800&auto=format&fit=crop&q=80',
    additionalImages: body.additionalImages || [],
    model3DType: body.model3DType || 'pen_holder',
    materialsSourceDescription: body.materialsSourceDescription || 'Thu gom từ gia đình & trường học',
    materialsSummary: body.materialsSummary || [],
    toolsSummary: body.toolsSummary || [],
    difficulty: body.difficulty || 'Dễ',
    estimatedTime: body.estimatedTime || '30 phút',
    recycledRatio: body.recycledRatio || 100,
    type: body.type || '100_percent_recycled',
    dimensions: body.dimensions || 'Tiêu chuẩn',
    steps: body.steps || [],
    tipsAndLearnings: body.tipsAndLearnings || ['Cẩn thận với kéo và làm nhẵn các cạnh.'],
    likesCount: 1,
    commentsCount: 0,
    comments: [],
    visibility: body.visibility || 'public',
    guideStatus: body.guideStatus || (body.steps && body.steps.length > 0 ? 'completed' : 'pending'),
    imageStatus: body.imageStatus || (body.coverImage ? 'completed' : 'pending'),
    createdAt: new Date().toISOString().split('T')[0]
  };

  db.update(s => {
    s.communityPosts.unshift(newPost);
  });

  res.json({ success: true, data: newPost });
});

// Like / Unlike Post
apiRouter.post('/community/:id/like', (req, res) => {
  const { id } = req.params;
  const userId = (req.body.userId as string) || 'user_default';
  let isLiked = false;
  let newLikesCount = 0;

  db.update(state => {
    if (!state.userLikes[userId]) state.userLikes[userId] = [];
    const userLiked = state.userLikes[userId].includes(id);
    const post = state.communityPosts.find(p => p.id === id);

    if (userLiked) {
      state.userLikes[userId] = state.userLikes[userId].filter(x => x !== id);
      if (post) post.likesCount = Math.max(0, post.likesCount - 1);
      isLiked = false;
    } else {
      state.userLikes[userId].push(id);
      if (post) post.likesCount += 1;
      isLiked = true;
    }

    if (post) newLikesCount = post.likesCount;
  });

  res.json({ success: true, isLiked, likesCount: newLikesCount });
});

// Add Comment
apiRouter.post('/community/:id/comment', (req, res) => {
  const { id } = req.params;
  const { text, userName } = req.body;
  if (!text || text.trim() === '') {
    return res.status(400).json({ error: 'Bình luận không được để trống' });
  }

  const state = db.get();
  const user = state.users.find(u => u.id === 'user_default');

  const newComment: CommunityComment = {
    id: 'c_' + Date.now(),
    userId: 'user_default',
    userName: userName || user?.name || 'Sáng Tạo Xanh (Bạn)',
    userAvatar: user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    text: text.trim(),
    createdAt: new Date().toLocaleString('vi-VN', { dateStyle: 'short', timeStyle: 'short' }),
    likes: 0
  };

  db.update(s => {
    const post = s.communityPosts.find(p => p.id === id);
    if (post) {
      post.comments.push(newComment);
      post.commentsCount = post.comments.length;
    }
  });

  res.json({ success: true, data: newComment });
});

// Toggle Save Idea
apiRouter.post('/community/:id/save', (req, res) => {
  const { id } = req.params;
  const userId = (req.body.userId as string) || 'user_default';
  let isSaved = false;

  db.update(state => {
    if (!state.savedProjects[userId]) state.savedProjects[userId] = [];
    const idx = state.savedProjects[userId].indexOf(id);
    if (idx !== -1) {
      state.savedProjects[userId].splice(idx, 1);
      isSaved = false;
    } else {
      state.savedProjects[userId].push(id);
      isSaved = true;
    }
  });

  res.json({ success: true, isSaved });
});

// Get Saved Ideas
apiRouter.get('/saved-ideas', (req, res) => {
  const userId = (req.query.userId as string) || 'user_default';
  const state = db.get();
  const savedIds = new Set(state.savedProjects[userId] || []);
  const savedPosts = state.communityPosts
    .filter(p => savedIds.has(p.id))
    .map(p => ({
      ...p,
      isLiked: (state.userLikes[userId] || []).includes(p.id),
      isSaved: true
    }));

  res.json({ success: true, data: savedPosts });
});

// User Profile
apiRouter.get('/profile', (req, res) => {
  const state = db.get();
  const user = state.users[0];
  res.json({ success: true, data: user });
});

apiRouter.put('/profile', (req, res) => {
  let updated: any = null;
  db.update(state => {
    if (state.users[0]) {
      state.users[0] = { ...state.users[0], ...req.body };
      updated = state.users[0];
    }
  });
  res.json({ success: true, data: updated });
});
