import React, { useState, useEffect } from 'react';
import {
  Navbar,
  ActiveTab
} from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { MaterialCapture } from './components/MaterialCapture';
import { ClassificationSafetyCard } from './components/ClassificationSafetyCard';
import { GeometryCalculatorCard } from './components/GeometryCalculatorCard';
import { MaterialScanner3D } from './three/MaterialScanner3D';
import { CraftRecommendationList } from './components/CraftRecommendationList';
import { InteractiveCraftGuide } from './components/InteractiveCraftGuide';
import { MaterialInventory } from './components/MaterialInventory';
import { MyProjectsView } from './components/MyProjectsView';
import { CommunityView } from './components/CommunityView';
import { SavedIdeasView } from './components/SavedIdeasView';
import { UserProfileModal } from './components/UserProfileModal';
import {
  MaterialItem,
  CraftProduct,
  UserProject,
  CommunityPost,
  UserProfile
} from '../server/db';
import { AnalysisInput, AnalysisResult } from '../server/gemini';
import {
  Sparkles,
  ShieldCheck,
  RotateCcw,
  AlertCircle,
  CheckCircle2,
  TreePine,
  ArrowRight
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [hasGeminiKey, setHasGeminiKey] = useState<boolean>(true);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);

  // Core Data Lists
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [projects, setProjects] = useState<UserProject[]>([]);
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>([]);
  const [savedPosts, setSavedPosts] = useState<CommunityPost[]>([]);

  // Scan & Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [confirmedMaterial, setConfirmedMaterial] = useState<MaterialItem | null>(null);

  // Active Craft Guide State
  const [activeCraftForGuide, setActiveCraftForGuide] = useState<CraftProduct | null>(null);
  const [activeProjectResumeIndex, setActiveProjectResumeIndex] = useState<number>(0);

  // Notification / Toast Message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Initial Data Fetch
  useEffect(() => {
    fetchApiStatus();
    fetchUserProfile();
    fetchInventory();
    fetchProjects();
    fetchCommunity();
    fetchSavedIdeas();
  }, []);

  const fetchApiStatus = async () => {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      setHasGeminiKey(Boolean(data.hasGeminiApiKey));
    } catch (err) {
      console.warn('Status fetch error:', err);
    }
  };

  const fetchUserProfile = async () => {
    try {
      const res = await fetch('/api/profile');
      const data = await res.json();
      if (data.success) setUserProfile(data.data);
    } catch (err) {
      console.warn('Profile fetch error:', err);
    }
  };

  const fetchInventory = async () => {
    try {
      const res = await fetch('/api/inventory');
      const data = await res.json();
      if (data.success) setMaterials(data.data);
    } catch (err) {
      console.warn('Inventory fetch error:', err);
    }
  };

  const fetchProjects = async () => {
    try {
      const res = await fetch('/api/projects');
      const data = await res.json();
      if (data.success) setProjects(data.data);
    } catch (err) {
      console.warn('Projects fetch error:', err);
    }
  };

  const fetchCommunity = async () => {
    try {
      const res = await fetch('/api/community');
      const data = await res.json();
      if (data.success) setCommunityPosts(data.data);
    } catch (err) {
      console.warn('Community fetch error:', err);
    }
  };

  const fetchSavedIdeas = async () => {
    try {
      const res = await fetch('/api/saved-ideas');
      const data = await res.json();
      if (data.success) setSavedPosts(data.data);
    } catch (err) {
      console.warn('Saved ideas fetch error:', err);
    }
  };

  // Handle Multimodal Analysis Call
  const handleStartAnalysis = async (input: AnalysisInput) => {
    setIsAnalyzing(true);
    setAnalysisResult(null);
    setConfirmedMaterial(null);

    try {
      const res = await fetch('/api/analyze-materials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Lỗi xử lý hình ảnh');
      }

      setAnalysisResult(json.data);
      setConfirmedMaterial(json.data.material);

      showToast(
        json.data.isDemoMode
          ? 'Đã hoàn thành phân tích ở chế độ mô phỏng trực quan!'
          : 'Gemini Vision AI đã phân tích vật liệu thành công!'
      );
    } catch (err: any) {
      console.error('Error analyzing materials:', err);
      showToast('Lỗi: ' + (err.message || 'Không thể phân tích'));
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Add analyzed material to Inventory
  const handleAddMaterialToInventory = async (mat: MaterialItem) => {
    try {
      const res = await fetch('/api/inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mat),
      });
      const data = await res.json();
      if (data.success) {
        setMaterials((prev) => [data.data, ...prev]);
        showToast('Đã lưu vật liệu vào kho cá nhân!');
      }
    } catch (err) {
      showToast('Lỗi khi lưu vật liệu.');
    }
  };

  const handleDeleteMaterial = async (id: string) => {
    try {
      await fetch(`/api/inventory/${id}`, { method: 'DELETE' });
      setMaterials((prev) => prev.filter((m) => m.id !== id));
      showToast('Đã xóa vật liệu khỏi kho.');
    } catch (err) {
      showToast('Lỗi khi xóa.');
    }
  };

  // Select craft to open 3D workshop
  const handleSelectCraftForGuide = (craft: CraftProduct) => {
    setActiveCraftForGuide(craft);
    setActiveProjectResumeIndex(0);
    setActiveTab('guide');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Resume project from My Projects
  const handleResumeProject = (proj: UserProject) => {
    setActiveCraftForGuide(proj.craftData);
    setActiveProjectResumeIndex(proj.currentStepIndex || 0);
    setActiveTab('guide');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Save project
  const handleSaveToProjects = async (craft: CraftProduct, completedIndices: number[]) => {
    const isCompleted = completedIndices.length === craft.steps.length;
    const projectPayload: Partial<UserProject> = {
      title: craft.title,
      description: craft.description,
      status: isCompleted ? 'completed' : 'in_progress',
      progressPercent: Math.round((completedIndices.length / craft.steps.length) * 100),
      currentStepIndex: Math.max(0, ...completedIndices),
      coverImage: craft.imageUrl,
      model3DType: craft.model3DType,
      craftData: craft,
      inputMaterials: confirmedMaterial ? [confirmedMaterial] : [],
      userNotes: 'Dự án tạo từ Recycle Art Studio',
    };

    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(projectPayload),
      });
      const data = await res.json();
      if (data.success) {
        setProjects((prev) => [data.data, ...prev]);
        fetchUserProfile(); // refresh user kg and stats
        showToast('Đã lưu vào "Dự án của tôi"!');
      }
    } catch (err) {
      showToast('Lỗi lưu dự án.');
    }
  };

  // Duplicate Project
  const handleDuplicateProject = async (proj: UserProject) => {
    const duplicated: Partial<UserProject> = {
      ...proj,
      id: undefined,
      title: `${proj.title} (Bản sao)`,
      status: 'in_progress',
      progressPercent: 0,
      currentStepIndex: 0,
    };
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(duplicated),
      });
      const data = await res.json();
      if (data.success) {
        setProjects((prev) => [data.data, ...prev]);
        showToast('Đã nhân bản dự án thành công!');
      }
    } catch (err) {
      showToast('Lỗi nhân bản.');
    }
  };

  // Delete project
  const handleDeleteProject = async (id: string) => {
    try {
      await fetch(`/api/projects/${id}`, { method: 'DELETE' });
      setProjects((prev) => prev.filter((p) => p.id !== id));
      showToast('Đã xóa dự án.');
    } catch (err) {
      showToast('Lỗi xóa dự án.');
    }
  };

  // Publish Craft to Community
  const handlePublishToCommunity = async (craft: CraftProduct) => {
    const payload: Partial<CommunityPost> = {
      title: craft.title,
      description: craft.description,
      coverImage: craft.imageUrl,
      model3DType: craft.model3DType,
      materialsSourceDescription: craft.whySuitable,
      materialsSummary: craft.materialsUsed.map((m) => m.name),
      toolsSummary: craft.toolsRequired,
      difficulty: craft.difficulty,
      estimatedTime: craft.estimatedTime,
      recycledRatio: craft.recycledMaterialRatio,
      type: craft.type,
      dimensions: `${craft.dimensionsFinished.lengthCm}×${craft.dimensionsFinished.widthCm}×${craft.dimensionsFinished.heightCm} cm`,
      steps: craft.steps,
      tipsAndLearnings: ['Cẩn thận với kéo và làm mịn viền cắt bằng băng keo.'],
    };

    try {
      const res = await fetch('/api/community', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        setCommunityPosts((prev) => [data.data, ...prev]);
        showToast('Tác phẩm đã xuất bản thành công lên Cộng Đồng!');
        setActiveTab('community');
      }
    } catch (err) {
      showToast('Lỗi xuất bản lên cộng đồng.');
    }
  };

  // Like / Save / Comment Community
  const handleToggleLike = async (postId: string) => {
    try {
      const res = await fetch(`/api/community/${postId}/like`, { method: 'POST', body: '{}' });
      const data = await res.json();
      if (data.success) {
        setCommunityPosts((prev) =>
          prev.map((p) =>
            p.id === postId
              ? { ...p, isLiked: data.isLiked, likesCount: data.likesCount } as any
              : p
          )
        );
      }
    } catch (err) {
      console.warn('Like toggle error:', err);
    }
  };

  const handleToggleSave = async (postId: string) => {
    try {
      const res = await fetch(`/api/community/${postId}/save`, { method: 'POST', body: '{}' });
      const data = await res.json();
      if (data.success) {
        setCommunityPosts((prev) =>
          prev.map((p) =>
            p.id === postId ? ({ ...p, isSaved: data.isSaved } as any) : p
          )
        );
        fetchSavedIdeas();
        showToast(data.isSaved ? 'Đã lưu vào Ý tưởng đã lưu' : 'Đã bỏ lưu ý tưởng');
      }
    } catch (err) {
      console.warn('Save toggle error:', err);
    }
  };

  const handleAddComment = async (postId: string, text: string) => {
    try {
      const res = await fetch(`/api/community/${postId}/comment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      const data = await res.json();
      if (data.success) {
        setCommunityPosts((prev) =>
          prev.map((p) =>
            p.id === postId
              ? {
                  ...p,
                  comments: [...p.comments, data.data],
                  commentsCount: p.commentsCount + 1,
                }
              : p
          )
        );
        showToast('Bình luận đã gửi thành công!');
      }
    } catch (err) {
      showToast('Lỗi gửi bình luận.');
    }
  };

  // Brainstorm combined materials from inventory
  const handleCombineFromInventory = (selectedMaterials: MaterialItem[]) => {
    const combinedNotes = selectedMaterials.map((m) => `${m.name} (${m.quantity} ${m.unit})`).join('; ');
    const allImages = selectedMaterials.flatMap((m) => m.images);

    handleStartAnalysis({
      images: allImages.length > 0 ? allImages : ['https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?w=500&auto=format&fit=crop&q=80'],
      userNotes: `Phối hợp nhiều vật liệu: ${combinedNotes}`,
      referenceObject: { type: 'credit_card_85mm' },
    });
    setActiveTab('scan');
  };

  return (
    <div className="min-h-screen bg-slate-50/60 text-slate-800 flex flex-col font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 px-4 py-2.5 rounded-2xl bg-slate-900 text-white text-xs font-semibold shadow-2xl border border-slate-800 flex items-center gap-2 animate-in fade-in slide-in-from-top duration-200">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Global Navbar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        userProfile={userProfile}
        onOpenProfile={() => setShowProfileModal(true)}
        hasGeminiKey={hasGeminiKey}
      />

      {/* Main App Content View Switcher */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* TAB 1: HOME */}
        {activeTab === 'home' && (
          <HeroSection
            onStartScan={() => setActiveTab('scan')}
            onExploreCommunity={() => setActiveTab('community')}
            onSelectFeaturedCraft={handleSelectCraftForGuide}
          />
        )}

        {/* TAB 2: SCAN & AI VISION STUDIO */}
        {activeTab === 'scan' && (
          <div className="space-y-10">
            {/* Camera / Multi-angle photo upload */}
            <MaterialCapture
              onStartAnalysis={handleStartAnalysis}
              isAnalyzing={isAnalyzing}
            />

            {/* Analysis Results Display */}
            {analysisResult && confirmedMaterial && (
              <div className="space-y-8 animate-in fade-in duration-300">
                {/* AI Engine & Insights Banner */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200 text-xs text-slate-800 flex items-start justify-between gap-3 shadow-xs">
                  <div className="flex items-start gap-2.5">
                    <Sparkles className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-extrabold text-slate-900 block text-sm">
                        Kết quả phân tích từ: {analysisResult.engineLabel || 'Google Gemini 3.8 Flash Vision'}
                      </span>
                      <p className="text-slate-600 text-xs mt-0.5">
                        {analysisResult.aiInsight || 'Đã phân tích cấu trúc vật liệu, đo đạc kích thước milimet và lập danh sách sản phẩm tái chế phù hợp.'}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider bg-white/90 text-emerald-800 border border-emerald-200 shadow-2xs shrink-0">
                    AI Đã Khớp
                  </span>
                </div>

                {/* Demo Mode Notice if running in demo */}
                {analysisResult.isDemoMode && (
                  <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-xs text-blue-900 flex items-start gap-2.5">
                    <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block">
                        Chế độ Demo Trực Quan (High-Fidelity Demonstration)
                      </span>
                      <span>
                        Hệ thống đã phân tích đặc tính vật liệu và kích thước 3D mẫu. Bạn có thể cấu hình GEMINI_API_KEY trong bảng điều khiển để kích hoạt phân tích AI trực tiếp cho mọi góc ảnh tùy chỉnh.
                      </span>
                    </div>
                  </div>
                )}

                {/* Section 8: Waste Classification & Usability Safety Assessment */}
                <ClassificationSafetyCard
                  material={confirmedMaterial}
                  onConfirmClassification={(updated) => setConfirmedMaterial(updated)}
                  onAddToInventory={handleAddMaterialToInventory}
                />

                {/* Section 10: 3D Material Scanner & Interactive Geometry Measurement */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                        DỰNG MÔ HÌNH 3D TỪ HÌNH ẢNH
                      </span>
                      <span className="text-xs text-slate-500">• Xoay 360°, lưới tọa độ & kích thước</span>
                    </div>
                  </div>

                  <MaterialScanner3D
                    material={confirmedMaterial}
                    height="440px"
                  />
                </div>

                {/* Section 10B: Mathematical Dimensions & Usable Surface Area Calculation */}
                <GeometryCalculatorCard
                  material={confirmedMaterial}
                  onUpdateDimensions={(newDims) => {
                    setConfirmedMaterial((prev) => (prev ? { ...prev, dimensions: newDims } : prev));
                  }}
                />

                {/* Section 9: 2-Group Craft Recommendations (100% Recycled vs Added Materials) */}
                <CraftRecommendationList
                  group100Percent={analysisResult.recommendations.group100Percent}
                  groupWithAddedMaterials={analysisResult.recommendations.groupWithAddedMaterials}
                  onSelectCraft={handleSelectCraftForGuide}
                  onUpdateCraft={(updated) => {
                    setAnalysisResult((prev) => {
                      if (!prev) return prev;
                      return {
                        ...prev,
                        recommendations: {
                          group100Percent: prev.recommendations.group100Percent.map((c) =>
                            c.id === updated.id ? updated : c
                          ),
                          groupWithAddedMaterials: prev.recommendations.groupWithAddedMaterials.map((c) =>
                            c.id === updated.id ? updated : c
                          ),
                        },
                      };
                    });
                    showToast(`Đã cập nhật mô hình 3D cho "${updated.title}"!`);
                  }}
                />
              </div>
            )}
          </div>
        )}

        {/* TAB 3: 3D INTERACTIVE CRAFT WORKSHOP GUIDE */}
        {activeTab === 'guide' && activeCraftForGuide && (
          <InteractiveCraftGuide
            craft={activeCraftForGuide}
            initialStepIndex={activeProjectResumeIndex}
            onSaveToProjects={handleSaveToProjects}
            onPublishToCommunity={handlePublishToCommunity}
            onBackToRecommendations={() => setActiveTab('scan')}
          />
        )}

        {/* TAB 4: MY MATERIAL INVENTORY */}
        {activeTab === 'inventory' && (
          <MaterialInventory
            materials={materials}
            onSelectCombineMaterials={handleCombineFromInventory}
            onDeleteMaterial={handleDeleteMaterial}
            onUpdateMaterial={(updated) => {
              setMaterials((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
            }}
            onAddNewScan={() => setActiveTab('scan')}
          />
        )}

        {/* TAB 5: MY PROJECTS */}
        {activeTab === 'projects' && (
          <MyProjectsView
            projects={projects}
            onResumeProject={handleResumeProject}
            onDeleteProject={handleDeleteProject}
            onDuplicateProject={handleDuplicateProject}
            onPublishToCommunity={handlePublishToCommunity}
            onStartNewProject={() => setActiveTab('scan')}
          />
        )}

        {/* TAB 6: COMMUNITY GALLERY */}
        {activeTab === 'community' && (
          <CommunityView
            posts={communityPosts}
            onToggleLike={handleToggleLike}
            onToggleSave={handleToggleSave}
            onAddComment={handleAddComment}
            onCreateNewPost={async (postData) => {
              try {
                const res = await fetch('/api/community', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(postData),
                });
                const data = await res.json();
                if (data.success) {
                  setCommunityPosts((prev) => [data.data, ...prev]);
                  showToast('Tác phẩm đã xuất bản thành công!');
                }
              } catch (err) {
                showToast('Lỗi xuất bản tác phẩm.');
              }
            }}
            onOpenWorkshop={handleSelectCraftForGuide}
          />
        )}

        {/* TAB 7: SAVED IDEAS */}
        {activeTab === 'saved' && (
          <SavedIdeasView
            savedPosts={savedPosts}
            onRemoveSaved={handleToggleSave}
            onToggleLike={handleToggleLike}
            onAddComment={handleAddComment}
            onStartCraft={handleSelectCraftForGuide}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-8 mt-16 text-center text-xs text-slate-500 space-y-3">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-xs">
              R
            </div>
            <span className="font-bold text-slate-800">Recycle Art Studio</span>
            <span>— Biến rác thải thành sáng tạo</span>
          </div>

          <p className="text-slate-400">
            Ứng dụng công nghệ AI Đa Phương Thức & 3D WebGL • Thúc đẩy kinh tế tuần hoàn
          </p>

          <div className="flex items-center gap-4 text-slate-600 font-semibold">
            <button onClick={() => setActiveTab('home')} className="hover:text-emerald-700">
              Trang chủ
            </button>
            <button onClick={() => setActiveTab('scan')} className="hover:text-emerald-700">
              Quét AI
            </button>
            <button onClick={() => setActiveTab('community')} className="hover:text-emerald-700">
              Cộng đồng
            </button>
          </div>
        </div>
      </footer>

      {/* User Profile Modal */}
      {showProfileModal && userProfile && (
        <UserProfileModal
          user={userProfile}
          onClose={() => setShowProfileModal(false)}
          onUpdateProfile={async (updated) => {
            try {
              const res = await fetch('/api/profile', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updated),
              });
              const data = await res.json();
              if (data.success) {
                setUserProfile(data.data);
                showToast('Đã cập nhật hồ sơ cá nhân!');
              }
            } catch (err) {
              showToast('Lỗi cập nhật hồ sơ.');
            }
          }}
        />
      )}
    </div>
  );
}
