import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Hammer,
  CheckCircle2,
  AlertTriangle,
  Ruler,
  Wrench,
  Layers,
  Sparkles,
  Bookmark,
  Share2,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Camera,
  Award,
  Check
} from 'lucide-react';
import { CraftProduct, CraftStep } from '../../server/db';
import { CraftViewer3D } from '../three/CraftViewer3D';

interface InteractiveCraftGuideProps {
  craft: CraftProduct;
  initialStepIndex?: number;
  onSaveToProjects: (craft: CraftProduct, completedStepIndices: number[]) => void;
  onPublishToCommunity: (craft: CraftProduct) => void;
  onBackToRecommendations: () => void;
}

export const InteractiveCraftGuide: React.FC<InteractiveCraftGuideProps> = ({
  craft,
  initialStepIndex = 0,
  onSaveToProjects,
  onPublishToCommunity,
  onBackToRecommendations,
}) => {
  const safeSteps = craft.steps && craft.steps.length > 0 ? craft.steps : [
    {
      stepNumber: 1,
      title: 'Chưa cập nhật cách làm chi tiết',
      description: 'Mục này hiện chưa có danh sách các bước thực hiện. Cộng đồng đang chờ đón sự đóng góp của bạn!',
      materialsNeeded: craft.materialsUsed.map(m => m.name),
      toolsNeeded: craft.toolsRequired,
      highlightPart: 'body'
    }
  ];

  const [currentStepIndex, setCurrentStepIndex] = useState(initialStepIndex);
  const [completedSteps, setCompletedSteps] = useState<number[]>(
    safeSteps.map((s, idx) => (s.isCompleted ? idx : -1)).filter((x) => x !== -1)
  );
  const [isSaved, setIsSaved] = useState(false);
  const [userFinishedPhoto, setUserFinishedPhoto] = useState<string | null>(null);

  const activeStep: CraftStep = safeSteps[currentStepIndex] || safeSteps[0];
  const isAllCompleted = completedSteps.length === safeSteps.length;

  const toggleStepCompleted = (stepIdx: number) => {
    setCompletedSteps((prev) => {
      const exists = prev.includes(stepIdx);
      let updated: number[];
      if (exists) {
        updated = prev.filter((i) => i !== stepIdx);
      } else {
        updated = [...prev, stepIdx];
        // Trigger celebratory confetti if this completes the last step
        if (updated.length === safeSteps.length) {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });
        }
      }
      return updated;
    });
  };

  const handleSave = () => {
    onSaveToProjects(craft, completedSteps);
    setIsSaved(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setUserFinishedPhoto(event.target.result as string);
        confetti({ particleCount: 50 });
      }
    };
    reader.readAsDataURL(file);
  };

  const progressPercent = Math.round((completedSteps.length / safeSteps.length) * 100);

  return (
    <div className="space-y-8 max-w-6xl mx-auto py-4">
      {/* Top Header & Back Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToRecommendations}
            className="p-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 transition"
            title="Quay lại danh sách đề xuất"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                XƯỞNG THỦ CÔNG 3D TƯƠNG TÁC
              </span>
              <span className="text-xs text-slate-500">• {craft.estimatedTime}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
              {craft.title}
            </h2>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            disabled={isSaved}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
              isSaved
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 shadow-xs'
            }`}
          >
            <Bookmark className="w-4 h-4 text-emerald-600" />
            <span>{isSaved ? 'Đã lưu dự án' : 'Lưu vào Dự án của tôi'}</span>
          </button>

          <button
            onClick={() => onPublishToCommunity(craft)}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition"
          >
            <Share2 className="w-4 h-4" />
            <span>Chia sẻ lên Cộng đồng</span>
          </button>
        </div>
      </div>

      {/* Main 3D Workshop Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Interactive 3D Model Viewer (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <CraftViewer3D
            craft={craft}
            currentStepIndex={currentStepIndex}
            onStepChange={setCurrentStepIndex}
            height="500px"
          />

          {/* Quick Step Timeline Indicators */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-700">
                Tiến độ thực hiện: {completedSteps.length} / {safeSteps.length} công đoạn hoàn tất
              </span>
              <span className="text-emerald-700 font-bold">{progressPercent}%</span>
            </div>

            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="flex items-center justify-between gap-1 overflow-x-auto no-scrollbar pt-1">
              {safeSteps.map((step, idx) => {
                const isActive = idx === currentStepIndex;
                const isDone = completedSteps.includes(idx);
                return (
                  <button
                    key={idx}
                    onClick={() => setCurrentStepIndex(idx)}
                    className={`flex-1 min-w-[70px] py-1.5 px-2 rounded-xl text-center text-xs font-bold transition border ${
                      isActive
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                        : isDone
                        ? 'border-slate-200 bg-emerald-500/10 text-emerald-700'
                        : 'border-slate-200 bg-slate-50 text-slate-500'
                    }`}
                  >
                    <div className="flex items-center justify-center gap-1">
                      {isDone && <Check className="w-3 h-3 text-emerald-600" />}
                      <span>Bước {idx + 1}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Step-by-Step Instructions & Safety (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Active Step Detail Card */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-5">
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded-md">
                  CÔNG ĐOẠN {activeStep.stepNumber}
                </span>
                <h3 className="text-lg font-extrabold text-slate-900 leading-snug">
                  {activeStep.title}
                </h3>
              </div>

              {/* Mark Completed Checkbox */}
              <button
                onClick={() => toggleStepCompleted(currentStepIndex)}
                className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition shrink-0 ${
                  completedSteps.includes(currentStepIndex)
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {completedSteps.includes(currentStepIndex) ? 'Đã hoàn thành' : 'Đánh dấu xong'}
                </span>
              </button>
            </div>

            {/* Description */}
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed bg-slate-50/70 p-3.5 rounded-2xl border border-slate-100">
              {activeStep.description}
            </p>

            {/* Materials and Tools Needed for this step */}
            <div className="space-y-3 pt-2 text-xs">
              {activeStep.materialsNeeded && activeStep.materialsNeeded.length > 0 && (
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Vật liệu công đoạn này:</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {activeStep.materialsNeeded.map((m, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 font-medium"
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {activeStep.toolsNeeded && activeStep.toolsNeeded.length > 0 && (
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5 text-slate-600" />
                    <span>Dụng cụ cần chuẩn bị:</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {activeStep.toolsNeeded.map((t, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-medium"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {activeStep.dimensionsNotice && (
                <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200 text-blue-900 flex items-start gap-2">
                  <Ruler className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Thông số kích thước chú ý:</span>
                    <span>{activeStep.dimensionsNotice}</span>
                  </div>
                </div>
              )}

              {activeStep.safetyWarning && (
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Cảnh báo an toàn thao tác:</span>
                    <span>{activeStep.safetyWarning}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Step Navigation Bottom Bar */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <button
                disabled={currentStepIndex === 0}
                onClick={() => setCurrentStepIndex((prev) => Math.max(0, prev - 1))}
                className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 disabled:opacity-30 disabled:hover:bg-transparent text-xs font-bold text-slate-700 flex items-center gap-1 transition"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Bước trước</span>
              </button>

              <button
                disabled={currentStepIndex === safeSteps.length - 1}
                onClick={() =>
                  setCurrentStepIndex((prev) => Math.min(safeSteps.length - 1, prev + 1))
                }
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-30 text-white text-xs font-bold flex items-center gap-1 shadow-xs transition"
              >
                <span>Bước tiếp theo</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Completion Milestone Card */}
          {isAllCompleted && (
            <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-lg space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center font-bold">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-black text-base">Tuyệt vời! Bạn đã hoàn thành!</h4>
                  <p className="text-xs text-emerald-100">
                    Sản phẩm tái chế đã sẵn sàng để sử dụng và trang trí.
                  </p>
                </div>
              </div>

              {/* Photo Upload of Real Finished Product */}
              <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 space-y-2">
                <span className="text-xs font-bold block">
                  Chụp ảnh thành quả thực tế của bạn:
                </span>
                {userFinishedPhoto ? (
                  <div className="relative rounded-xl overflow-hidden aspect-video">
                    <img
                      src={userFinishedPhoto}
                      alt="Thành quả của bạn"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-1 right-1 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-md">
                      Ảnh thực tế của bạn
                    </span>
                  </div>
                ) : (
                  <label className="flex items-center justify-center gap-2 p-3 rounded-xl border border-dashed border-white/40 hover:bg-white/10 cursor-pointer text-xs font-semibold transition">
                    <Camera className="w-4 h-4" />
                    <span>Tải ảnh sản phẩm hoàn thiện</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handlePhotoUpload}
                    />
                  </label>
                )}
              </div>

              <button
                onClick={() => onPublishToCommunity(craft)}
                className="w-full py-2.5 rounded-xl bg-white text-emerald-800 font-extrabold text-xs shadow-sm hover:bg-emerald-50 transition"
              >
                Đăng lên Cộng Đồng Sáng Tạo Ngay
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
