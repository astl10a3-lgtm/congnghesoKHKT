import React from 'react';
import {
  Recycle,
  Sparkles,
  Package,
  FolderGit2,
  Users,
  Bookmark,
  Camera,
  Layers,
  Leaf
} from 'lucide-react';
import { UserProfile } from '../../server/db';

export type ActiveTab = 'home' | 'scan' | 'inventory' | 'projects' | 'community' | 'saved' | 'guide';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  userProfile?: UserProfile | null;
  onOpenProfile: () => void;
  hasGeminiKey: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  userProfile,
  onOpenProfile,
  hasGeminiKey,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-emerald-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <button
            onClick={() => onTabChange('home')}
            className="flex items-center gap-2.5 text-left focus:outline-hidden group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 flex items-center justify-center shadow-md shadow-emerald-500/20 group-hover:scale-105 transition">
              <Recycle className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg text-slate-800 tracking-tight">
                  Recycle Art <span className="text-emerald-600">Studio</span>
                </span>
                <span className="px-1.5 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                  AI 3D
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                Biến rác thải thành sáng tạo
              </p>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => onTabChange('home')}
              className={`px-3 py-2 rounded-xl text-sm font-medium transition ${
                activeTab === 'home'
                  ? 'bg-emerald-50 text-emerald-700 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Trang chủ
            </button>

            <button
              onClick={() => onTabChange('scan')}
              className={`px-3.5 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5 transition ${
                activeTab === 'scan'
                  ? 'bg-emerald-600 text-white font-semibold shadow-sm shadow-emerald-600/30'
                  : 'text-emerald-700 bg-emerald-50/80 hover:bg-emerald-100/80 font-medium'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>Quét & Phân tích AI</span>
            </button>

            <button
              onClick={() => onTabChange('inventory')}
              className={`px-3 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5 transition ${
                activeTab === 'inventory'
                  ? 'bg-emerald-50 text-emerald-700 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Package className="w-4 h-4 text-slate-500" />
              <span>Kho vật liệu</span>
            </button>

            <button
              onClick={() => onTabChange('projects')}
              className={`px-3 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5 transition ${
                activeTab === 'projects'
                  ? 'bg-emerald-50 text-emerald-700 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <FolderGit2 className="w-4 h-4 text-slate-500" />
              <span>Dự án của tôi</span>
            </button>

            <button
              onClick={() => onTabChange('community')}
              className={`px-3 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5 transition ${
                activeTab === 'community'
                  ? 'bg-emerald-50 text-emerald-700 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Users className="w-4 h-4 text-slate-500" />
              <span>Cộng đồng sáng tạo</span>
            </button>

            <button
              onClick={() => onTabChange('saved')}
              className={`px-3 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5 transition ${
                activeTab === 'saved'
                  ? 'bg-emerald-50 text-emerald-700 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Bookmark className="w-4 h-4 text-slate-500" />
              <span>Đã lưu</span>
            </button>
          </nav>

          {/* User Profile & AI Mode Badge */}
          <div className="flex items-center gap-3">
            {/* AI Status Pill */}
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-[11px] text-slate-600">
              <span
                className={`w-2 h-2 rounded-full ${
                  hasGeminiKey ? 'bg-emerald-500' : 'bg-blue-500'
                }`}
              />
              <span className="font-medium">
                {hasGeminiKey ? 'Gemini 3.8 Flash' : 'Chế độ Demo Sẵn Sàng'}
              </span>
            </div>

            {/* Profile Avatar Button */}
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition border border-transparent hover:border-slate-200"
              title="Xem hồ sơ cá nhân & chỉ số tái chế"
            >
              <img
                src={
                  userProfile?.avatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                }
                alt="Avatar"
                className="w-8 h-8 rounded-full object-cover ring-2 ring-emerald-500/30"
              />
              <div className="hidden sm:block text-left text-xs">
                <p className="font-semibold text-slate-800 line-clamp-1">
                  {userProfile?.name || 'Sáng Tạo Xanh'}
                </p>
                <p className="text-[10px] text-emerald-600 font-medium">
                  {userProfile?.savedWasteKg || 8.5} kg rác đã giảm
                </p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Scrollable Navigation Bar */}
      <div className="md:hidden flex items-center gap-1 px-4 py-2 overflow-x-auto no-scrollbar border-t border-slate-100 bg-white">
        <button
          onClick={() => onTabChange('home')}
          className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-medium ${
            activeTab === 'home' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-600'
          }`}
        >
          Trang chủ
        </button>
        <button
          onClick={() => onTabChange('scan')}
          className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-medium flex items-center gap-1 ${
            activeTab === 'scan' ? 'bg-emerald-600 text-white font-semibold' : 'text-emerald-700 bg-emerald-50'
          }`}
        >
          <Camera className="w-3.5 h-3.5" />
          Quét AI
        </button>
        <button
          onClick={() => onTabChange('inventory')}
          className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-medium ${
            activeTab === 'inventory' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-600'
          }`}
        >
          Kho vật liệu
        </button>
        <button
          onClick={() => onTabChange('projects')}
          className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-medium ${
            activeTab === 'projects' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-600'
          }`}
        >
          Dự án của tôi
        </button>
        <button
          onClick={() => onTabChange('community')}
          className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-medium ${
            activeTab === 'community' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-600'
          }`}
        >
          Cộng đồng
        </button>
        <button
          onClick={() => onTabChange('saved')}
          className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-medium ${
            activeTab === 'saved' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-600'
          }`}
        >
          Đã lưu
        </button>
      </div>
    </header>
  );
};
