import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  TreePine,
  Layers,
  Clock,
  Hammer,
  ArrowRight,
  Filter,
  DollarSign,
  CheckCircle,
  PlusCircle,
  HelpCircle,
  AlertCircle,
  Box,
  Image as ImageIcon,
  Check,
  Maximize2
} from 'lucide-react';
import { CraftProduct } from '../../server/db';
import { CraftViewer3D } from '../three/CraftViewer3D';

interface CraftRecommendationListProps {
  group100Percent: CraftProduct[];
  groupWithAddedMaterials: CraftProduct[];
  onSelectCraft: (craft: CraftProduct) => void;
  onUpdateCraft?: (updated: CraftProduct) => void;
}

export const CraftRecommendationList: React.FC<CraftRecommendationListProps> = ({
  group100Percent,
  groupWithAddedMaterials,
  onSelectCraft,
  onUpdateCraft,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | '100_percent' | 'with_added'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'recycled_ratio' | 'easiest' | 'fastest' | 'lowest_cost'>('recycled_ratio');

  const categories = [
    { id: 'all', label: 'Tất cả danh mục' },
    { id: 'garden', label: 'Làm vườn & Cây xanh' },
    { id: 'study', label: 'Đồ dùng học tập' },
    { id: 'decor', label: 'Trang trí phòng' },
    { id: 'stem_toy', label: 'Đồ chơi STEM' },
    { id: 'home', label: 'Gia đình' },
  ];

  // Filter & sort logic
  const filtered100 = useMemo(() => {
    let list = [...group100Percent];
    if (selectedCategory !== 'all') {
      list = list.filter((c) => c.category === selectedCategory);
    }
    return list;
  }, [group100Percent, selectedCategory]);

  const filteredAdded = useMemo(() => {
    let list = [...groupWithAddedMaterials];
    if (selectedCategory !== 'all') {
      list = list.filter((c) => c.category === selectedCategory);
    }
    return list;
  }, [groupWithAddedMaterials, selectedCategory]);

  const sortProducts = (products: CraftProduct[]) => {
    return [...products].sort((a, b) => {
      if (sortBy === 'recycled_ratio') {
        return b.recycledMaterialRatio - a.recycledMaterialRatio;
      }
      if (sortBy === 'fastest') {
        const timeA = parseInt(a.estimatedTime) || 30;
        const timeB = parseInt(b.estimatedTime) || 30;
        return timeA - timeB;
      }
      if (sortBy === 'easiest') {
        const diffRank: Record<string, number> = { Dễ: 1, 'Trung bình': 2, Khó: 3 };
        return (diffRank[a.difficulty] || 2) - (diffRank[b.difficulty] || 2);
      }
      if (sortBy === 'lowest_cost') {
        const costA = a.materialsNeededExtra.reduce((acc, m) => acc + m.estimatedCostVnd, 0);
        const costB = b.materialsNeededExtra.reduce((acc, m) => acc + m.estimatedCostVnd, 0);
        return costA - costB;
      }
      return 0;
    });
  };

  const sorted100 = useMemo(() => sortProducts(filtered100), [filtered100, sortBy]);
  const sortedAdded = useMemo(() => sortProducts(filteredAdded), [filteredAdded, sortBy]);

  return (
    <div className="space-y-10 py-4">
      {/* Header and Filter Bar */}
      <div className="space-y-4">
        <div className="text-center max-w-2xl mx-auto space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>3 Ý TƯỞNG SẢN PHẨM TÁI CHẾ TÍCH HỢP MÔ HÌNH 3D TƯƠNG TÁC</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            3 Sản phẩm tái chế tối ưu theo ảnh & mô tả thành phần
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Hệ thống AI đã phân tích ảnh chụp cùng bản mô tả chi tiết của bạn để gợi ý 3 sản phẩm tái chế có tỷ lệ thành công cao nhất, tích hợp trực tiếp mô hình 3D tương tác 360° xoay lật đa chiều.
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Mode Pill Filter */}
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 w-full md:w-auto">
            <button
              onClick={() => setFilterMode('all')}
              className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                filterMode === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả ({group100Percent.length + groupWithAddedMaterials.length})
            </button>
            <button
              onClick={() => setFilterMode('100_percent')}
              className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                filterMode === '100_percent'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-emerald-700 hover:text-emerald-900'
              }`}
            >
              <span>🌿 100% Có sẵn</span>
              <span className="text-[10px] opacity-80">({group100Percent.length})</span>
            </button>
            <button
              onClick={() => setFilterMode('with_added')}
              className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                filterMode === 'with_added'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-indigo-700 hover:text-indigo-900'
              }`}
            >
              <span>✨ Thêm phụ liệu</span>
              <span className="text-[10px] opacity-80">({groupWithAddedMaterials.length})</span>
            </button>
          </div>

          {/* Category & Sorting Selectors */}
          <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="p-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="p-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white"
            >
              <option value="recycled_ratio">Tận dụng nhiều rác nhất (%)</option>
              <option value="lowest_cost">Ít tốn chi phí mua thêm nhất</option>
              <option value="easiest">Dễ thực hiện nhất</option>
              <option value="fastest">Thời gian ngắn nhất</option>
            </select>
          </div>
        </div>
      </div>

      {/* SECTION 1: NHÓM 1: 100% RECYCLED MATERIALS */}
      {(filterMode === 'all' || filterMode === '100_percent') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-emerald-200">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                1
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
                  <span>Khu vực 1: Sáng tạo 100% từ vật liệu của bạn</span>
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                    Không cần mua thêm
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Tận dụng tối đa rác thải đã tải lên, không tốn thêm chi phí nguyên liệu.
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-emerald-700 hidden sm:inline">
              {sorted100.length} sản phẩm
            </span>
          </div>

          {sorted100.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
              Không có sản phẩm nào phù hợp với bộ lọc hiện tại trong nhóm này.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sorted100.map((craft) => (
                <CraftCard
                  key={craft.id}
                  craft={craft}
                  onSelect={onSelectCraft}
                  onUpdateCraft={onUpdateCraft}
                />
              ))}
            </div>
          )}
        </section>
      )}

      {/* SECTION 2: NHÓM 2: COMBINED WITH ADDED MATERIALS */}
      {(filterMode === 'all' || filterMode === 'with_added') && (
        <section className="space-y-4 pt-4">
          <div className="flex items-center justify-between pb-2 border-b border-indigo-200">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                2
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
                  <span>Khu vực 2: Mở rộng sáng tạo với vật liệu bổ sung</span>
                  <span className="text-xs font-bold text-indigo-800 bg-indigo-100 px-2 py-0.5 rounded-full">
                    Phụ liệu dễ tìm & an toàn
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Vật liệu tái chế đóng vai trò chủ đạo, kết hợp phụ liệu chi phí thấp (đèn LED 3V, sỏi, dây bấc...).
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-indigo-700 hidden sm:inline">
              {sortedAdded.length} sản phẩm
            </span>
          </div>

          {sortedAdded.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
              Không có sản phẩm nào phù hợp với bộ lọc hiện tại trong nhóm này.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedAdded.map((craft) => (
                <CraftCard
                  key={craft.id}
                  craft={craft}
                  onSelect={onSelectCraft}
                  onUpdateCraft={onUpdateCraft}
                />
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
};

// Sub-component: Craft Card with 3D Simulation Generator
const CraftCard: React.FC<{
  craft: CraftProduct;
  onSelect: (craft: CraftProduct) => void;
  onUpdateCraft?: (craft: CraftProduct) => void;
}> = ({ craft, onSelect }) => {
  const is100 = craft.type === '100_percent_recycled';
  const totalExtraCost = craft.materialsNeededExtra.reduce((acc, m) => acc + m.estimatedCostVnd, 0);

  const [currentCraft, setCurrentCraft] = useState<CraftProduct>(craft);
  // Default to 3D view so user sees the 3D model right away
  const [viewMode, setViewMode] = useState<'3d' | 'image'>(craft.imageUrl ? 'image' : '3d');

  React.useEffect(() => {
    setCurrentCraft(craft);
  }, [craft]);

  return (
    <div className="flex flex-col rounded-3xl bg-white border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-xl hover:border-emerald-300 transition duration-300 group">
      {/* 3D Model Interactive Viewport or Photo View */}
      <div className="relative h-64 w-full bg-slate-950 overflow-hidden flex items-center justify-center">
        {viewMode === '3d' ? (
          <div className="w-full h-full relative">
            <CraftViewer3D
              craft={currentCraft}
              currentStepIndex={0}
              height="256px"
            />
            <div className="absolute bottom-2 left-3 z-10 bg-slate-950/75 backdrop-blur-xs text-white text-[10px] px-2.5 py-1 rounded-md font-mono flex items-center gap-1.5 pointer-events-none">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>Kéo chuột để xoay 360°</span>
            </div>
          </div>
        ) : (
          <div className="w-full h-full relative">
            {currentCraft.imageUrl ? (
              <img
                src={currentCraft.imageUrl}
                alt={currentCraft.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-center space-y-2">
                <Box className="w-10 h-10 text-emerald-400" />
                <span className="text-white text-xs font-bold block">
                  Mô hình 3D sẵn sàng
                </span>
              </div>
            )}
          </div>
        )}

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 z-10 pointer-events-none">
          <span
            className={`px-3 py-1 rounded-xl text-[11px] font-extrabold shadow-sm ${
              is100 ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white'
            }`}
          >
            {is100 ? '🌿 100% Rác tái chế' : '✨ Có phụ liệu an toàn'}
          </span>
          <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black bg-slate-900/80 text-teal-300 backdrop-blur-md shadow-sm flex items-center gap-1 w-fit">
            <Box className="w-3 h-3 text-teal-400" />
            <span>3D: {currentCraft.model3DType}</span>
          </span>
        </div>

        {/* View Switcher Toggle Button */}
        {currentCraft.imageUrl && (
          <div className="absolute top-3 right-3 z-10">
            <button
              type="button"
              onClick={() => setViewMode(viewMode === '3d' ? 'image' : '3d')}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-900 text-white text-[11px] font-bold backdrop-blur-md border border-white/20 shadow-md flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            >
              {viewMode === '3d' ? (
                <>
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Xem ảnh chụp</span>
                </>
              ) : (
                <>
                  <Box className="w-3.5 h-3.5 text-teal-400" />
                  <span>Xoay mô hình 3D</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Quick Time Badge */}
        <div className="absolute bottom-3 right-3 bg-slate-900/85 backdrop-blur-md text-white text-[11px] px-2.5 py-1 rounded-lg font-medium flex items-center gap-1.5 z-10 pointer-events-none">
          <Clock className="w-3.5 h-3.5 text-emerald-400" />
          <span>{currentCraft.estimatedTime}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold text-slate-500 uppercase">{currentCraft.categoryLabel}</span>
            <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              {currentCraft.recycledMaterialRatio}% Tái chế
            </span>
          </div>

          <h3 className="font-bold text-slate-900 text-base group-hover:text-emerald-700 transition line-clamp-1">
            {currentCraft.title}
          </h3>

          <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap break-words">
            {currentCraft.description}
          </p>
        </div>

        {/* Interactive 3D Model Status Badge */}
        <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-emerald-950 font-bold">
            <Box className="w-4 h-4 text-emerald-600" />
            <span>Mô hình 3D chuẩn xác: {currentCraft.model3DType}</span>
          </div>
          <span className="text-[10px] font-bold text-emerald-700 bg-white/80 px-2 py-0.5 rounded-md border border-emerald-200">
            Tách cấu tạo 3D
          </span>
        </div>

        {/* Materials Summary List */}
        <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs">
          <p className="font-semibold text-slate-700 text-[11px] flex items-center justify-between">
            <span>Nguyên liệu sử dụng:</span>
            {totalExtraCost > 0 ? (
              <span className="text-amber-700 font-bold">
                Phụ liệu: ~{totalExtraCost.toLocaleString('vi-VN')} đ
              </span>
            ) : (
              <span className="text-emerald-700 font-bold">0 đ bổ sung</span>
            )}
          </p>

          <div className="space-y-1">
            {currentCraft.materialsUsed.map((m, i) => (
              <div key={i} className="flex items-center gap-1.5 text-slate-600 text-[11px]">
                <CheckCircle className="w-3 h-3 text-emerald-600 shrink-0" />
                <span className="truncate">{m.name}</span>
                <span className="text-[10px] text-slate-400">({m.role})</span>
              </div>
            ))}

            {currentCraft.materialsNeededExtra.map((extra, idx) => (
              <div key={idx} className="flex items-center gap-1.5 text-indigo-700 text-[11px]">
                <PlusCircle className="w-3 h-3 text-indigo-500 shrink-0" />
                <span className="truncate">{extra.name}</span>
                <span className="text-[10px] text-slate-400">({extra.purpose})</span>
              </div>
            ))}
          </div>
        </div>

        {/* Finished Dimensions */}
        <div className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xl flex items-center justify-between">
          <span>Kích thước sản phẩm:</span>
          <span className="font-mono font-medium text-slate-700">
            {currentCraft.dimensionsFinished.lengthCm} × {currentCraft.dimensionsFinished.widthCm} ×{' '}
            {currentCraft.dimensionsFinished.heightCm} cm
          </span>
        </div>

        {/* Action Button */}
        <button
          onClick={() => onSelect(currentCraft)}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
        >
          <Hammer className="w-4 h-4" />
          <span>Vào Xưởng Chế Tạo 3D ({currentCraft.steps.length} bước)</span>
        </button>
      </div>
    </div>
  );
};

