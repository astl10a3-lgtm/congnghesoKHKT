import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  Camera,
  Upload,
  Trash2,
  Plus,
  RefreshCw,
  Ruler,
  AlertCircle,
  Sparkles,
  CheckCircle,
  Image as ImageIcon,
  Layers,
  SwitchCamera,
  Grid,
  X,
  Check,
  RotateCw,
  Maximize2,
  Minimize2,
  FileText
} from 'lucide-react';
import { AnalysisInput } from '../../server/gemini';

interface MaterialCaptureProps {
  onStartAnalysis: (input: AnalysisInput) => void;
  isAnalyzing: boolean;
}

export const MaterialCapture: React.FC<MaterialCaptureProps> = ({
  onStartAnalysis,
  isAnalyzing,
}) => {
  const [photos, setPhotos] = useState<string[]>([]);
  const [activeAngleIndex, setActiveAngleIndex] = useState<number>(0);
  const [referenceType, setReferenceType] = useState<
    'none' | 'ruler_30cm' | 'ruler_15cm' | 'credit_card_85mm' | 'coin_25mm'
  >('credit_card_85mm');
  const [referenceDescription, setReferenceDescription] = useState('');
  const [userNotes, setUserNotes] = useState('');

  // AI Engine selector state (Google Gemini vs OpenAI ChatGPT vs Dual)
  const [aiEngine, setAiEngine] = useState<'gemini' | 'chatgpt' | 'dual'>('gemini');

  // Camera stream state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [showGrid, setShowGrid] = useState<boolean>(false);
  const [isFlashing, setIsFlashing] = useState<boolean>(false);
  const [isVideoLive, setIsVideoLive] = useState<boolean>(false);
  const [isFullscreenCamera, setIsFullscreenCamera] = useState<boolean>(false);

  // Orientation tracking
  const [deviceOrientation, setDeviceOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [forcedOrientation, setForcedOrientation] = useState<'auto' | 'portrait' | 'landscape'>('auto');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const cameraContainerRef = useRef<HTMLDivElement>(null);
  const notesTextareaRef = useRef<HTMLTextAreaElement | null>(null);
  const isComposingNotesRef = useRef<boolean>(false);

  const autoGrowNotesTextarea = (el?: HTMLTextAreaElement | null) => {
    const target = el || notesTextareaRef.current;
    if (!target) return;
    target.style.height = 'auto';
    target.style.height = `${Math.max(120, target.scrollHeight)}px`;
  };

  const setUserNotesProgrammatic = (nextValue: string) => {
    setUserNotes(nextValue);
    if (notesTextareaRef.current) {
      notesTextareaRef.current.value = nextValue;
      autoGrowNotesTextarea(notesTextareaRef.current);
    }
  };

  const recommendedAngles = [
    {
      name: 'Chính diện',
      desc: 'Chụp thẳng mặt trước của vật liệu',
      tip: 'Đặt vật liệu đứng thẳng, ánh sáng đều rõ logo/nhãn',
    },
    {
      name: 'Mặt sau',
      desc: 'Xoay 180° chụp mặt lưng',
      tip: 'Kiểm tra mặt sau xem có vết thủng, nhãn phụ hoặc nứt',
    },
    {
      name: 'Góc nghiêng',
      desc: 'Chụp nghiêng 45° bên hông',
      tip: 'Giúp AI ước lượng chiều dày và độ cong hình học 3D',
    },
    {
      name: 'Từ trên xuống',
      desc: 'Góc nhìn đỉnh vật liệu',
      tip: 'Quan sát miệng chai, nắp vặn hoặc độ rỗng bên trong',
    },
    {
      name: 'Cận cảnh / Thước',
      desc: 'Ký hiệu tái chế hoặc vật tham chiếu',
      tip: 'Đặt thẻ ATM hoặc thước kẻ kế bên để AI đo milimet',
    },
  ];

  // Effective orientation (either auto-detected or manually toggled)
  const effectiveOrientation = forcedOrientation === 'auto' ? deviceOrientation : forcedOrientation;

  // Listen to physical phone rotation via orientation media query (avoids keyboard-resize re-renders while typing on mobile)
  useEffect(() => {
    const mediaQuery = window.matchMedia('(orientation: landscape)');
    const checkOrientation = () => {
      // Ignore viewport height shrinkage caused by opening the mobile virtual keyboard while typing
      const activeTag = document.activeElement?.tagName;
      if (activeTag === 'TEXTAREA' || activeTag === 'INPUT') return;
      setDeviceOrientation(mediaQuery.matches ? 'landscape' : 'portrait');
    };

    checkOrientation();
    mediaQuery.addEventListener?.('change', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);

    return () => {
      mediaQuery.removeEventListener?.('change', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  // Continuous stream keep-alive watchdog to prevent mobile Safari from freezing the video
  useEffect(() => {
    if (!isCameraActive) return;
    const interval = setInterval(() => {
      const v = videoRef.current;
      if (v && streamRef.current && v.paused) {
        v.play().catch(() => {});
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [isCameraActive]);

  // Callback ref for Video element: forces inline play on iOS Safari & resumes if paused
  const setVideoRef = useCallback((el: HTMLVideoElement | null) => {
    videoRef.current = el;
    if (!el) return;

    // Critical imperative attributes required by iOS WebKit Safari
    el.muted = true;
    el.playsInline = true;
    el.autoplay = true;
    el.setAttribute('playsinline', 'true');
    el.setAttribute('webkit-playsinline', 'true');
    el.setAttribute('muted', '');
    el.setAttribute('autoplay', '');

    if (streamRef.current) {
      if (el.srcObject !== streamRef.current) {
        el.srcObject = streamRef.current;
      }
      el.play()
        .then(() => setIsVideoLive(true))
        .catch((err) => console.warn('Video play error:', err));
    }

    // Auto-resume if iOS pauses the stream
    el.onpause = () => {
      if (streamRef.current) {
        el.play().catch(() => {});
      }
    };
  }, []);

  // Start Camera with resilient constraints
  const startCamera = async (fullscreen = false) => {
    setCameraError(null);
    setIsCameraActive(true);
    if (fullscreen) {
      setIsFullscreenCamera(true);
    }

    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: cameraFacing },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      };

      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia(constraints);
      } catch (firstErr) {
        console.warn('Initial camera constraints failed, attempting fallback...', firstErr);
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: cameraFacing },
          audio: false,
        });
      }

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.muted = true;
        videoRef.current.playsInline = true;
        videoRef.current.autoplay = true;
        videoRef.current.setAttribute('playsinline', 'true');
        videoRef.current.setAttribute('webkit-playsinline', 'true');
        videoRef.current.srcObject = stream;
        videoRef.current.play()
          .then(() => setIsVideoLive(true))
          .catch((err) => console.warn('Video play error:', err));
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError('Không thể mở camera. Vui lòng cấp quyền truy cập camera trong trình duyệt hoặc sử dụng nút "Chọn ảnh từ máy".');
      setIsCameraActive(false);
      setIsVideoLive(false);
      setIsFullscreenCamera(false);
    }
  };

  // Stop Camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setIsVideoLive(false);
    setIsFullscreenCamera(false);
  };

  // Switch Camera front/back
  const toggleCameraFacing = () => {
    setCameraFacing((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  useEffect(() => {
    if (isCameraActive) {
      startCamera(isFullscreenCamera);
    }
  }, [cameraFacing]);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // Snap photo from live camera
  const capturePhoto = () => {
    if (!videoRef.current) return;

    // Trigger visual flash feedback
    setIsFlashing(true);
    setTimeout(() => setIsFlashing(false), 160);

    // Haptic feedback for mobile devices
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(40);
      } catch (e) {
        // Ignore vibration error
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1280;
    canvas.height = videoRef.current.videoHeight || 960;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.88);

    setPhotos((prev) => [...prev, dataUrl]);

    // Automatically advance to next angle recommendation
    setActiveAngleIndex((prev) => Math.min(prev + 1, recommendedAngles.length - 1));
  };

  // Handle file uploads (multiple files supported)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newPhotos: string[] = [];
    let processed = 0;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          newPhotos.push(event.target.result as string);
        }
        processed++;
        if (processed === files.length) {
          setPhotos((prev) => [...prev, ...newPhotos]);
          setActiveAngleIndex((prev) => Math.min(prev + newPhotos.length, recommendedAngles.length - 1));
        }
      };
      reader.readAsDataURL(file);
    });

    e.target.value = '';
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  // Toggle orientation manually (Portrait <-> Landscape)
  const toggleManualOrientation = () => {
    setForcedOrientation((current) => {
      if (current === 'auto') {
        return deviceOrientation === 'portrait' ? 'landscape' : 'portrait';
      }
      return current === 'portrait' ? 'landscape' : 'portrait';
    });
  };

  // Quick preset sample loaders
  const loadBottleSample = () => {
    setPhotos([
      'https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?w=700&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1545241047-6083a3684587?w=700&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1616401784845-180882ba9ba8?w=700&auto=format&fit=crop&q=80',
    ]);
    setUserNotesProgrammatic('Chai nhựa nước giải khát PET 500ml còn nắp xanh');
    setReferenceType('credit_card_85mm');
  };

  const loadCardboardSample = () => {
    setPhotos([
      'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=700&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1586075010923-2dd4570fb338?w=700&auto=format&fit=crop&q=80',
    ]);
    setUserNotesProgrammatic('Hộp carton đựng giày 3 lớp sạch sẽ');
    setReferenceType('ruler_30cm');
  };

  const handleSubmitAnalysis = () => {
    if (photos.length === 0) return;
    const rawNotes = notesTextareaRef.current ? notesTextareaRef.current.value : userNotes;
    const effectiveNotes =
      rawNotes.trim().length > 0
        ? rawNotes
        : 'Vật liệu rác thải sinh hoạt gia đình/trường học đã thu gom, cần phân tích chi tiết độ dày, cấu trúc và đề xuất đúng 3 sản phẩm tái chế tối ưu có mô hình 3D tương tác.';
    onStartAnalysis({
      images: photos,
      referenceObject: {
        type: referenceType,
        description: referenceDescription,
      },
      userNotes: effectiveNotes,
      aiEngine,
    });
  };

  const completionPercent = Math.min(100, Math.round((photos.length / 4) * 100));

  return (
    <div className="space-y-6 max-w-5xl mx-auto py-2">
      {/* Header (compacted when camera is active so camera stays immediately in viewport) */}
      {!isCameraActive ? (
        <div className="text-center space-y-2 px-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
            <Camera className="w-3.5 h-3.5 text-emerald-600" />
            <span>BƯỚC 1: QUÉT VẬT LIỆU ĐA CHIỀU</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Chụp ảnh hoặc tải lên vật liệu tái chế
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed">
            Màn hình chụp và nút bấm tách biệt rõ ràng, dễ dàng thao tác một tay trên điện thoại.
          </p>
        </div>
      ) : (
        <div className="flex items-center justify-between px-2 bg-emerald-50/80 border border-emerald-200/80 p-2.5 rounded-2xl text-xs">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-emerald-600" />
            <span className="font-bold text-emerald-950">Camera Chụp Ảnh Tái Chế</span>
            <span className="text-emerald-700 font-medium">({photos.length}/5 góc đã chụp)</span>
          </div>
          <button
            type="button"
            onClick={stopCamera}
            className="text-emerald-800 hover:text-emerald-950 font-bold underline text-xs cursor-pointer"
          >
            Đóng Camera
          </button>
        </div>
      )}

      {/* Progress & Angle Coverage Indicator (shown when camera is not open) */}
      {!isCameraActive && (
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-600" />
              <span className="font-bold text-sm text-slate-800">
                Độ hoàn thiện dữ liệu góc chụp ({photos.length} ảnh đã chụp)
              </span>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-full self-start sm:self-auto ${
                photos.length >= 3
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {photos.length >= 3
                ? '✓ Đủ điều kiện phân tích 3D tối ưu'
                : `Khuyên dùng thêm ${Math.max(1, 3 - photos.length)} góc ảnh`}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                photos.length >= 3 ? 'bg-emerald-500' : 'bg-amber-400'
              }`}
              style={{ width: `${Math.max(15, completionPercent)}%` }}
            />
          </div>

          {/* 5 Recommended Angles Grid / Clickable Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
            {recommendedAngles.map((angle, idx) => {
              const isFilled = idx < photos.length;
              const isCurrent = idx === activeAngleIndex;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setActiveAngleIndex(idx);
                    startCamera();
                  }}
                  className={`p-2.5 rounded-xl border text-xs text-left transition ${
                    isCurrent
                      ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 ring-2 ring-emerald-400/40'
                      : isFilled
                      ? 'border-emerald-200 bg-emerald-50/40 text-emerald-900'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold mb-0.5">
                    <span className="text-[11px] text-slate-500 font-semibold">Góc {idx + 1}</span>
                    {isFilled ? (
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-slate-300" />
                    )}
                  </div>
                  <p className="font-bold text-slate-800 truncate">{angle.name}</p>
                  <p className="text-[10px] text-slate-500 line-clamp-1">{angle.desc}</p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Camera Live Stream & Dedicated Control Dock */}
      <div
        ref={cameraContainerRef}
        className="space-y-4"
      >
        {/* Camera error notification if any */}
        {cameraError && (
          <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold block mb-0.5">Thông báo Camera</span>
              <span>{cameraError}</span>
            </div>
            <button
              type="button"
              onClick={() => setCameraError(null)}
              className="p-1 rounded-md hover:bg-amber-100 text-amber-700 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {isCameraActive ? (
          /* ========================================================
             ACTIVE CAMERA WORKSPACE:
             1. KHU VỰC MÀN HÌNH CHỤP LINH HOẠT (FREE-MOVING REAL-TIME VIEWFINDER)
             2. KHU VỰC NÚT CHỤP TÁCH RỜI RIÊNG BIỆT (DEDICATED SHUTTER DOCK)
             ======================================================== */
          <div
            className={`transition-all duration-300 ${
              isFullscreenCamera
                ? 'fixed inset-0 z-50 bg-black text-white flex flex-col justify-between p-3 sm:p-5'
                : 'space-y-3'
            }`}
          >
            {/* ----------------------------------------------------
                PHẦN 1: MÀN HÌNH CHỤP CAMERA THÔNG THUỐNG, LINH HOẠT
                ---------------------------------------------------- */}
            <div
              className={`relative rounded-3xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center shadow-xl transition-all duration-300 w-full ${
                isFullscreenCamera
                  ? 'flex-1 my-2 min-h-[300px]'
                  : effectiveOrientation === 'landscape'
                  ? 'aspect-[16/9] min-h-[320px] max-h-[65vh]'
                  : 'h-[44vh] sm:h-[48vh] min-h-[320px] max-h-[500px]'
              }`}
            >
              {/* The Live Video Element (Active, uninterrupted stream on iOS Safari & Android) */}
              <video
                ref={setVideoRef}
                playsInline
                autoPlay
                muted
                webkit-playsinline="true"
                onLoadedMetadata={() => {
                  setIsVideoLive(true);
                  videoRef.current?.play().catch(console.warn);
                }}
                onPlay={() => setIsVideoLive(true)}
                onClick={() => videoRef.current?.play().catch(() => {})}
                className="w-full h-full object-cover select-none cursor-pointer"
              />

              {/* Shutter Visual Flash Animation */}
              {isFlashing && (
                <div className="absolute inset-0 bg-white/80 pointer-events-none transition-opacity duration-150 animate-out fade-out z-30" />
              )}

              {/* Live Status indicator when video is warming up */}
              {!isVideoLive && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/80 text-white gap-2 z-20 pointer-events-none">
                  <RefreshCw className="w-7 h-7 text-emerald-400 animate-spin" />
                  <span className="text-xs text-slate-300 font-medium">Đang khởi động ống kính...</span>
                </div>
              )}

              {/* Viewfinder Alignment Corner Markers */}
              <div className="absolute inset-4 sm:inset-7 border border-white/20 rounded-2xl pointer-events-none z-10">
                <div className="w-7 h-7 sm:w-10 sm:h-10 border-t-2 border-l-2 border-emerald-400 absolute -top-1 -left-1 rounded-tl-lg" />
                <div className="w-7 h-7 sm:w-10 sm:h-10 border-t-2 border-r-2 border-emerald-400 absolute -top-1 -right-1 rounded-tr-lg" />
                <div className="w-7 h-7 sm:w-10 sm:h-10 border-b-2 border-l-2 border-emerald-400 absolute -bottom-1 -left-1 rounded-bl-lg" />
                <div className="w-7 h-7 sm:w-10 sm:h-10 border-b-2 border-r-2 border-emerald-400 absolute -bottom-1 -right-1 rounded-br-lg" />

                {/* Optional Grid (disabled by default for maximum clean view) */}
                {showGrid && (
                  <div className="w-full h-full grid grid-cols-3 grid-rows-3 opacity-20 pointer-events-none">
                    <div className="border-r border-b border-white" />
                    <div className="border-r border-b border-white" />
                    <div className="border-b border-white" />
                    <div className="border-r border-b border-white" />
                    <div className="border-r border-b border-white" />
                    <div className="border-b border-white" />
                    <div className="border-r border-white" />
                    <div className="border-r border-white" />
                    <div />
                  </div>
                )}
              </div>

              {/* Top Viewfinder Bar (Clean & Minimal) */}
              <div className="absolute top-3 inset-x-3 sm:top-4 sm:inset-x-4 flex items-center justify-between gap-2 pointer-events-auto z-20">
                {/* Clean Angle Indicator */}
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white text-xs font-semibold shadow-md">
                  <Camera className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="truncate max-w-[150px] sm:max-w-none">
                    Góc {activeAngleIndex + 1}: {recommendedAngles[activeAngleIndex].name}
                  </span>
                </div>

                {/* Viewfinder Tools: Fullscreen, Rotate, Grid, Close */}
                <div className="flex items-center gap-1 bg-black/60 backdrop-blur-md border border-white/20 p-1 rounded-full text-white">
                  {/* Fullscreen Camera Toggle */}
                  <button
                    type="button"
                    onClick={() => setIsFullscreenCamera((prev) => !prev)}
                    className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition cursor-pointer"
                    title={isFullscreenCamera ? 'Thu nhỏ khung hình' : 'Mở toàn màn hình máy ảnh'}
                  >
                    {isFullscreenCamera ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  </button>

                  {/* Manual Phone/Frame Rotation Toggle */}
                  <button
                    type="button"
                    onClick={toggleManualOrientation}
                    className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition flex items-center gap-1 text-[11px] font-bold cursor-pointer"
                    title="Xoay khung ngang / dọc"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>

                  {/* Grid Toggle */}
                  <button
                    type="button"
                    onClick={() => setShowGrid((prev) => !prev)}
                    className={`p-1.5 rounded-full text-xs transition cursor-pointer ${
                      showGrid ? 'bg-emerald-500/40 text-emerald-300' : 'text-white/60 hover:text-white'
                    }`}
                    title="Bật/Tắt đường lưới căn góc"
                  >
                    <Grid className="w-3.5 h-3.5" />
                  </button>

                  {/* Close Camera */}
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-rose-500/50 transition cursor-pointer"
                    title="Đóng camera"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* ----------------------------------------------------
                PHẦN 2: BẢNG NÚT CHỤP TÁCH BIỆT HOÀN TOÀN (DEDICATED SHUTTER BAR)
                Nằm tách biệt bên dưới, luôn cố định trong tầm tay (sticky bottom)
                ---------------------------------------------------- */}
            <div className="sticky bottom-2 z-40 sm:static rounded-3xl bg-slate-900/95 backdrop-blur-md border border-slate-700/80 p-3 sm:p-4 text-white shadow-2xl space-y-3">
              {/* Quick Angle Chips Row */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {recommendedAngles.map((angle, idx) => {
                  const isFilled = idx < photos.length;
                  const isActive = idx === activeAngleIndex;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setActiveAngleIndex(idx)}
                      className={`shrink-0 px-2.5 py-1 rounded-xl text-[11px] font-semibold flex items-center gap-1.5 transition ${
                        isActive
                          ? 'bg-emerald-500 text-white shadow-sm ring-2 ring-emerald-400/40'
                          : isFilled
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/70'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700/60'
                      }`}
                    >
                      {isFilled ? (
                        <Check className="w-3 h-3 text-emerald-300 shrink-0" />
                      ) : (
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-500 shrink-0" />
                      )}
                      <span>{idx + 1}. {angle.name}</span>
                    </button>
                  );
                })}
              </div>

              {/* Main Shutter Controller Row (Native Phone Ergonomics) */}
              <div className="flex items-center justify-between px-2 sm:px-6 pt-1">
                {/* Left: Thumbnail of Last Photo */}
                <div className="w-16 flex flex-col items-center justify-center">
                  {photos.length > 0 ? (
                    <div
                      className="relative group cursor-pointer"
                      onClick={() => fileInputRef.current?.click()}
                      title="Nhấn để tải thêm ảnh từ máy"
                    >
                      <div className="w-12 h-12 rounded-xl overflow-hidden border-2 border-white/50 shadow-md">
                        <img
                          src={photos[photos.length - 1]}
                          alt="Ảnh vừa chụp"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <span className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-xs">
                        {photos.length}
                      </span>
                      <span className="text-[10px] text-slate-400 mt-0.5 block font-medium text-center">
                        Đã chụp
                      </span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex flex-col items-center justify-center text-slate-400 hover:text-white transition group cursor-pointer"
                      title="Tải ảnh từ máy"
                    >
                      <div className="w-11 h-11 rounded-xl bg-slate-800 group-hover:bg-slate-700 flex items-center justify-center border border-slate-700">
                        <Upload className="w-5 h-5 text-slate-300" />
                      </div>
                      <span className="text-[10px] text-slate-400 mt-0.5">Tải ảnh</span>
                    </button>
                  )}
                </div>

                {/* Center: BIG DEDICATED NATIVE SHUTTER BUTTON */}
                <div className="flex flex-col items-center">
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="relative group p-1.5 sm:p-2 rounded-full bg-white/20 border-2 border-white/90 hover:border-emerald-300 hover:bg-emerald-500/20 active:scale-90 transition-all duration-150 focus:outline-hidden touch-manipulation cursor-pointer"
                    title="Bấm để chụp góc này"
                    aria-label="Chụp ảnh góc hiện tại"
                  >
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-emerald-500 hover:bg-emerald-400 group-hover:bg-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-500/50 text-white transition">
                      <Camera className="w-7 h-7 sm:w-9 sm:h-9" />
                    </div>
                  </button>
                  <span className="text-xs font-bold text-emerald-400 mt-1.5 tracking-wide uppercase text-center">
                    Chụp: {recommendedAngles[activeAngleIndex].name}
                  </span>
                </div>

                {/* Right: Camera Switch button */}
                <div className="w-16 flex flex-col items-center justify-center">
                  <button
                    type="button"
                    onClick={toggleCameraFacing}
                    className="flex flex-col items-center justify-center text-slate-300 hover:text-white transition group cursor-pointer"
                    title="Đổi camera trước / sau"
                  >
                    <div className="w-11 h-11 rounded-xl bg-slate-800 group-hover:bg-slate-700 flex items-center justify-center border border-slate-700 active:rotate-180 transition-transform duration-300">
                      <SwitchCamera className="w-5 h-5 text-slate-200" />
                    </div>
                    <span className="text-[10px] text-slate-400 mt-0.5 text-center">
                      {cameraFacing === 'environment' ? 'Cam sau' : 'Cam trước'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Status & Close Camera Quick Action */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px]">
                  Đã có <strong className="text-white font-bold">{photos.length} ảnh</strong>
                  {photos.length >= 3 ? ' (Đủ điều kiện AI 3D)' : ' (Nên thêm)'}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] border border-slate-700 transition cursor-pointer"
                  >
                    + Thêm
                  </button>
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[11px] transition shadow-xs cursor-pointer"
                  >
                    Xong
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Empty / Standby State (When camera is not active) */
          <div className="p-4 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm text-center">
            <div className="border-2 border-dashed border-slate-300 hover:border-emerald-400 rounded-2xl p-6 sm:p-10 text-center transition bg-slate-50/50 flex flex-col items-center justify-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-xs">
                <Camera className="w-8 h-8" />
              </div>

              <div className="space-y-1 max-w-md">
                <h3 className="font-bold text-slate-800 text-base sm:text-lg">
                  Chụp trực tiếp bằng Camera hoặc Tải ảnh từ máy
                </h3>
                <p className="text-xs text-slate-500">
                  Màn hình chụp chuyển động linh hoạt theo tay cầm, không bị khóa hình. Bảng nút chụp riêng biệt ở phía dưới dễ thao tác một tay trên điện thoại.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => startCamera(false)}
                  className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center gap-2.5 shadow-md shadow-emerald-600/20 active:scale-95 transition cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>Mở Camera Chụp Ảnh</span>
                </button>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-5 py-3 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-sm font-bold flex items-center gap-2 shadow-xs transition cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-slate-500" />
                  <span>Chọn ảnh từ máy</span>
                </button>
              </div>

              {/* Quick Demo Previews */}
              <div className="pt-2 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500">
                <span>Thử nhanh mẫu có sẵn:</span>
                <button
                  type="button"
                  onClick={loadBottleSample}
                  className="text-emerald-700 hover:underline font-semibold bg-emerald-50 px-2 py-0.5 rounded-md cursor-pointer"
                >
                  Chai nhựa PET 500ml
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={loadCardboardSample}
                  className="text-emerald-700 hover:underline font-semibold bg-emerald-50 px-2 py-0.5 rounded-md cursor-pointer"
                >
                  Hộp carton Kraft
                </button>
              </div>
            </div>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={handleFileUpload}
        />

        {/* Thumbnail Gallery of Uploaded / Captured Photos */}
        {photos.length > 0 && (
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                <span>Ảnh đã thu thập ({photos.length} góc ảnh)</span>
              </span>
              <button
                type="button"
                onClick={() => setPhotos([])}
                className="text-xs text-rose-600 hover:underline flex items-center gap-1 font-medium cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Xóa tất cả</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {photos.map((imgUrl, index) => (
                <div
                  key={index}
                  className="relative group rounded-xl overflow-hidden aspect-square border border-slate-200 bg-slate-100 shadow-xs"
                >
                  <img
                    src={imgUrl}
                    alt={`Góc chụp ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => removePhoto(index)}
                      className="p-1.5 rounded-lg bg-rose-600 text-white hover:bg-rose-700 transition cursor-pointer"
                      title="Xóa ảnh này"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <span className="absolute bottom-1 left-1 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded-md font-mono">
                    Góc #{index + 1}
                  </span>
                </div>
              ))}

              {/* Add more button */}
              <button
                type="button"
                onClick={() => {
                  if (!isCameraActive) {
                    startCamera();
                  } else {
                    fileInputRef.current?.click();
                  }
                }}
                className="aspect-square rounded-xl border-2 border-dashed border-slate-300 hover:border-emerald-500 hover:bg-emerald-50/50 flex flex-col items-center justify-center text-slate-500 hover:text-emerald-700 transition cursor-pointer"
              >
                <Plus className="w-5 h-5 mb-1" />
                <span className="text-[11px] font-bold">Thêm ảnh</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Component Description & User Requirements for Detailed AI Analysis */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-sm sm:text-base flex items-center gap-2 flex-wrap">
                <span>Mô tả thành phần & Yêu cầu của bạn</span>
                <span className="text-[10px] font-black tracking-wider uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  Bắt buộc để AI phân tích kỹ hơn
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Mô tả chi tiết giúp AI nhận diện đúng độ dày, tình trạng sạch/bẩn, nắp phụ kiện và ý muốn tái chế để đề xuất 3 sản phẩm tối ưu kèm mô hình 3D tương tác.
              </p>
            </div>
          </div>
          {userNotes.trim().length >= 10 ? (
            <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-xl shrink-0 self-start sm:self-auto">
              <Check className="w-3.5 h-3.5" />
              <span>Đã có mô tả chi tiết</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-3 py-1 rounded-xl shrink-0 self-start sm:self-auto">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Cần thêm thông tin</span>
            </span>
          )}
        </div>

        {/* Textarea (Uncontrolled DOM during IME composition so mobile keyboards never block spaces or Vietnamese Telex) */}
        <div className="space-y-2">
          <textarea
            ref={notesTextareaRef}
            rows={4}
            defaultValue={userNotes}
            onCompositionStart={() => {
              isComposingNotesRef.current = true;
            }}
            onCompositionEnd={(e) => {
              isComposingNotesRef.current = false;
              setUserNotes(e.currentTarget.value);
              autoGrowNotesTextarea(e.currentTarget);
            }}
            onInput={(e) => {
              autoGrowNotesTextarea(e.currentTarget);
              if (!isComposingNotesRef.current) {
                setUserNotes(e.currentTarget.value);
              }
            }}
            onBlur={(e) => {
              setUserNotes(e.currentTarget.value);
            }}
            autoComplete="off"
            autoCorrect="on"
            autoCapitalize="sentences"
            spellCheck={true}
            enterKeyHint="enter"
            inputMode="text"
            placeholder="Ví dụ: Tôi có 1 chai nhựa PET 500ml trong suốt đã rửa sạch bóc tem nhãn, kèm 2 nắp chai màu xanh. Muốn tái chế thành đồ trang trí bàn học hoặc chậu cây nhỏ xinh xắn..."
            className="w-full min-h-[120px] p-3.5 rounded-2xl border border-slate-300 text-base sm:text-sm text-slate-800 bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-hidden leading-relaxed resize-y shadow-2xs touch-auto select-text whitespace-pre-wrap"
          />
          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 px-1">
            <span>Hỗ trợ gõ dấu cách, xuống dòng tự do trên điện thoại & máy tính</span>
            <span className="font-semibold text-emerald-700">
              {userNotes.length} ký tự • Không giới hạn chữ
            </span>
          </div>

          {/* Quick-suggestion chips */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-500 block">
              💡 Gợi ý nhanh (Bấm để chèn tự động vào mô tả):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                'Chai nhựa PET 500ml trong suốt, đã rửa sạch, có nắp',
                'Thùng carton sóng 3 lớp khô ráo 30x25cm',
                'Vỏ lon nhôm 330ml nguyên vẹn, đã phơi khô',
                'Hộp sữa tươi 1L tráng nhôm đã khử mùi',
                'Muốn làm chậu cây tự dưỡng hoặc lọ hoa',
                'Muốn làm ống cắm bút hoặc kệ để bàn'
              ].map((chip, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    const current = notesTextareaRef.current ? notesTextareaRef.current.value : userNotes;
                    if (current.includes(chip)) return;
                    const nextVal = current ? `${current} ${chip}` : chip;
                    setUserNotesProgrammatic(nextVal);
                  }}
                  className="px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-200 border border-slate-200 text-[11px] text-slate-600 font-medium transition cursor-pointer"
                >
                  + {chip}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Reference Object Scale Calibration row */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Ruler className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-bold text-xs text-slate-800 block">
                Vật tham chiếu tỷ lệ kích thước 3D (Khuyên dùng)
              </span>
              <span className="text-[11px] text-slate-500">
                Đặt cạnh vật liệu để AI đo đạc milimet và tính thể tích chính xác.
              </span>
            </div>
          </div>
          <select
            value={referenceType}
            onChange={(e: any) => setReferenceType(e.target.value)}
            className="p-2.5 rounded-xl border border-slate-300 text-xs font-medium text-slate-700 bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden sm:w-72 shrink-0"
          >
            <option value="credit_card_85mm">Thẻ ngân hàng / Thẻ học sinh (85.6 × 53.98 mm)</option>
            <option value="ruler_30cm">Thước kẻ học sinh 30cm</option>
            <option value="ruler_15cm">Thước kẻ mini 15cm</option>
            <option value="coin_25mm">Đồng xu hoặc nắp chai chuẩn 25mm</option>
            <option value="none">Không có vật tham chiếu (AI ước lượng theo chuẩn ISO)</option>
          </select>
        </div>
      </div>


      {/* AI Model Selection: Google Gemini vs OpenAI ChatGPT vs Dual Mode */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
          <div>
            <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Lựa chọn Công cụ AI Đánh Giá & Gợi Ý</span>
            </h4>
            <p className="text-xs text-slate-500">
              Tích hợp Google Gemini 3.8 và OpenAI ChatGPT-4o để đánh giá ảnh, đo đạc và đề xuất sản phẩm tái chế.
            </p>
          </div>
        </div>

        {/* 3 AI Model Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Option 1: Gemini */}
          <button
            type="button"
            onClick={() => setAiEngine('gemini')}
            className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
              aiEngine === 'gemini'
                ? 'border-emerald-500 bg-emerald-50/70 shadow-xs ring-2 ring-emerald-500/20'
                : 'border-slate-200 hover:border-slate-300 bg-white'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-emerald-800 flex items-center gap-1">
                  <span>🌟 Google Gemini 3.8</span>
                </span>
                {aiEngine === 'gemini' && <Check className="w-4 h-4 text-emerald-600" />}
              </div>
              <p className="text-[11px] text-slate-600">
                Đo đạc hình học không gian, milimet & tính toán thể tích chính xác cao.
              </p>
            </div>
            <span className="mt-2 text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md w-fit">
              Tốc độ cao • Mặc định
            </span>
          </button>

          {/* Option 2: ChatGPT */}
          <button
            type="button"
            onClick={() => setAiEngine('chatgpt')}
            className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
              aiEngine === 'chatgpt'
                ? 'border-indigo-500 bg-indigo-50/70 shadow-xs ring-2 ring-indigo-500/20'
                : 'border-slate-200 hover:border-slate-300 bg-white'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-indigo-800 flex items-center gap-1">
                  <span>🤖 OpenAI ChatGPT-4o</span>
                </span>
                {aiEngine === 'chatgpt' && <Check className="w-4 h-4 text-indigo-600" />}
              </div>
              <p className="text-[11px] text-slate-600">
                Ý tưởng thủ công DIY sáng tạo, phối màu nghệ thuật & hướng dẫn dễ hiểu.
              </p>
            </div>
            <span className="mt-2 text-[10px] font-bold text-indigo-700 bg-indigo-100/80 px-2 py-0.5 rounded-md w-fit">
              Sáng tạo DIY cao
            </span>
          </button>

          {/* Option 3: Dual AI */}
          <button
            type="button"
            onClick={() => setAiEngine('dual')}
            className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
              aiEngine === 'dual'
                ? 'border-teal-500 bg-teal-50/70 shadow-xs ring-2 ring-teal-500/20'
                : 'border-slate-200 hover:border-slate-300 bg-white'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-teal-800 flex items-center gap-1">
                  <span>⚡ AI Song Mã Kết Hợp</span>
                </span>
                {aiEngine === 'dual' && <Check className="w-4 h-4 text-teal-600" />}
              </div>
              <p className="text-[11px] text-slate-600">
                Gemini đo đạc milimet + ChatGPT mở rộng các ý tưởng đồ chơi STEM độc đáo.
              </p>
            </div>
            <span className="mt-2 text-[10px] font-bold text-teal-700 bg-teal-100/80 px-2 py-0.5 rounded-md w-fit">
              Đề xuất phong phú nhất
            </span>
          </button>
        </div>
      </div>

      {/* Start AI Analysis Call to Action */}
      <div className="text-center pt-2 pb-4">
        <button
          type="button"
          disabled={photos.length === 0 || isAnalyzing}
          onClick={handleSubmitAnalysis}
          className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-700 hover:via-teal-700 hover:to-indigo-700 disabled:opacity-50 text-white font-extrabold text-base shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-3 mx-auto transition hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
        >
          {isAnalyzing ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>
                {aiEngine === 'chatgpt'
                  ? 'ChatGPT-4o Đang Phân Tích & Sáng Tạo Ý Tưởng...'
                  : aiEngine === 'dual'
                  ? 'AI Song Mã (Gemini + ChatGPT) Đang Đồng Bộ Dựng Hình...'
                  : 'Gemini Vision AI Đang Phân Tích Đa Chiều & Dựng Hình 3D...'}
              </span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span>
                {aiEngine === 'chatgpt'
                  ? 'Phân Tích Bằng ChatGPT-4o & Gợi Ý 3 Mô Hình 3D'
                  : aiEngine === 'dual'
                  ? 'Phân Tích Song Mã & Gợi Ý 3 Mô Hình 3D'
                  : 'Phân Tích Vật Liệu & Gợi Ý 3 Mô Hình 3D'}
              </span>
            </>
          )}
        </button>

        {photos.length === 0 && (
          <p className="text-xs text-slate-400 mt-2">
            * Vui lòng chụp hoặc tải lên ít nhất 1 ảnh để bắt đầu phân tích
          </p>
        )}
      </div>
    </div>
  );
};
