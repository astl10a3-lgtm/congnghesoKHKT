import React, { useState } from 'react';
import {
  Ruler,
  Maximize2,
  Box,
  Layers,
  HelpCircle,
  Calculator,
  Percent,
  CheckCircle,
  Edit2
} from 'lucide-react';
import { MaterialItem } from '../../server/db';

interface GeometryCalculatorCardProps {
  material: MaterialItem;
  onUpdateDimensions?: (dimensions: MaterialItem['dimensions']) => void;
}

export const GeometryCalculatorCard: React.FC<GeometryCalculatorCardProps> = ({
  material,
  onUpdateDimensions,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [dims, setDims] = useState(material.dimensions);

  const isCylinder = dims.shapeType === 'cylinder';
  const isBox = dims.shapeType === 'box';

  const handleSave = () => {
    // Recalculate based on input
    let vol = dims.volumeMl || 0;
    let totalS = dims.totalSurfaceCm2 || 0;
    let usableS = dims.usableSurfaceCm2 || 0;

    if (isCylinder && dims.diameterCm && dims.heightCm) {
      const r = dims.diameterCm / 2;
      const h = dims.heightCm;
      vol = Math.round(Math.PI * r * r * h);
      totalS = Math.round(2 * Math.PI * r * (r + h));
      usableS = Math.round(2 * Math.PI * r * (h * 0.8)); // 80% body cut area
    } else if (isBox && dims.lengthCm && dims.widthCm && dims.heightCm) {
      const a = dims.lengthCm;
      const b = dims.widthCm;
      const c = dims.heightCm;
      vol = Math.round(a * b * c);
      totalS = Math.round(2 * (a * b + b * c + c * a));
      usableS = Math.round(totalS * 0.82);
    }

    const usableRatio = totalS > 0 ? Math.round((usableS / totalS) * 100) : 80;

    const updated = {
      ...dims,
      volumeMl: vol,
      totalSurfaceCm2: totalS,
      usableSurfaceCm2: usableS,
      usableRatioPercent: usableRatio,
    };

    setDims(updated);
    if (onUpdateDimensions) onUpdateDimensions(updated);
    setIsEditing(false);
  };

  return (
    <div className="rounded-3xl bg-white border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-teal-50 text-teal-700">
            <Calculator className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-lg sm:text-xl">
              Toán Học & Đo Lường Kích Thước Hình Học 3D
            </h3>
            <p className="text-xs text-slate-500">
              Công thức hình học xác định thể tích, diện tích bề mặt và lượng vật liệu cắt ghép thực tế
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsEditing(!isEditing)}
          className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-bold text-slate-700 flex items-center gap-1.5 transition self-start sm:self-auto"
        >
          <Edit2 className="w-3.5 h-3.5" />
          <span>{isEditing ? 'Đóng' : 'Nhập kích thước tay'}</span>
        </button>
      </div>

      {/* Dimensional Inputs if editing */}
      {isEditing && (
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
          <p className="font-bold text-slate-800">Hiệu chuẩn kích thước thực tế (cm)</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-slate-600 block mb-1">Chiều cao (H)</label>
              <input
                type="number"
                value={dims.heightCm}
                onChange={(e) => setDims({ ...dims, heightCm: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 rounded-lg border bg-white"
              />
            </div>
            {isCylinder ? (
              <div>
                <label className="text-slate-600 block mb-1">Đường kính (Ø)</label>
                <input
                  type="number"
                  value={dims.diameterCm || 6.5}
                  onChange={(e) =>
                    setDims({ ...dims, diameterCm: parseFloat(e.target.value) || 0 })
                  }
                  className="w-full p-2 rounded-lg border bg-white"
                />
              </div>
            ) : (
              <>
                <div>
                  <label className="text-slate-600 block mb-1">Chiều dài (L)</label>
                  <input
                    type="number"
                    value={dims.lengthCm}
                    onChange={(e) =>
                      setDims({ ...dims, lengthCm: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full p-2 rounded-lg border bg-white"
                  />
                </div>
                <div>
                  <label className="text-slate-600 block mb-1">Chiều rộng (W)</label>
                  <input
                    type="number"
                    value={dims.widthCm}
                    onChange={(e) =>
                      setDims({ ...dims, widthCm: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full p-2 rounded-lg border bg-white"
                  />
                </div>
              </>
            )}
          </div>
          <button
            onClick={handleSave}
            className="px-4 py-2 rounded-xl bg-teal-600 text-white font-bold text-xs"
          >
            Tính toán lại thông số 3D
          </button>
        </div>
      )}

      {/* Geometry Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Dimensions */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            Kích thước (XYZ)
          </span>
          <p className="text-lg font-extrabold text-slate-900">
            {isCylinder
              ? `Ø ${dims.diameterCm || 6.5} × ${dims.heightCm} cm`
              : `${dims.lengthCm} × ${dims.widthCm} × ${dims.heightCm} cm`}
          </p>
          <span className="text-[11px] text-slate-500 block">
            {isCylinder ? 'Hình trụ tròn đều' : 'Hình khối hộp chữ nhật'}
          </span>
        </div>

        {/* Volume */}
        <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1">
          <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
            Thể tích ước tính (V)
          </span>
          <p className="text-lg font-extrabold text-emerald-700">
            {dims.volumeMl || 500} ml / cm³
          </p>
          <span className="text-[11px] text-emerald-600 font-mono block">
            {isCylinder ? 'V = π × r² × h' : 'V = a × b × c'}
          </span>
        </div>

        {/* Total Surface Area */}
        <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-1">
          <span className="text-[11px] font-bold text-blue-800 uppercase tracking-wider">
            Diện tích toàn phần
          </span>
          <p className="text-lg font-extrabold text-blue-700">
            {dims.totalSurfaceCm2 || 400} cm²
          </p>
          <span className="text-[11px] text-blue-600 font-mono block">
            {isCylinder ? 'S_tp = 2πr(r + h)' : '2(ab + bc + ca)'}
          </span>
        </div>

        {/* Usable Surface Area for Crafting */}
        <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-200 space-y-1">
          <span className="text-[11px] font-bold text-teal-800 uppercase tracking-wider">
            Phần có thể tận dụng
          </span>
          <p className="text-lg font-extrabold text-teal-700">
            {dims.usableSurfaceCm2 || 350} cm²{' '}
            <span className="text-xs font-semibold">({dims.usableRatioPercent || 85}%)</span>
          </p>
          <span className="text-[11px] text-teal-600 block">Trừ hao hụt cổ nắp & đáy</span>
        </div>
      </div>

      {/* Applied Mathematical Formula Details */}
      <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-2">
        <div className="flex items-center gap-1.5 font-bold text-slate-800">
          <Ruler className="w-4 h-4 text-emerald-600" />
          <span>Cơ sở hình học & Thuật toán tính toán diện tích chế tạo:</span>
        </div>
        <p className="leading-relaxed">
          {isCylinder
            ? 'Hệ thống nhận diện vật liệu có hình trụ tròn. Diện tích bề mặt xung quanh có thể cắt phẳng là S = 2π × (3.25) × 21 ≈ 428 cm². Sau khi loại trừ phần cổ xoắn ốc (hao hụt 10%) và đáy dập nổi (hao hụt 5%), diện tích phẳng khả dụng để uốn cong hoặc làm thân chậu/hộp bút là ~380 cm².'
            : 'Hệ thống nhận diện khối hộp chữ nhật 6 mặt. Các vách thành bên được phân rã thành các tấm phẳng có diện tích hữu dụng ~1,880 cm² đủ cắt làm 4 tấm ngăn bậc thang hoặc tường mô hình nhà.'}
        </p>
      </div>
    </div>
  );
};
