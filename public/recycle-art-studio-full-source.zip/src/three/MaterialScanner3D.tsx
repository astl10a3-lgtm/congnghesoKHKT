import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import {
  Eye,
  Grid,
  Maximize2,
  Minimize2,
  RotateCcw,
  Ruler,
  ShieldCheck,
  Compass,
  Play,
  Pause,
  Download,
  Crosshair,
  Check,
  Trash2,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';
import { MaterialItem } from '../../server/db';
import {
  createRecycledPETMaterial,
  createHDPECapMaterial,
  createKraftCardboardMaterial,
  createBrushedAluminumMaterial,
} from './photorealisticMaterials';
import { getContactShadowTexture } from './photorealisticTextures';

interface MaterialScanner3DProps {
  material: MaterialItem;
  height?: string;
}

interface MeasuredPoint {
  position: THREE.Vector3;
  label: string;
}

export const MaterialScanner3D: React.FC<MaterialScanner3DProps> = ({
  material,
  height = '460px',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Display modes
  const [renderMode, setRenderMode] = useState<'realistic' | 'wireframe' | 'xray'>('realistic');
  const [showDimensions, setShowDimensions] = useState(true);
  const [showUsableZone, setShowUsableZone] = useState(true);
  const [isAutoRotating, setIsAutoRotating] = useState(false);
  const [isZenMode, setIsZenMode] = useState(false);

  // Caliper 3D measurement tool
  const [isCaliperActive, setIsCaliperActive] = useState(false);
  const [caliperPoints, setCaliperPoints] = useState<MeasuredPoint[]>([]);
  const [measuredDistanceCm, setMeasuredDistanceCm] = useState<number | null>(null);
  const [calibrationHeightCm, setCalibrationHeightCm] = useState<number>(
    material.dimensions.heightCm || 21
  );
  const [showCalibrationModal, setShowCalibrationModal] = useState(false);
  const [exportingGlb, setExportingGlb] = useState(false);

  // Three.js instances
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const dimGroupRef = useRef<THREE.Group | null>(null);
  const measurementGroupRef = useRef<THREE.Group | null>(null);
  const animFrameRef = useRef<number>(0);

  // Camera transition animation target
  const targetCamPosRef = useRef<THREE.Vector3 | null>(null);

  // Calculate scaling factor between 3D scene units and real-world centimeters
  const sceneHeightUnits = (material.dimensions.heightCm || 20) * (material.dimensions.shapeType === 'box' ? 0.08 : 0.1);
  const scaleCmPerUnit = (calibrationHeightCm || 21) / (sceneHeightUnits || 2.0);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL guard
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0xf8fafc); // slate-50 studio background
    scene.fog = new THREE.FogExp2(0xf8fafc, 0.03);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(4, 3.2, 5);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    rendererRef.current = renderer;
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    renderer.domElement.style.touchAction = 'none';
    container.appendChild(renderer.domElement);

    // Studio Environment map via RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // OrbitControls - Allow full 360-degree rotation vertically & horizontally
    const controls = new OrbitControls(camera, renderer.domElement);
    controlsRef.current = controls;
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI - 0.05; // Full 360-degree orbit
    controls.minPolarAngle = 0.05;
    controls.minDistance = 0.8;
    controls.maxDistance = 14;
    controls.target.set(0, 1.0, 0);
    controls.touches = {
      ONE: THREE.TOUCH.ROTATE,
      TWO: THREE.TOUCH.DOLLY_PAN,
    };

    // Studio Lighting Rig
    const ambientLight = new THREE.HemisphereLight(0xffffff, 0xcce0ff, 0.75);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff7ed, 1.9);
    keyLight.position.set(4, 7, 3);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.85);
    fillLight.position.set(-4, 3, -3);
    scene.add(fillLight);

    // Rim light for translucent edge highlights
    const rimLight = new THREE.DirectionalLight(0xffffff, 2.2);
    rimLight.position.set(-2, 5, -4);
    scene.add(rimLight);

    // Ground Grid & Soft Shadow Plane
    const gridHelper = new THREE.GridHelper(12, 24, 0x10b981, 0xe2e8f0);
    gridHelper.position.y = 0.001;
    scene.add(gridHelper);

    // High-fidelity contact shadow
    const shadowGeo = new THREE.PlaneGeometry(3.5, 3.5);
    const shadowTex = getContactShadowTexture();
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.003;
    scene.add(shadowMesh);

    // Build Procedural Material 3D Object
    const modelGroup = new THREE.Group();
    modelGroup.name = 'material_model_root';
    modelGroupRef.current = modelGroup;
    scene.add(modelGroup);

    buildMaterialMesh(modelGroup, material);

    // Build Dimension & Axis Overlays
    const dimGroup = new THREE.Group();
    dimGroupRef.current = dimGroup;
    scene.add(dimGroup);
    buildDimensionGuides(dimGroup, material);

    // Group for live 3D caliper measurement points & lines
    const measurementGroup = new THREE.Group();
    measurementGroupRef.current = measurementGroup;
    scene.add(measurementGroup);

    // Render loop with smooth camera lerping & auto-rotate
    const animate = () => {
      // Smooth camera transition if active
      if (targetCamPosRef.current && cameraRef.current && controlsRef.current) {
        cameraRef.current.position.lerp(targetCamPosRef.current, 0.08);
        if (cameraRef.current.position.distanceTo(targetCamPosRef.current) < 0.02) {
          targetCamPosRef.current = null;
        }
      }

      controls.update();
      renderer.render(scene, camera);
      animFrameRef.current = requestAnimationFrame(animate);
    };
    animate();

    // Resize observer
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    const ro = new ResizeObserver(handleResize);
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animFrameRef.current);
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, [material]);

  // Update render mode (realistic / wireframe / xray)
  useEffect(() => {
    if (!modelGroupRef.current) return;
    modelGroupRef.current.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (mesh.name === 'usableZoneHighlight') return;

        if (mesh.material) {
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => applyMaterialMode(m, renderMode));
          } else {
            applyMaterialMode(mesh.material, renderMode);
          }
        }
      }
    });
  }, [renderMode]);

  // Auto-rotate effect
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = isAutoRotating;
      controlsRef.current.autoRotateSpeed = 2.5;
    }
  }, [isAutoRotating]);

  // Toggle dimensions visibility
  useEffect(() => {
    if (dimGroupRef.current) {
      dimGroupRef.current.visible = showDimensions;
    }
  }, [showDimensions]);

  // Toggle usable zone highlight
  useEffect(() => {
    if (!modelGroupRef.current) return;
    const highlightMesh = modelGroupRef.current.getObjectByName('usableZoneHighlight');
    if (highlightMesh) {
      highlightMesh.visible = showUsableZone;
    }
  }, [showUsableZone]);

  // Handle Caliper Raycast Click on Canvas
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isCaliperActive || !mountRef.current || !cameraRef.current || !modelGroupRef.current) return;

    const rect = mountRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const intersects = raycaster.intersectObjects(modelGroupRef.current.children, true);
    // Ignore helper / wireframe meshes
    const validHit = intersects.find((hit) => hit.object.name !== 'usableZoneHighlight');

    if (validHit) {
      const hitPoint = validHit.point;

      if (caliperPoints.length >= 2) {
        // Reset and set point A
        const newPoints = [{ position: hitPoint, label: 'A' }];
        setCaliperPoints(newPoints);
        setMeasuredDistanceCm(null);
        renderCaliper3D(newPoints);
      } else if (caliperPoints.length === 1) {
        // Set point B and calculate distance
        const newPoints = [...caliperPoints, { position: hitPoint, label: 'B' }];
        setCaliperPoints(newPoints);
        const distUnits = newPoints[0].position.distanceTo(newPoints[1].position);
        const distCm = Number((distUnits * scaleCmPerUnit).toFixed(1));
        setMeasuredDistanceCm(distCm);
        renderCaliper3D(newPoints, distCm);
      } else {
        // First point A
        const newPoints = [{ position: hitPoint, label: 'A' }];
        setCaliperPoints(newPoints);
        renderCaliper3D(newPoints);
      }
    }
  };

  // Render 3D Visual Caliper Line and Spheres in Three.js
  const renderCaliper3D = (pts: MeasuredPoint[], distanceCm?: number) => {
    const group = measurementGroupRef.current;
    if (!group) return;

    // Clear previous measurement geometry
    while (group.children.length > 0) {
      const obj = group.children[0];
      group.remove(obj);
    }

    pts.forEach((p, idx) => {
      // Glowing sphere pin
      const sphereGeo = new THREE.SphereGeometry(0.06, 16, 16);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: idx === 0 ? 0x10b981 : 0xef4444, // Green for A, Red for B
        emissive: idx === 0 ? 0x10b981 : 0xef4444,
        emissiveIntensity: 0.6,
      });
      const sphere = new THREE.Mesh(sphereGeo, sphereMat);
      sphere.position.copy(p.position);
      group.add(sphere);

      // Label sprite
      const sprite = createTextSprite(p.label, idx === 0 ? '#10b981' : '#ef4444');
      sprite.position.copy(p.position).add(new THREE.Vector3(0, 0.15, 0));
      group.add(sprite);
    });

    // If both points exist, draw connecting neon line and midpoint measurement tag
    if (pts.length === 2) {
      const lineGeo = new THREE.BufferGeometry().setFromPoints([pts[0].position, pts[1].position]);
      const lineMat = new THREE.LineDashedMaterial({
        color: 0x38bdf8,
        dashSize: 0.1,
        gapSize: 0.05,
        linewidth: 2,
      });
      const line = new THREE.Line(lineGeo, lineMat);
      line.computeLineDistances();
      group.add(line);

      // Midpoint tag with measured cm
      const midPoint = pts[0].position.clone().add(pts[1].position).multiplyScalar(0.5);
      const distTag = createTextSprite(`${distanceCm} cm`, '#0284c7');
      distTag.position.copy(midPoint).add(new THREE.Vector3(0, 0.2, 0));
      group.add(distTag);
    }
  };

  const clearMeasurement = () => {
    setCaliperPoints([]);
    setMeasuredDistanceCm(null);
    if (measurementGroupRef.current) {
      while (measurementGroupRef.current.children.length > 0) {
        measurementGroupRef.current.remove(measurementGroupRef.current.children[0]);
      }
    }
  };

  // Camera presets transitions
  const setCameraAngle = (angle: 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom' | 'iso') => {
    if (!controlsRef.current) return;
    const dist = 5.2;
    const targetY = 1.0;
    controlsRef.current.target.set(0, targetY, 0);

    const positions: Record<string, THREE.Vector3> = {
      front: new THREE.Vector3(0, targetY, dist),
      back: new THREE.Vector3(0, targetY, -dist),
      left: new THREE.Vector3(-dist, targetY, 0),
      right: new THREE.Vector3(dist, targetY, 0),
      top: new THREE.Vector3(0, targetY + dist * 1.3, 0.001),
      bottom: new THREE.Vector3(0, targetY - dist * 0.9, 0.001),
      iso: new THREE.Vector3(4, 3.2, 5),
    };

    targetCamPosRef.current = positions[angle] || positions.iso;
  };

  // GLTF/GLB Export
  const handleExportGLB = () => {
    if (!modelGroupRef.current) return;
    setExportingGlb(true);

    const exporter = new GLTFExporter();
    exporter.parse(
      modelGroupRef.current,
      (gltf) => {
        const blob = new Blob([gltf as ArrayBuffer], { type: 'application/octet-stream' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${material.name.toLowerCase().replace(/[\s/]/g, '_')}_model.glb`;
        link.click();
        URL.revokeObjectURL(link.href);
        setExportingGlb(false);
      },
      (error) => {
        console.error('An error happened while exporting GLB:', error);
        setExportingGlb(false);
      },
      { binary: true }
    );
  };

  return (
    <div className="w-full space-y-3">
      <div
        className={`relative w-full rounded-3xl overflow-hidden bg-slate-100 border border-slate-200 transition-all ${
          isZenMode ? 'fixed inset-0 z-50 rounded-none h-screen w-screen' : ''
        }`}
        style={{ height: isZenMode ? '100vh' : height }}
      >
      {/* 3D Canvas Mount Point */}
      <div
        ref={mountRef}
        onClick={handleCanvasClick}
        className={`w-full h-full touch-none select-none ${
          isCaliperActive ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'
        }`}
        style={{ touchAction: 'none' }}
      />

      {/* Floating 360 Rotation Guide Badge */}
      <div className="absolute top-16 left-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-xl shadow-xs border border-slate-200 text-[10px] text-slate-600 font-medium pointer-events-none flex items-center gap-1.5 z-10">
        <Compass className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
        <span>Vuốt tay / kéo chuột để xoay 360° tự do</span>
      </div>

      {/* Top Left Status & Geometry Identification Panel */}
      <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none max-w-sm">
        <div className="flex items-center gap-2 bg-white/95 backdrop-blur-md px-3.5 py-1.5 rounded-2xl shadow-sm border border-emerald-100 text-xs font-bold text-emerald-900">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>TÁI DỰNG 3D ĐA GÓC NHÌN (COMPUTER VISION)</span>
        </div>

        <div className="bg-slate-900/85 backdrop-blur-md text-white text-[11px] p-2.5 rounded-2xl shadow-md space-y-1">
          <div className="flex items-center justify-between gap-3">
            <span className="font-semibold text-emerald-300">
              {material.dimensions.shapeType === 'box'
                ? `Hộp: ${material.dimensions.lengthCm} × ${material.dimensions.widthCm} × ${material.dimensions.heightCm} cm`
                : `Trụ: Ø${material.dimensions.diameterCm || 6.5} × H${material.dimensions.heightCm} cm`}
            </span>
            <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full font-mono">
              {material.dimensions.usableRatioPercent}% khả dụng
            </span>
          </div>

          <div className="flex items-center gap-2 text-[10px] text-slate-300 pt-0.5 border-t border-slate-700">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" />
            <span>Kích thước đã hiệu chuẩn</span>
            <span>•</span>
            <span className="text-slate-400">Sai số: ±2%</span>
          </div>
        </div>
      </div>

      {/* Top Right Tool Bar (Export, Fullscreen, Calibrate) */}
      <div className="absolute top-3 right-3 flex items-center gap-2">
        <button
          onClick={() => setShowCalibrationModal(true)}
          className="px-3 py-1.5 rounded-xl bg-white/90 backdrop-blur-md hover:bg-white text-slate-700 shadow-sm border border-slate-200 text-xs font-semibold flex items-center gap-1.5 transition"
          title="Hiệu chỉnh tỷ lệ kích thước thực tế"
        >
          <Compass className="w-3.5 h-3.5 text-indigo-600" />
          <span className="hidden sm:inline">Hiệu chuẩn tỷ lệ</span>
        </button>

        <button
          onClick={handleExportGLB}
          disabled={exportingGlb}
          className="px-3 py-1.5 rounded-xl bg-white/90 backdrop-blur-md hover:bg-white text-slate-700 shadow-sm border border-slate-200 text-xs font-semibold flex items-center gap-1.5 transition"
          title="Tải tệp mô hình 3D (.glb)"
        >
          <Download className="w-3.5 h-3.5 text-emerald-600" />
          <span className="hidden sm:inline">{exportingGlb ? 'Đang xuất...' : 'Tải GLB'}</span>
        </button>

        <button
          onClick={() => setIsZenMode(!isZenMode)}
          className="p-2 rounded-xl bg-white/90 backdrop-blur-md hover:bg-white text-slate-700 shadow-sm border border-slate-200 text-xs font-medium transition"
          title={isZenMode ? 'Thu nhỏ' : 'Toàn màn hình'}
        >
          {isZenMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Floating 3D Caliper Active HUD Card */}
      {isCaliperActive && (
        <div className="absolute top-20 left-3 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl shadow-xl border border-indigo-200 text-xs space-y-2 max-w-xs animate-in fade-in">
          <div className="flex items-center justify-between">
            <span className="font-bold text-indigo-950 flex items-center gap-1.5">
              <Crosshair className="w-4 h-4 text-indigo-600" />
              <span>Thước kẹp 3D (Caliper)</span>
            </span>
            <button
              onClick={clearMeasurement}
              className="text-[11px] text-slate-400 hover:text-rose-600 font-semibold"
            >
              Đặt lại
            </button>
          </div>

          <p className="text-[11px] text-slate-600 leading-tight">
            {caliperPoints.length === 0 && 'Nhấn chuột vào điểm thứ nhất trên mô hình (Điểm A).'}
            {caliperPoints.length === 1 && 'Nhấn chuột vào điểm thứ hai để đo khoảng cách (Điểm B).'}
            {caliperPoints.length === 2 && 'Đã đo xong! Nhấn điểm khác để đo tiếp.'}
          </p>

          {measuredDistanceCm !== null && (
            <div className="p-2 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-between font-mono">
              <span className="text-slate-600 text-[11px]">Khoảng cách A-B:</span>
              <span className="font-extrabold text-indigo-700 text-sm">
                {measuredDistanceCm} cm
              </span>
            </div>
          )}
        </div>
      )}

      {/* Zen Mode Floating Controls Bar (Chỉ hiển thị khi phóng to toàn màn hình) */}
      {isZenMode && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-2xl border border-slate-200 flex items-center gap-2 text-xs z-30">
          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
              isAutoRotating ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
            }`}
          >
            {isAutoRotating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>360°</span>
          </button>
          <button
            onClick={() => {
              setIsCaliperActive(!isCaliperActive);
              if (!isCaliperActive) clearMeasurement();
            }}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
              isCaliperActive ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-indigo-700'
            }`}
          >
            <Crosshair className="w-3.5 h-3.5" />
            <span>Thước đo</span>
          </button>
          <button
            onClick={() => setIsZenMode(false)}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600"
            title="Thu nhỏ"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>

    {/* BẢNG ĐIỀU KHIỂN & CÔNG CỤ 3D (ĐẶT BÊN NGOÀI MÀN HÌNH 3D) */}
    {!isZenMode && (
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-3.5">
        {/* HÀNG 1: CÔNG CỤ ĐO ĐẠC & CHẾ ĐỘ HIỂN THỊ */}
        <div className="flex items-center justify-between flex-wrap gap-2.5 pb-3 border-b border-slate-100 text-xs">
          <div className="flex items-center flex-wrap gap-2">
            {/* Auto-rotate button */}
            <button
              onClick={() => setIsAutoRotating(!isAutoRotating)}
              className={`px-3 py-2 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs ${
                isAutoRotating
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'
              }`}
              title="Tự động xoay 360 độ"
            >
              {isAutoRotating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isAutoRotating ? 'Dừng xoay 360°' : 'Xoay 360°'}</span>
            </button>

            {/* 3D Caliper Mode Button */}
            <button
              onClick={() => {
                setIsCaliperActive(!isCaliperActive);
                if (!isCaliperActive) clearMeasurement();
              }}
              className={`px-3 py-2 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs ${
                isCaliperActive
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-indigo-700'
              }`}
              title="Bật thước kẹp đo khoảng cách 2 điểm"
            >
              <Crosshair className="w-3.5 h-3.5" />
              <span>Thước đo 3D</span>
            </button>

            {/* Dimension Box Toggle */}
            <button
              onClick={() => setShowDimensions(!showDimensions)}
              className={`px-3 py-2 rounded-xl font-medium flex items-center gap-1.5 transition cursor-pointer shadow-2xs ${
                showDimensions
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
              title="Bật/tắt khung kích thước XYZ"
            >
              <Ruler className="w-3.5 h-3.5 text-emerald-600" />
              <span>Khung XYZ</span>
            </button>

            {/* Usable Zone Highlight Toggle */}
            <button
              onClick={() => setShowUsableZone(!showUsableZone)}
              className={`px-3 py-2 rounded-xl font-medium flex items-center gap-1.5 transition cursor-pointer shadow-2xs ${
                showUsableZone
                  ? 'bg-teal-50 text-teal-800 border border-teal-200'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
              title="Làm nổi bật vùng có thể cắt tạo hình"
            >
              <Layers className="w-3.5 h-3.5 text-teal-600" />
              <span>Vùng cắt</span>
            </button>
          </div>

          {/* Render mode selector pills */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl">
            <button
              onClick={() => setRenderMode('realistic')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                renderMode === 'realistic' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Thực tế
            </button>
            <button
              onClick={() => setRenderMode('wireframe')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                renderMode === 'wireframe' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Lưới Mesh
            </button>
            <button
              onClick={() => setRenderMode('xray')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                renderMode === 'xray' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              X-Ray
            </button>
          </div>
        </div>

        {/* HÀNG 2: GÓC NHÌN NHANH 360 ĐỘ */}
        <div className="flex items-center flex-wrap gap-1.5 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1 flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 text-indigo-500" />
            <span>Góc nhìn 3D:</span>
          </span>
          <button
            onClick={() => setCameraAngle('iso')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-semibold text-slate-700 transition cursor-pointer text-[11px]"
          >
            Phối cảnh
          </button>
          <button
            onClick={() => setCameraAngle('front')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
          >
            Chính diện
          </button>
          <button
            onClick={() => setCameraAngle('back')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
          >
            Phía sau
          </button>
          <button
            onClick={() => setCameraAngle('left')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
          >
            Trái
          </button>
          <button
            onClick={() => setCameraAngle('right')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
          >
            Phải
          </button>
          <button
            onClick={() => setCameraAngle('top')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
          >
            Trên đỉnh
          </button>
          <button
            onClick={() => setCameraAngle('bottom')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 font-medium text-slate-700 transition cursor-pointer text-[11px]"
          >
            Dưới đáy
          </button>
        </div>
      </div>
    )}

    {/* Scale Calibration Modal */}
    {showCalibrationModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-2 text-indigo-900 font-bold text-base">
              <Compass className="w-5 h-5 text-indigo-600" />
              <span>Hiệu Chuẩn Tỷ Lệ Thực Tế</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Nếu bạn đã đo vật liệu thực tế bằng thước dây ngoài đời, hãy nhập chiều cao thực tế để AI hiệu chỉnh tỷ lệ mô hình 3D chính xác 100%.
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">Chiều cao thực tế (cm):</label>
              <input
                type="number"
                min="1"
                max="200"
                value={calibrationHeightCm}
                onChange={(e) => setCalibrationHeightCm(Number(e.target.value) || 21)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold font-mono focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowCalibrationModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
              >
                Đóng
              </button>
              <button
                onClick={() => setShowCalibrationModal(false)}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs"
              >
                Lưu hiệu chuẩn
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper: Material rendering modes applier
function applyMaterialMode(mat: THREE.Material, mode: 'realistic' | 'wireframe' | 'xray') {
  if ('wireframe' in mat) {
    (mat as any).wireframe = mode === 'wireframe';
  }
  if (mode === 'xray') {
    mat.transparent = true;
    mat.opacity = 0.35;
    mat.depthWrite = false;
  } else if (mode === 'realistic') {
    mat.transparent = (mat as any)._wasTransparent ?? false;
    mat.opacity = (mat as any)._wasOpacity ?? 1.0;
    mat.depthWrite = true;
  }
}

// 2D Text Sprite for Three.js 3D Viewport Labels
function createTextSprite(text: string, color: string = '#10b981'): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = color;
    ctx.roundRect(16, 16, 224, 96, 24);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 44px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 128, 64);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  const spriteMat = new THREE.SpriteMaterial({ map: texture, depthTest: false, depthWrite: false });
  const sprite = new THREE.Sprite(spriteMat);
  sprite.scale.set(0.65, 0.32, 1);
  return sprite;
}

// Procedural Multi-view Material Mesh Generator
function buildMaterialMesh(group: THREE.Group, material: MaterialItem) {
  const category = material.category;
  const name = material.name.toLowerCase();

  if (category === 'paper' || name.includes('carton') || name.includes('hộp')) {
    buildCardboardBox(group, material);
  } else if (category === 'metal' || name.includes('lon') || name.includes('nhôm')) {
    buildAluminumCan(group, material);
  } else if (category === 'fabric' || name.includes('jean') || name.includes('vải')) {
    buildFabricDenim(group, material);
  } else if (category === 'glass' || name.includes('thủy tinh')) {
    buildGlassJar(group, material);
  } else if (name.includes('nắp')) {
    buildBottleCap(group, material);
  } else {
    // Default: PET Plastic bottle
    buildPlasticBottle(group, material);
  }
}

function buildPlasticBottle(group: THREE.Group, material: MaterialItem) {
  const radius = (material.dimensions.diameterCm ? material.dimensions.diameterCm / 2 : 3.25) * 0.15;
  const height = (material.dimensions.heightCm || 21) * 0.1;

  // 1. Photorealistic recycled PET plastic body material with transmission & micro-scratches
  const bodyMat = createRecycledPETMaterial({ tintColor: 0xffffff, roughness: 0.22 });
  (bodyMat as any)._wasTransparent = true;
  (bodyMat as any)._wasOpacity = 0.85;

  // 2. Main cylinder body with reinforcement ribs
  const bodyH = height * 0.55;
  const bodyGeo = new THREE.CylinderGeometry(radius, radius, bodyH, 48);
  const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
  bodyMesh.position.y = bodyH / 2 + height * 0.15;
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  group.add(bodyMesh);

  // Horizontal reinforcement rib indentations
  const rib1 = new THREE.Mesh(new THREE.TorusGeometry(radius * 0.98, 0.02, 12, 36), bodyMat);
  rib1.rotation.x = Math.PI / 2;
  rib1.position.y = bodyMesh.position.y - bodyH * 0.2;
  group.add(rib1);

  const rib2 = new THREE.Mesh(new THREE.TorusGeometry(radius * 0.98, 0.02, 12, 36), bodyMat);
  rib2.rotation.x = Math.PI / 2;
  rib2.position.y = bodyMesh.position.y + bodyH * 0.2;
  group.add(rib2);

  // 3. Tapered Shoulder
  const shoulderH = height * 0.2;
  const shoulderGeo = new THREE.CylinderGeometry(radius * 0.45, radius, shoulderH, 48);
  const shoulderMesh = new THREE.Mesh(shoulderGeo, bodyMat);
  shoulderMesh.position.y = bodyMesh.position.y + bodyH / 2 + shoulderH / 2;
  shoulderMesh.castShadow = true;
  group.add(shoulderMesh);

  // 4. Threaded Neck
  const neckH = height * 0.1;
  const neckGeo = new THREE.CylinderGeometry(radius * 0.4, radius * 0.45, neckH, 32);
  const neckMesh = new THREE.Mesh(neckGeo, bodyMat);
  neckMesh.position.y = shoulderMesh.position.y + shoulderH / 2 + neckH / 2;
  group.add(neckMesh);

  // 5. Plastic Cap with HDPE knurled flutes
  const capMat = createHDPECapMaterial(0x0284c7);
  const capH = height * 0.08;
  const capGeo = new THREE.CylinderGeometry(radius * 0.44, radius * 0.44, capH, 32);
  const capMesh = new THREE.Mesh(capGeo, capMat);
  capMesh.position.y = neckMesh.position.y + neckH / 2 + capH / 2;
  capMesh.castShadow = true;
  group.add(capMesh);

  // 6. Base / Molded 5 petal feet
  const baseH = height * 0.15;
  const baseGeo = new THREE.CylinderGeometry(radius, radius * 0.88, baseH, 48);
  const baseMesh = new THREE.Mesh(baseGeo, bodyMat);
  baseMesh.position.y = baseH / 2;
  group.add(baseMesh);

  // 7. Usable Zone Green Overlay
  const usableH = bodyH * 0.85;
  const usableGeo = new THREE.CylinderGeometry(radius * 1.02, radius * 1.02, usableH, 24, 1, true);
  const usableMat = new THREE.MeshBasicMaterial({
    color: 0x10b981,
    transparent: true,
    opacity: 0.25,
    side: THREE.DoubleSide,
    wireframe: true,
  });
  const usableMesh = new THREE.Mesh(usableGeo, usableMat);
  usableMesh.name = 'usableZoneHighlight';
  usableMesh.position.y = bodyMesh.position.y;
  group.add(usableMesh);
}

function buildCardboardBox(group: THREE.Group, material: MaterialItem) {
  const l = (material.dimensions.lengthCm || 28) * 0.08;
  const w = (material.dimensions.widthCm || 18) * 0.08;
  const h = (material.dimensions.heightCm || 14) * 0.08;

  const kraftMat = createKraftCardboardMaterial();

  // Main Box body
  const boxGeo = new THREE.BoxGeometry(l, h, w);
  const boxMesh = new THREE.Mesh(boxGeo, kraftMat);
  boxMesh.position.y = h / 2;
  boxMesh.castShadow = true;
  boxMesh.receiveShadow = true;
  group.add(boxMesh);

  // Flap tape seam on top
  const tapeGeo = new THREE.PlaneGeometry(l * 0.95, 0.08);
  const tapeMat = new THREE.MeshStandardMaterial({
    color: 0xe29578,
    roughness: 0.55,
  });
  const tapeMesh = new THREE.Mesh(tapeGeo, tapeMat);
  tapeMesh.rotation.x = -Math.PI / 2;
  tapeMesh.position.set(0, h + 0.002, 0);
  group.add(tapeMesh);

  // Usable area highlight
  const usableGeo = new THREE.BoxGeometry(l * 1.01, h * 0.8, w * 1.01);
  const usableMat = new THREE.MeshBasicMaterial({
    color: 0x10b981,
    transparent: true,
    opacity: 0.25,
    wireframe: true,
  });
  const usableMesh = new THREE.Mesh(usableGeo, usableMat);
  usableMesh.name = 'usableZoneHighlight';
  usableMesh.position.y = h / 2;
  group.add(usableMesh);
}

function buildAluminumCan(group: THREE.Group, material: MaterialItem) {
  const radius = (material.dimensions.diameterCm ? material.dimensions.diameterCm / 2 : 3.3) * 0.15;
  const height = (material.dimensions.heightCm || 12.5) * 0.12;

  const canMat = createBrushedAluminumMaterial();

  const printedMat = new THREE.MeshStandardMaterial({
    color: 0xef4444, // soda red label
    metalness: 0.65,
    roughness: 0.32,
  });

  const bodyH = height * 0.75;
  const bodyGeo = new THREE.CylinderGeometry(radius, radius, bodyH, 32);
  const bodyMesh = new THREE.Mesh(bodyGeo, printedMat);
  bodyMesh.position.y = bodyH / 2 + height * 0.1;
  bodyMesh.castShadow = true;
  group.add(bodyMesh);

  const rimH = height * 0.15;
  const rimGeo = new THREE.CylinderGeometry(radius * 0.9, radius, rimH, 32);
  const rimMesh = new THREE.Mesh(rimGeo, canMat);
  rimMesh.position.y = bodyMesh.position.y + bodyH / 2 + rimH / 2;
  group.add(rimMesh);

  const tabGeo = new THREE.BoxGeometry(0.12, 0.02, 0.22);
  const tabMesh = new THREE.Mesh(tabGeo, canMat);
  tabMesh.position.set(0, rimMesh.position.y + rimH / 2 + 0.01, 0.05);
  group.add(tabMesh);

  const baseH = height * 0.1;
  const baseGeo = new THREE.CylinderGeometry(radius, radius * 0.88, baseH, 32);
  const baseMesh = new THREE.Mesh(baseGeo, canMat);
  baseMesh.position.y = baseH / 2;
  group.add(baseMesh);

  const usableGeo = new THREE.CylinderGeometry(radius * 1.02, radius * 1.02, bodyH * 0.9, 24, 1, true);
  const usableMat = new THREE.MeshBasicMaterial({
    color: 0x10b981,
    transparent: true,
    opacity: 0.25,
    wireframe: true,
  });
  const usableMesh = new THREE.Mesh(usableGeo, usableMat);
  usableMesh.name = 'usableZoneHighlight';
  usableMesh.position.y = bodyMesh.position.y;
  group.add(usableMesh);
}

function buildFabricDenim(group: THREE.Group, material: MaterialItem) {
  const denimMat = new THREE.MeshStandardMaterial({
    color: 0x1e3a8a, // deep indigo denim
    roughness: 0.95,
  });

  const rollGeo = new THREE.CylinderGeometry(0.65, 0.65, 2.2, 32);
  const rollMesh = new THREE.Mesh(rollGeo, denimMat);
  rollMesh.rotation.z = Math.PI / 2;
  rollMesh.position.y = 0.65;
  rollMesh.castShadow = true;
  group.add(rollMesh);

  const flatClothGeo = new THREE.BoxGeometry(2.4, 0.04, 1.8);
  const flatCloth = new THREE.Mesh(flatClothGeo, denimMat);
  flatCloth.position.set(0, 0.02, 0.6);
  group.add(flatCloth);
}

function buildGlassJar(group: THREE.Group, material: MaterialItem) {
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0xf1f5f9,
    metalness: 0.05,
    roughness: 0.05,
    transmission: 0.92,
    transparent: true,
    opacity: 0.8,
    ior: 1.52,
  });

  const lidMat = new THREE.MeshStandardMaterial({
    color: 0xd97706, // gold metallic lid
    metalness: 0.8,
    roughness: 0.3,
  });

  const jarH = 1.8;
  const jarR = 0.85;

  const jarMesh = new THREE.Mesh(new THREE.CylinderGeometry(jarR, jarR, jarH, 32), glassMat);
  jarMesh.position.y = jarH / 2;
  jarMesh.castShadow = true;
  group.add(jarMesh);

  const lidMesh = new THREE.Mesh(new THREE.CylinderGeometry(jarR * 1.04, jarR * 1.04, 0.2, 32), lidMat);
  lidMesh.position.y = jarH + 0.1;
  group.add(lidMesh);
}

function buildBottleCap(group: THREE.Group, material: MaterialItem) {
  const capMat = new THREE.MeshStandardMaterial({
    color: 0x10b981,
    roughness: 0.35,
  });

  const capMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 0.5, 32), capMat);
  capMesh.position.y = 0.25;
  capMesh.castShadow = true;
  group.add(capMesh);
}

// 3D Bounding box & Axis dimension lines
function buildDimensionGuides(dimGroup: THREE.Group, material: MaterialItem) {
  const isBox = material.dimensions.shapeType === 'box';
  const l = isBox ? (material.dimensions.lengthCm || 28) * 0.08 : (material.dimensions.diameterCm || 6.5) * 0.3;
  const w = isBox ? (material.dimensions.widthCm || 18) * 0.08 : (material.dimensions.diameterCm || 6.5) * 0.3;
  const h = (material.dimensions.heightCm || 20) * (isBox ? 0.08 : 0.1);

  // Bounding box wireframe
  const boxGeo = new THREE.BoxGeometry(l, h, w);
  const edges = new THREE.EdgesGeometry(boxGeo);
  const lineMat = new THREE.LineBasicMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.65 });
  const wireframe = new THREE.LineSegments(edges, lineMat);
  wireframe.position.y = h / 2;
  dimGroup.add(wireframe);

  // Height guide line (Z/Y axis)
  const heightLinePoints = [
    new THREE.Vector3(l / 2 + 0.2, 0, w / 2),
    new THREE.Vector3(l / 2 + 0.2, h, w / 2),
  ];
  const hLineGeo = new THREE.BufferGeometry().setFromPoints(heightLinePoints);
  const hLineMat = new THREE.LineBasicMaterial({ color: 0x10b981, linewidth: 2 });
  const hLine = new THREE.Line(hLineGeo, hLineMat);
  dimGroup.add(hLine);

  // Width guide line (X axis)
  const widthLinePoints = [
    new THREE.Vector3(-l / 2, 0, w / 2 + 0.2),
    new THREE.Vector3(l / 2, 0, w / 2 + 0.2),
  ];
  const wLineGeo = new THREE.BufferGeometry().setFromPoints(widthLinePoints);
  const wLineMat = new THREE.LineBasicMaterial({ color: 0xef4444, linewidth: 2 });
  const wLine = new THREE.Line(wLineGeo, wLineMat);
  dimGroup.add(wLine);
}
